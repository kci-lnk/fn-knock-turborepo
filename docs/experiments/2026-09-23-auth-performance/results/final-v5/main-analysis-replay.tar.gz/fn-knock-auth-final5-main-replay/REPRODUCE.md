# Main-matrix offline replay

This archive preserves the original final-v5 main results.json, manifest.json and acceptance.json bytes. It contains no database, runtime key, credential fixture or service log. It is an analysis bundle, not a new experiment.

Run `node summarize-main.mjs` inside the extracted directory (Node 22 or later). The script reads only these three local inputs and the included frozen auth-performance-lib.mjs, verifies their recorded hashes and reconstructs the tables. It does not access the network or start services. Only the report script import was made relative for portability; the statistical library is byte-identical to the runtime snapshot and its SHA is checked against the original manifest.

MAIN-SUMMARY.json records generator path/hash and library path. Those provenance fields naturally change if the archive is moved; numerical and validation results must stay identical. Main raw per-trial time series are collected separately in the final experiment evidence archive; this bundle uses the main summary inputs only.

Source data and acceptance retain their original remote paths and SHA256 associations. A path in those records is provenance, not a local file that the replay needs to open.
