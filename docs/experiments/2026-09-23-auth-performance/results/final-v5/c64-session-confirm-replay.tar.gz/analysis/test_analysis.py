#!/usr/bin/env python3
import copy,importlib.util
from pathlib import Path
p=Path(__file__).with_name('analyze.py');spec=importlib.util.spec_from_file_location('review',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=dict(complete_pairs=6,six_valid_pairs=True,invalid_runs=0,duplicate_runs=0,incomplete_pairs=0,recovery_probe=False,rss_complete_pairs=6,throughput_change_median=0.2,p99_change_median=-0.2,peak_rss_change_median=dict(combined=0.03),throughput_change_bootstrap_95=[0.1,0.3],p99_change_bootstrap_95=[-0.3,-0.1])
assert m.evaluate_gate(base)['passed']
for change in [dict(complete_pairs=5),dict(invalid_runs=1),dict(duplicate_runs=1),dict(rss_complete_pairs=5),dict(throughput_change_median=-0.05001),dict(p99_change_median=0.10001),dict(peak_rss_change_median={'combined':0.05001}),dict(throughput_change_median=0,p99_change_median=0)]:
 g=copy.deepcopy(base);g.update(change);assert not m.evaluate_gate(g)['passed'],change
g=copy.deepcopy(base);g['peak_rss_change_median']['combined']=0.05;assert m.evaluate_gate(g)['passed']
print('10 synthetic gate checks passed; no experiment or network.')
