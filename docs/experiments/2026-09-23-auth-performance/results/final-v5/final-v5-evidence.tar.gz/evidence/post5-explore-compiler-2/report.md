# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +5.2% | -1.9% | 不足6对 | 不足6对 | -0.8% | +30.7% | +14.6% |
| session_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +20.7% | -19.1% | 不足6对 | 不足6对 | -0.2% | +31.5% | +15.3% |
| grant_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +15.4% | -13.0% | 不足6对 | 不足6对 | -1.0% | +31.5% | +14.3% |
| auto_ip_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +41.2% | -26.6% | 不足6对 | 不足6对 | +0.3% | +31.9% | +15.8% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 401.7 | 54.0 | 414.3 | 3152.1 | 38.37 → 38.30 | 36.49 → 35.90 | 0 |
| bootstrap/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 422.7 | 53.0 | 412.7 | 2942.7 | 38.06 → 37.98 | 47.70 → 47.38 | 0 |
| session_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 486.5 | 47.0 | 469.2 | 2865.9 | 39.80 → 39.63 | 38.03 → 34.93 | 0 |
| session_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 587.4 | 38.0 | 437.4 | 2174.5 | 39.70 → 39.45 | 50.00 → 47.06 | 0 |
| grant_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 1049.9 | 23.0 | 539.9 | 1007.5 | 40.01 → 39.71 | 35.57 → 35.57 | 0 |
| grant_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1211.8 | 20.0 | 514.6 | 842.3 | 39.59 → 39.23 | 46.79 → 46.79 | 0 |
| auto_ip_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 167.3 | 109.0 | 485.3 | 6599.0 | 39.14 → 38.96 | 37.54 → 36.68 | 0 |
| auto_ip_hit/16/candidate5-2-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 236.2 | 80.0 | 453.3 | 4541.1 | 39.25 → 39.25 | 49.51 → 48.71 | 0 |

SQLite primary采样最大队列深度 23，最大队列等待 9.0ms，最大活动操作 1.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
