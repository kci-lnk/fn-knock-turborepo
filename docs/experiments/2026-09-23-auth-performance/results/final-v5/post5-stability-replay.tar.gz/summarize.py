"""Offline review of the six completed post5 soak/recovery JSON files; no network."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-dir', type=Path, default=Path(__file__).parent)
parser.add_argument('--plan-dir', type=Path, default=Path(__file__).parent / 'frozen-plan')
parser.add_argument('--output-dir', type=Path, default=Path(__file__).parent)
args = parser.parse_args()
source = args.input_dir.resolve()
out = args.output_dir.resolve()
pins = json.loads((args.plan_dir / 'bundle-manifest.json').read_text())
jobs = {j['name']: j for j in json.loads((args.plan_dir / 'jobs.json').read_text())}
names = ['soak/results.json', 'soak/manifest.json', 'soak.soak-summary.json',
         'recovery/results.json', 'recovery/manifest.json', 'recovery.validity.json']
data = {n: json.loads((source / n).read_text()) for n in names}
sha = lambda b: hashlib.sha256(b).hexdigest()
input_hashes = {n: {'sha256': sha((source / n).read_bytes()), 'bytes': (source / n).stat().st_size} for n in names}

def check_quality(q):
    assert all(q[k] for k in ['sampling_ok', 'health_ok', 'client_ok', 'duration_ok'])

def measurement(m):
    return {k: v for k, v in m.items() if k not in ['histogram_ms', 'anomalies']}

def resources(phase):
    result = {}
    elapsed = phase['measurement']['elapsed_ms'] / 1000
    for name, r in phase['resources'].items():
        assert (r['before']['pid'], r['before']['start_ticks']) == (r['after']['pid'], r['after']['start_ticks'])
        result[name] = {**r, 'cpu_ms_per_success': r['cpu_ms_per_1000_success'] / 1000,
                        'average_cores': r['cpu_seconds'] / elapsed,
                        'sampled_peak_rss_mib': r['peak_rss_bytes'] / 1048576}
    return result

def health(h):
    return {'http_status': h.get('status'), 'observed_at_epoch_ms': h.get('observed_at_epoch_ms'),
            'cached_last_checked_at': h.get('snapshot', {}).get('last_checked_at'),
            'overall_status': h.get('snapshot', {}).get('overall_status'),
            'storage': h.get('storage'), 'auth_bridge': h.get('auth_bridge')}

for case in ['soak', 'recovery']:
    manifest = data[case + '/manifest.json']
    job = jobs[case]
    config = json.loads((args.plan_dir / 'configs' / (job['config'] + '.json')).read_text())
    assert manifest['config'] == config
    expected = {(v['name'], c, v[c], pins['artifacts'][v[c]]['sha256'])
                for v in [config['baseline'], *config['candidates']] for c in ['go', 'rust']}
    actual = {(i['variant'], i['component'], i['path'], i['sha256']) for i in manifest['identities']}
    assert len(manifest['identities']) == 4 and actual == expected
    # The runtime manifest records these eight invoked helpers, not the four outer CLI/report scripts.
    excluded_tools = {'auth-performance-suite.mjs', 'check-auth-performance-plan.mjs',
                      'check-auth-performance.mjs', 'report-auth-performance.mjs'}
    expected_tools = {n: h for n, h in pins['tools_snapshot_manifest']['files'].items() if n not in excluded_tools}
    assert {f['name']: f['sha256'] for f in manifest['harness_identity']['files']} == expected_tools
    assert manifest['harness_identity']['control_binary_sha256'] == '897cfef2a9f4b1fdf7330e66acbe7b4449945875fa2ac99ac9ab63632fc2d398'
    aliases = {'cache-ttl': 'cacheTtl', 'credential-kind': 'credentialKind', 'recovery-probe': 'recoveryProbe', 'profile-idle': 'profileIdle'}
    for key, value in job['options'].items():
        value = value.split(',') if key in ['routes', 'roles'] else bool(value) if key in ['profile', 'recovery-probe'] else value
        assert manifest['options'][aliases.get(key, key)] == value, (case, key)
    rows = data[case + '/results.json']['runs']
    expected_roles = ['candidate'] if case == 'soak' else ['baseline', 'candidate']
    assert len(rows) == len(expected_roles) and {r['role'] for r in rows} == set(expected_roles)
    for r in rows:
        variant = config['baseline'] if r['role'] == 'baseline' else config['candidates'][0]
        assert r['variant'] == variant['name'] and r['candidate'] == config['candidates'][0]['name']
        assert r['variant_metadata'] == variant['metadata'] and r['env'] == variant['env']
        assert r['scenario'] == 'auto_ip_hit' and r['pair'] == 0 and r['concurrency'] == 16
        assert r['profiling'] is False and r['recovery_probe'] == (case == 'recovery')
        assert r['seed']['accounts'] == r['seed']['sessions'] == 1000
        assert r['seed']['ordinary_grants'] == r['seed']['total_grants'] == 100
        assert r['seed']['credential_kind'] == 'totp' and r['seed']['renewal_tokens_per_phase'] == 0
        env = r['effective_runtime_env']
        assert env['FN_KNOCK_TOKIO_WORKER_THREADS'] == '2' and env['FN_KNOCK_RUNTIME_TARGET'] == 'linux'
        assert env['FN_KNOCK_SQLITE_AUTH_READERS'] == variant['env'].get('FN_KNOCK_SQLITE_AUTH_READERS')
        assert env['FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT'] == ('32' if case == 'recovery' else None)
        for key in ['GLIBC_TUNABLES', 'LD_PRELOAD', 'MALLOC_ARENA_MAX', 'GOMEMLIMIT', 'GOGC', 'GOMAXPROCS']:
            assert env[key] is None
        for key in ['cache_control', 'cache_control_after']:
            assert r[key]['runtime_verified'] and r[key]['auth_cache_ttl_seconds'] == r[key]['auth_cache_unauthorized_ttl_seconds'] == 0
        assert r['validation']['passed'] and r['measurement']['failures'] == 0 and r['warmup']['measurement']['failures'] == 0
        check_quality(r['quality'])
        resources(r)

soak = data['soak/results.json']['runs'][0]
trend = data['soak.soak-summary.json']
for key in ['elapsed_ms', 'successful_requests', 'failures']:
    assert trend[key] == soak['measurement'][key]
assert trend['completed_30_minutes_without_request_or_quality_failure'] and trend['elapsed_ms'] >= 1800000
assert trend['quality'] == soak['quality'] and not trend['windows_overlap'] and trend['window_ms'] == 300000
assert trend['processes']['go']['rss_bytes']['samples'] == trend['processes']['rust']['rss_bytes']['samples'] == soak['observation_counts']['process_samples']
assert trend['go_goroutines']['samples'] == soak['observation_counts']['health_samples']
full_buckets = [b for b in trend['buckets'] if b['to_ms'] - b['from_ms'] == 300000]
assert len(full_buckets) == 6
for name in ['go', 'rust']:
    for field in ['rss_bytes', 'fds', 'threads']:
        t = trend['processes'][name][field]
        assert t['first_window_median'] == full_buckets[0]['processes'][name][field]
        assert t['last_window_median'] == full_buckets[-1]['processes'][name][field]

report = {'schema_version': 1, 'input_files': input_hashes,
          'generator_sha256': sha(Path(__file__).read_bytes()),
          'identity_and_workload_contract_passed': True,
          'scope': 'Only six completed JSON files; no soak raw sampling file, service requests, or new load',
          'soak': {'measurement': measurement(soak['measurement']), 'warmup': measurement(soak['warmup']['measurement']),
                   'resources': resources(soak), 'quality': soak['quality'], 'observation_counts': soak['observation_counts'],
                   'trend_from_existing_summary': trend, 'identities': data['soak/manifest.json']['identities']},
          'recovery': [], 'recovery_comparison_is_not_performance_acceptance': True}
for row in data['recovery/results.json']['runs']:
    r = row['recovery']
    assert r['passed'] and r['recovered'] and not r.get('burst_error')
    assert r['burst_concurrency'] == 64 and r['burst_duration_ms'] == 2000
    assert r['recovery_concurrency'] == 1 and r['recovery_deadline_ms'] == 10000 and r['success_window_ms'] == 2000
    burst = r['burst']
    assert r['burst_503_responses'] == burst['measurement']['statuses'].get('503', 0) > 0
    check_quality(burst['quality'])
    checks = []
    for c in r['checks']:
        phase = c['result']
        check_quality(phase['quality'])
        checks.append({k: v for k, v in c.items() if k != 'result'} | {'measurement': measurement(phase['measurement']), 'quality': phase['quality']})
    successful = [c for c in checks if c['continuous_success']]
    assert successful and successful[-1]['measurement']['failures'] == 0
    assert successful[-1]['measurement']['elapsed_ms'] >= 2000 and r['recovery_elapsed_ms'] <= 10000
    gap = r['recovery_started_at_epoch_ms'] - burst['requests_finished_at_epoch_ms']
    report['recovery'].append({'role': row['role'], 'variant': row['variant'], 'passed': r['passed'],
        'burst': measurement(burst['measurement']), 'burst_quality': burst['quality'],
        'burst_503_rate': r['burst_503_responses'] / burst['measurement']['requests'],
        'checks': checks, 'recovery_elapsed_ms': r['recovery_elapsed_ms'], 'observed_until_ms': r['observed_until_ms'],
        'burst_last_request_end_to_recovery_timer_ms': gap,
        'burst_last_request_end_to_success_window_end_ms': gap + r['recovery_elapsed_ms'],
        'health': {key: health(r[key]) for key in ['before_health', 'after_burst_health', 'after_recovery_health']},
        'normal_warmup': measurement(row['warmup']['measurement']), 'normal_load': measurement(row['measurement']),
        'normal_load_quality': row['quality'], 'normal_load_resources': resources(row)})
validity = data['recovery.validity.json']
assert len(validity) == 1 and validity[0]['complete_pairs'] == 1
assert validity[0]['invalid_runs'] == validity[0]['incomplete_pairs'] == validity[0]['duplicate_runs'] == 0
report['recovery_validity'] = validity
report['limitations'] = [
    '只读取既有soak汇总，核对其与results字段/桶边界一致；没有读取大型raw，不能独立重算采样中位数或逐请求正确性。',
    '单候选30分钟单场景只能说明该窗口内未观察到请求失败；5分钟中位数趋势不能证明无泄漏，未做停载/GC后回收观察。',
    'Go goroutine来自缓存health快照，重复样本不独立；Rust异步task计数不可用，native线程数不能替代。',
    'RSS按负载中采样计，Go/Rust峰值不一定同时；不能等同VmHWM。CPU含窗口内后台任务，不是请求延迟。',
    '恢复只做一轮capacity32、burst c64，再降c1；不能证明正常capacity、持续过载、多轮或所有路径的恢复行为。',
    'recovery_elapsed包含2秒连续成功窗口，起点在burst workers退出及phase收尾之后；不等于首次成功时间，也不能据约10ms差异宣称候选恢复更快。',
    '503证明burst产生了可观察拒绝压力；没有请求体/日志归因，不能据此确定Go还是Rust哪层容量首先触发。',
    'health HTTP200仅说明端点可读；缓存overall/auth_bridge仍degraded，不能声明所有组件健康。storage队列仅primary，不能外推auth reader队列。',
    'burst的低延迟/高总RPS主要包含503；recovery后的c16三秒load和validity比较只有一对，均不用于性能收益验收。']

m = report['soak']['measurement']
lines = ['# post5 稳定性与饱和恢复离线审阅', '',
    '仅分析指定六份已完成JSON。固定source、四制品SHA、冻结config、harness/control身份及每trial有效env/TTL均通过合同核对；未访问业务端口、未启动负载，未读取soak大型raw。', '',
    '## 30分钟 auto-IP soak', '',
    f"候选单独运行，c16/clients2、accounts/sessions1000、grants100、TOTP、mobility关闭、TTL0、Tokio2、默认reader1/z及正常capacity。实际负载{m['elapsed_ms']/1000:.3f}秒，{m['successful_requests']}次200，失败{m['failures']}，RPS{m['successful_requests_per_second']:.3f}，P50/P95/P99={m['p50_ms']}/{m['p95_ms']}/{m['p99_ms']}ms。warmup {soak['warmup']['measurement']['successful_requests']}次200、零失败。", '',
    f"采样{soak['observation_counts']['process_samples']}次、health观察{soak['observation_counts']['health_samples']}次；最大采样间隔{soak['quality']['max_sampling_gap_ms']:.3f}ms，客户端event-loop最大延迟{m['client_event_loop_delay_max_ms']:.3f}ms、启动最大延迟{m['client_start_delay_max_ms']:.3f}ms。四项quality均true，timeout phase事件{soak['observation_counts']['timeout_phase_events']}。首尾进程PID/start_ticks一致。", '',
    '| 进程 | RSS首/末5分钟中位MiB（变化） | RSS采样峰MiB | FD首→末/峰 | native线程首→末/峰 | CPU秒 | CPU ms/成功请求 | 平均核数 |',
    '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for name in ['go', 'rust']:
    t = trend['processes'][name]; r = report['soak']['resources'][name]
    rss, fd, th = (t[k] for k in ['rss_bytes', 'fds', 'threads'])
    lines.append(f"| {name} | {rss['first_window_median']/1048576:.3f}→{rss['last_window_median']/1048576:.3f} ({rss['median_change']:+.2%}) | {rss['peak']/1048576:.3f} | {fd['first_window_median']}→{fd['last_window_median']}/{fd['peak']} | {th['first_window_median']}→{th['last_window_median']}/{th['peak']} | {r['cpu_seconds']:.2f} | {r['cpu_ms_per_success']:.3f} | {r['average_cores']:.4f} |")
g = trend['go_goroutines']
lines += ['', f"Go goroutine首/末5分钟中位{g['first_window_median']}→{g['last_window_median']}，峰{g['peak']}；Rust async task不可用。Go native线程在前5分钟后中位稳定为11，Rust始终为8。Go RSS缓慢上升约0.67MiB，Rust中位近乎持平；这是观察到的趋势，不是无泄漏证明。", '',
    '| 5分钟区间 | Go RSS中位MiB | Rust RSS中位MiB | 样本数 |', '| --- | ---: | ---: | ---: |']
for b in full_buckets:
    lines.append(f"| {b['from_ms']/60000:.0f}–{b['to_ms']/60000:.0f}分 | {b['processes']['go']['rss_bytes']/1048576:.3f} | {b['processes']['rust']['rss_bytes']/1048576:.3f} | {b['samples']} |")
lines += ['', 'CPU ms/成功请求 = CPU秒×1000/成功数；平均核数 = CPU秒/实际负载秒。负载生成器和fixture分开计，分别为：', '']
for name in ['client', 'fixture']:
    r = report['soak']['resources'][name]
    lines.append(f"- {name}: {r['cpu_seconds']:.2f} CPU秒，{r['cpu_ms_per_success']:.3f}ms/成功请求，平均{r['average_cores']:.4f}核；采样峰RSS {r['sampled_peak_rss_mib']:.3f}MiB。")
lines += ['', '## capacity32 恢复探测', '',
    '配置的常规warmup/load为c16、1秒/3秒；独立probe先c64 burst发起2秒，再c1寻找持续2秒零失败窗口，恢复计时上限10秒。burst与恢复阶段分别使用最多2个和1个worker。', '',
    '| 角色 | burst实际秒 | burst 200/503 | 503比例 | c1窗口成功/失败 | c1窗口实际ms | 报告恢复ms | burst末请求→计时起点ms | burst末请求→成功窗末ms |',
    '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in report['recovery']:
    b = r['burst']; c = r['checks'][0]['measurement']
    lines.append(f"| {r['role']} | {b['elapsed_ms']/1000:.3f} | {b['statuses'].get('200',0)}/{b['statuses'].get('503',0)} | {r['burst_503_rate']:.2%} | {c['successful_requests']}/{c['failures']} | {c['elapsed_ms']:.3f} | {r['recovery_elapsed_ms']:.3f} | {r['burst_last_request_end_to_recovery_timer_ms']:.3f} | {r['burst_last_request_end_to_success_window_end_ms']:.3f} |")
lines += ['', '两版均第一个c1窗口成功，probe passed=true，随后常规warmup/load均零错误；burst、恢复窗及常规load的四项quality均true。没有自动重试整个trial。报告恢复值包含完整2秒成功窗口，而结束burst请求与开始恢复计时之间包含资源采集/worker清理等收尾。两版约10ms的报告差异不能用作恢复速度优劣结论。', '',
    '| 角色 | c16 warmup成功/失败 | c16 load成功/失败 | load实际秒 | load RPS | load P99ms |', '| --- | ---: | ---: | ---: | ---: | ---: |']
for r in report['recovery']:
    w, m = r['normal_warmup'], r['normal_load']
    lines.append(f"| {r['role']} | {w['successful_requests']}/{w['failures']} | {m['successful_requests']}/{m['failures']} | {m['elapsed_ms']/1000:.3f} | {m['successful_requests_per_second']:.3f} | {m['p99_ms']} |")
lines += ['', 'health端点前后均HTTP200且storage缓存为healthy；但overall/auth_bridge缓存状态仍degraded，burst前后快照甚至复用同一last_checked_at。恢复后bridge reason变为connected。primary队列历史峰值baseline33/268ms、candidate10/5ms，但该字段不统计auth pool，且缓存快照不能定位burst瞬时饱和层。', '', '## 证据边界', '']
lines += ['- ' + limitation for limitation in report['limitations']]
lines += ['', '本分析已结束，不监测或干预后续并发补测。', '']
out.mkdir(parents=True, exist_ok=True)
(out / 'STABILITY-SUMMARY.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
(out / 'STABILITY-REVIEW.md').write_text('\n'.join(lines))
print(json.dumps({'soak_requests': soak['measurement']['successful_requests'], 'recovery_roles': len(report['recovery']), 'contract_passed': True}))
