# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -0.9% | +3.8% | 不足6对 | 不足6对 | +2.0% | -0.7% | +0.7% |
| session_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +25.9% | -15.6% | 不足6对 | 不足6对 | +2.5% | -0.7% | +0.9% |
| grant_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +46.5% | -32.0% | 不足6对 | 不足6对 | +0.8% | +1.1% | +0.9% |
| auto_ip_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +8.3% | +2.8% | 不足6对 | 不足6对 | -0.4% | +10.5% | +4.8% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 397.3 | 53.0 | 413.9 | 3150.7 | 39.23 → 39.23 | 37.18 → 36.06 | 0 |
| bootstrap/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 393.9 | 55.0 | 389.9 | 3171.8 | 40.02 → 39.94 | 36.90 → 36.55 | 0 |
| session_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 485.0 | 45.0 | 458.3 | 2881.4 | 40.50 → 40.37 | 38.28 → 35.34 | 0 |
| session_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 610.6 | 38.0 | 460.2 | 2897.5 | 41.52 → 41.24 | 38.00 → 35.07 | 0 |
| grant_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 1036.4 | 25.0 | 531.5 | 1008.3 | 41.51 → 41.04 | 35.16 → 35.09 | 0 |
| grant_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1518.5 | 17.0 | 421.7 | 1105.0 | 41.84 → 41.46 | 35.55 → 35.52 | 0 |
| auto_ip_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 165.3 | 108.0 | 484.8 | 6786.9 | 40.05 → 40.05 | 37.16 → 36.32 | 0 |
| auto_ip_hit/16/candidate5-z-reader2/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 179.0 | 111.0 | 467.9 | 9413.3 | 39.90 → 39.90 | 41.04 → 39.77 | 0 |

SQLite primary采样最大队列深度 28，最大队列等待 13.0ms，最大活动操作 1.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
