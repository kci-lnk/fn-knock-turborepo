#!/usr/bin/env python3
"""Copy only fixed audit6 smoke/TTL0 files through read-only SSH. No services."""
import datetime,hashlib,json,shlex,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REMOTE='/tmp/fn-knock-auth-performance-20260923/audit6-final'
NAMES=['prepared-manifest.json','started-utc.txt']
for case in ['smoke','session-ttl0']:
    # Read completion first. Once a completed outcome exists, its results are
    # immutable; do not pair an old results read with a just-published outcome.
    NAMES += [case+'.outcome.json']
    NAMES += [case+'/'+n for n in ['manifest.json','results.json']]
    NAMES += [case+s for s in ['.contract.json','.gate.json','.report.md','.contract.stderr.log','.gate.stderr.log','.report.stderr.log']]
remote_code="""import json
from pathlib import Path
root=Path(%r)
names=%r
values={}
for name in names:
 p=root/name
 if p.is_file():values[name]=p.read_text()
print(json.dumps(values))
"""%(REMOTE,NAMES)
result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','root@192.168.31.98','python3 -c '+shlex.quote(remote_code)],capture_output=True,text=True,check=True)
values=json.loads(result.stdout);copied=[];incomplete=[]
for name,content in values.items():
    if name.endswith('.json'):
        try:json.loads(content)
        except json.JSONDecodeError:incomplete.append(name);continue
    path=ROOT/'inputs'/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(content);copied.append(name)
record={'copied_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'remote_root':REMOTE,'files':{name:{'sha256':hashlib.sha256((ROOT/'inputs'/name).read_bytes()).hexdigest(),'bytes':(ROOT/'inputs'/name).stat().st_size} for name in copied},'write_in_progress_json_skipped':incomplete,'remote_write':False,'business_port_access':False}
(ROOT/'collection.json').write_text(json.dumps(record,indent=2)+'\n')
summary={'copied_files':len(copied),'write_in_progress_skipped':incomplete,'cases':{}}
for case in ['smoke','session-ttl0']:
    p=ROOT/'inputs'/case/'results.json';out=ROOT/'inputs'/(case+'.outcome.json')
    rows=json.loads(p.read_text()).get('runs',[]) if p.exists() else []
    status={'rows':len(rows),'valid':sum(r.get('validation',{}).get('passed') is True for r in rows),'completed_pairs':sum(sum(r.get('pair')==pair for r in rows)==2 for pair in range(6)) if case=='session-ttl0' else None,'outcome':json.loads(out.read_text()) if out.exists() else None}
    if status['outcome']:status['outcome']={k:status['outcome'].get(k) for k in (['passed','exit_code'] if status['outcome'].get('passed') else ['passed','exit_code','stages'])}
    summary['cases'][case]=status
print(json.dumps(summary,indent=2))
