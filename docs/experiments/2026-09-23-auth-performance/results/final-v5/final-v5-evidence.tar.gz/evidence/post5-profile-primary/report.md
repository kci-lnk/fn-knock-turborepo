# 鉴权性能实验结果

记录 6 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| grant_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +277.8% | -66.7% | 不足6对 | 不足6对 | -0.6% | -1.8% | -1.2% |
| session_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +161.3% | -61.9% | 不足6对 | 不足6对 | +0.6% | -7.6% | -3.6% |
| auto_ip_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +109.1% | -54.1% | 不足6对 | 不足6对 | -1.6% | -11.1% | -6.6% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| grant_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 274.6 | 69.0 | 515.1 | 3579.0 | 40.18 → 39.43 | 36.12 → 36.12 | 0 |
| grant_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1037.3 | 23.0 | 539.3 | 1020.2 | 39.94 → 39.69 | 35.48 → 35.33 | 0 |
| session_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 187.5 | 113.0 | 587.8 | 8513.6 | 40.02 → 39.53 | 41.77 → 41.16 | 0 |
| session_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 490.0 | 43.0 | 467.8 | 2932.6 | 40.27 → 39.82 | 38.59 → 35.48 | 0 |
| auto_ip_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 82.8 | 229.0 | 805.9 | 20080.2 | 39.50 → 39.50 | 43.03 → 42.23 | 0 |
| auto_ip_hit/16/candidate5/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 173.2 | 105.0 | 453.8 | 6421.2 | 38.86 → 38.86 | 38.24 → 37.38 | 0 |

| 路由 / 角色 | executor调用/成功请求 | executor wall ms/成功请求 | executor CPU ms/成功请求 | admission等待 ms/成功请求 | idle executor调用/秒 |
| --- | ---: | ---: | ---: | ---: | ---: |
| candidate5/grant_hit/baseline/pair1 | 6.017 | 2.767 | 2.737 | n/a | 1.399 |
| candidate5/grant_hit/candidate/pair1 | 2.004 | 0.633 | 0.612 | 13.366 | 1.399 |
| candidate5/session_hit/baseline/pair1 | 10.026 | 1.796 | 1.422 | n/a | 2.798 |
| candidate5/session_hit/candidate/pair1 | 8.010 | 0.897 | 0.738 | 26.724 | 2.798 |
| candidate5/auto_ip_hit/baseline/pair1 | 3.052 | 5.647 | 4.163 | n/a | 2.798 |
| candidate5/auto_ip_hit/candidate/pair1 | 3.029 | 4.617 | 4.535 | 79.653 | 2.798 |

| 路由 / 角色 | auth reader调用/成功请求 | auth reader wall ms/成功请求 | auth reader CPU ms/成功请求 | auth reader admission等待 ms/成功请求 | idle auth reader调用/秒 |
| --- | ---: | ---: | ---: | ---: | ---: |
| candidate5/grant_hit/baseline/pair1 | 6.000 | 2.764 | 2.734 | n/a | n/a |
| candidate5/grant_hit/candidate/pair1 | 2.000 | 0.633 | 0.611 | 13.366 | n/a |
| candidate5/session_hit/baseline/pair1 | 3.000 | 0.411 | 0.241 | n/a | n/a |
| candidate5/session_hit/candidate/pair1 | 7.000 | 0.683 | 0.587 | 26.273 | n/a |
| candidate5/auto_ip_hit/baseline/pair1 | n/a | n/a | n/a | n/a | n/a |
| candidate5/auto_ip_hit/candidate/pair1 | 3.000 | 4.611 | 4.529 | 79.653 | n/a |

Operation recorder统计进程内executor job scope，包含同一捕获窗口的背景操作；每成功请求归一化不等于每请求精确SQL条数。一次executor job可能执行多条SQL。idle频率保留作背景参照，不自动扣减。profiling会增加开销，应另跑关闭profiling的性能A/B。
原overall executor合计primary与auth reader，overall admission合计全部入场label；auth_reader单独聚合全部auth reader slot，执行仅取kind=sqlite_auth_read，入场仅取kind=sqlite_admission且label=sqlite_auth_read。两者都不包含中间的checkpoint gate等待，也不提供逐slot分布；并行scope的累计wall可以超过捕获时长。旧报告缺少auth_reader时显示n/a。

SQLite primary采样最大队列深度 16，最大队列等待 63.0ms，最大活动操作 4.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
