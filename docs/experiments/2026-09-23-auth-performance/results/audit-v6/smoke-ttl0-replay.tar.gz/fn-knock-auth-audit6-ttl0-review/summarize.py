#!/usr/bin/env python3
"""Offline audit6 smoke + TTL0 analysis; fixed-library statistics, no network."""
import argparse,hashlib,importlib.util,json,math,statistics,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def median(xs):
    xs=[x for x in xs if isinstance(x,(int,float)) and math.isfinite(x)]
    return statistics.median(xs) if xs else None
def pct(a,b):return b/a-1 if isinstance(a,(int,float)) and isinstance(b,(int,float)) and a>0 else None
def row_metrics(row):
    mm=row['measurement'];res=row['resources'];seconds=mm['elapsed_ms']/1000
    out=dict(successful_requests=mm['successful_requests'],rps=mm['successful_requests_per_second'],p99_ms=mm['p99_ms'],elapsed_ms=mm['elapsed_ms'])
    for component in ['go','rust','client','fixture']:
        r=res.get(component,{})
        out[component+'_peak_rss_mib']=r.get('peak_rss_bytes',0)/(1024**2)
        out[component+'_cpu_ms_per_success']=r['cpu_ms_per_1000_success']/1000 if r.get('cpu_ms_per_1000_success') is not None else None
        out[component+'_average_cores']=r['cpu_seconds']/seconds if r.get('cpu_seconds') is not None else None
    out['combined_peak_rss_mib']=out['go_peak_rss_mib']+out['rust_peak_rss_mib']
    out['combined_cpu_ms_per_success']=out['go_cpu_ms_per_success']+out['rust_cpu_ms_per_success']
    out['combined_average_cores']=out['go_average_cores']+out['rust_average_cores']
    return out
def fmt(x,n=2):return '不可用' if x is None else f'{x:.{n}f}'
def percent(x):return '不可用' if x is None else f'{x*100:+.2f}%'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT/'inputs')
    parser.add_argument('--plan',type=Path,default=ROOT/'plan')
    parser.add_argument('--tools',type=Path,default=ROOT/'tools')
    parser.add_argument('--out',type=Path,default=ROOT/'analysis')
    a=parser.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    plan=load(a.plan/'manifest.json')
    assert sha(a.plan/'manifest.json')=='87e69d8e1dedce80e7ddb6ea574fa1145975123cdca60b3b662f0637a78002ce','wrong frozen audit6 plan'
    for name,value in plan['files'].items():assert sha(a.plan/name)==value,'plan file changed: '+name
    for name in ['auth-performance-lib.mjs','check-auth-performance.mjs','report-auth-performance.mjs']:assert sha(a.tools/name)==plan['tools']['files'][name],'frozen tool changed: '+name
    spec=importlib.util.spec_from_file_location('audit6_check_plan',a.plan/'check-plan.py');cp=importlib.util.module_from_spec(spec);spec.loader.exec_module(cp)
    input_hashes={str(p.relative_to(a.input)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(a.input.rglob('*')) if p.is_file()}
    origins=load(a.input/'source-index.json')['files'] if (a.input/'source-index.json').exists() else {}
    if origins:
        for name,record in origins.items():
            assert sha(a.input/name)==record['collected_sha256'] and (a.input/name).stat().st_size==record['collected_bytes'],'collector view changed: '+name
        assert origins['prepared-manifest.json']['source_sha256']==sha(a.plan/'manifest.json'),'remote prepared source differs'
        assert load(a.input/'prepared-manifest.json')==plan,'normalized prepared manifest content differs'
    else:assert sha(a.input/'prepared-manifest.json')==sha(a.plan/'manifest.json'),'remote prepared manifest differs'
    def matches_origin(name,evidence):
        p=a.input/name
        if not p.is_file():return False
        if origins:
            record=origins.get(name,{})
            return record.get('source_sha256')==evidence['sha256'] and record.get('source_bytes')==evidence['bytes']
        return sha(p)==evidence['sha256'] and p.stat().st_size==evidence['bytes']
    summary={'schema_version':1,'analysis_scope':['smoke','session-ttl0'],'status':'checkpoint','plan_sha256':sha(a.plan/'manifest.json'),'product_sources':plan['product_sources'],'artifacts':plan['artifacts'],'prior_v5_data_pooled':False,'cases':{},'inputs':input_hashes,'limitations':['只分析本批的 smoke 和 TTL0；TTL1、soak、recovery 不在本报告范围。','TTL0 六对评价正确性修复相对上一优化候选的增量非回退，不是 d4→优化版收益。','稳态 session 命中负载不主动触发注销；不能替代 logout/singleflight 并发正确性回归。','RSS 使用 Go/Rust 各自负载采样峰值之和，不代表同一时刻峰值；role 中位数和 paired change 中位数不同。','CPU ms/成功请求 = cpu_ms_per_1000_success / 1000；平均核数 = CPU 秒 / 实际负载秒，包含进程后台工作，不是单次 Rust 请求的纯CPU。','client/fixture 进程在 case 内复用，产品进程逐 trial 重启；采样 health_ok 不等于所有缓存健康组件均 healthy。']}
    if origins:summary['collector_source_index']=origins
    for name in ['smoke','session-ttl0']:
        case=a.input/name;outcome=a.input/(name+'.outcome.json')
        if not (case/'results.json').exists():summary['cases'][name]={'status':'not_started_or_not_collected'};continue
        result=load(case/'results.json');manifest=load(case/'manifest.json');rows=result.get('runs',[])
        item={'status':'checkpoint','observed_trials':len(rows),'valid_trials':sum(r.get('validation',{}).get('passed') is True for r in rows),'outcome':load(outcome) if outcome.exists() else None}
        summary['cases'][name]=item
        if not outcome.exists():
            job=next(j for j in plan['jobs'] if j['name']==name);config=load(a.plan/'configs'/f"{job['config']}.json")
            try:
                partial=cp.contract(plan,job,config,manifest,result)
                expected_partial={'exact ordered trials / no missing route, pair, role or duplicate','unique trial directories'}
                item['checkpoint_identity_quality_errors']=[e for e in partial['errors'] if e not in expected_partial]
            except (KeyError,TypeError,ValueError,AttributeError) as error:item['checkpoint_identity_quality_errors']=['incomplete/invalid row: '+str(error)]
            if item['checkpoint_identity_quality_errors']:item['status']='invalid_checkpoint'
            continue
        item['collection_snapshot_issues']=[]
        for path,evidence in item['outcome'].get('evidence',{}).items():
            if path.endswith('.run.log'):continue
            p=a.input/path
            if not matches_origin(path,evidence):
                item['collection_snapshot_issues'].append(path)
        if item['collection_snapshot_issues'] and item['outcome'].get('passed') is True:
            item['status']='incomplete_collection'
            continue
        job=next(j for j in plan['jobs'] if j['name']==name);config=load(a.plan/'configs'/f"{job['config']}.json")
        try:contract=cp.contract(plan,job,config,manifest,result)
        except (KeyError,TypeError,ValueError,AttributeError) as error:contract={'contract_passed':False,'errors':['malformed/incomplete row: '+str(error)]}
        (a.out/(name+'.contract-recomputed.json')).write_text(json.dumps(contract,indent=2)+'\n')
        item['contract_recomputed']=contract
        flags=plan['gate_flags'] if name=='session-ttl0' else []
        gate=subprocess.run(['node',str(a.tools/'check-auth-performance.mjs'),str(case/'results.json'),*flags],capture_output=True,text=True)
        (a.out/(name+'.gate-recomputed.json')).write_text(gate.stdout)
        (a.out/(name+'.gate-recomputed.stderr.log')).write_text(gate.stderr)
        item['gate_exit_code']=gate.returncode
        try:comparison=json.loads(gate.stdout)
        except json.JSONDecodeError:comparison=None
        item['comparison_recomputed']=comparison
        remote_gate=a.input/(name+'.gate.json');item['remote_gate_matches_recomputed']=remote_gate.exists() and load(remote_gate)==comparison
        item['outcome_artifacts_match']=True
        for path,evidence in item['outcome'].get('evidence',{}).items():
            p=a.input/path
            # run.log is intentionally excluded from this bounded collector.
            if p.exists() and not matches_origin(path,evidence):item['outcome_artifacts_match']=False
        item['status']='passed' if contract['contract_passed'] and gate.returncode==0 and item['outcome'].get('passed') is True and item['remote_gate_matches_recomputed'] and item['outcome_artifacts_match'] else 'failed'
        # The harness retains a failed readiness/preflight row even if no load
        # phase exists. Preserve the failure report instead of leaving an old
        # checkpoint behind by indexing missing measurements/resources.
        def complete_metrics(r):
            mm=r.get('measurement',{});quality=r.get('quality',{});observations=r.get('observation_counts',{})
            return all(k in mm for k in ['elapsed_ms','successful_requests','successful_requests_per_second','p99_ms','statuses','client_event_loop_delay_max_ms','client_start_delay_max_ms']) and all(k in quality for k in ['max_sampling_gap_ms','sampling_ok','health_ok','client_ok','duration_ok']) and all(k in observations for k in ['process_samples','health_samples']) and all(all(isinstance(r.get('resources',{}).get(c,{}).get(k),(int,float)) for k in ['peak_rss_bytes','cpu_ms_per_1000_success','cpu_seconds']) for c in ['go','rust'])
        if not rows or not all(complete_metrics(r) for r in rows):
            item['status']='failed'
            item['metrics_unavailable_reason']='At least one retained failed trial has no complete load/resources/quality; use contract, gate stderr and original row.'
            continue
        item['counts']={phase:{'successes':sum((r.get('warmup',{}).get('measurement',{}) if phase=='warmup' else r.get('measurement',{})).get('successful_requests',0) for r in rows),'failures':sum((r.get('warmup',{}).get('measurement',{}) if phase=='warmup' else r.get('measurement',{})).get('failures',0) for r in rows)} for phase in ['warmup','load']}
        item['quality']={'max_client_event_loop_delay_ms':max(r['measurement']['client_event_loop_delay_max_ms'] for r in rows),'max_client_start_delay_ms':max(r['measurement']['client_start_delay_max_ms'] for r in rows),'max_sampling_gap_ms':max(r['quality']['max_sampling_gap_ms'] for r in rows),'min_process_samples':min(r['observation_counts']['process_samples'] for r in rows),'min_health_samples':min(r['observation_counts']['health_samples'] for r in rows),'response_statuses':sorted({s for r in rows for s in r['measurement']['statuses']}),'all_four_quality_flags':all(all(r['quality'][k] is True for k in ['sampling_ok','health_ok','client_ok','duration_ok']) for r in rows)}
        if name=='smoke':
            item['routes']=[{'scenario':s,'rows':[{'role':r['role'],'requests':r['measurement']['successful_requests'],'statuses':r['measurement']['statuses'],'preflight':r['preflight'],'quality':r['quality']} for r in rows if r['scenario']==s]} for s in job['options']['routes']]
        else:
            pairs=[]
            for pair in range(6):
                by={r['role']:row_metrics(r) for r in rows if r['pair']==pair}
                if set(by)!=set(['baseline','candidate']):continue
                pairs.append({'pair':pair,'order':'AB' if pair%2==0 else 'BA',**by,'relative_change':{k:pct(by['baseline'][k],by['candidate'][k]) for k in by['baseline'] if k not in ['successful_requests','elapsed_ms']}})
            item['pairs']=pairs
            item['role_metric_medians']={role:{k:median([p[role][k] for p in pairs]) for k in pairs[0][role]} for role in ['baseline','candidate']} if pairs else {}
            item['cpu_paired_change_medians']={k:median([p['relative_change'][k] for p in pairs]) for k in ['go_cpu_ms_per_success','rust_cpu_ms_per_success','combined_cpu_ms_per_success','combined_average_cores']}
    statuses=[x['status'] for x in summary['cases'].values()]
    summary['status']='failed' if any(x in statuses for x in ['failed','invalid_checkpoint']) else 'passed' if statuses==['passed','passed'] else 'checkpoint'
    write=a.out/'SUMMARY.json';write.write_text(json.dumps(summary,indent=2)+'\n')
    lines=['# audit6 smoke 与 TTL0 六对独立复核','',f"状态：**{summary['status']}**。只读采集与离线复算，不启动业务服务、不重新运行实验。",'',f"固定计划 SHA256 `{summary['plan_sha256']}`；baseline Go4d15fa3 / Rust5fdd，candidate Go66998225 / Rust5fdd（仅嵌入新 gateway commit 重建）。两角色 reader1/z/Tokio2、正常 capacity unset，c16、2 clients、N1000 accounts/sessions、grants100、TOTP、mobility=false；本报告两组 TTL 均为 0。",'']
    for name,item in summary['cases'].items():
        lines += [f"## {name}",'',f"状态：{item['status']}；已写 {item.get('observed_trials',0)} 行，validation 通过 {item.get('valid_trials',0)} 行。"]
        if 'counts' not in item:
            note='失败行缺少完整测量字段；已保留 contract/gate/outcome 及原始记录，不补造指标。' if item['status']=='failed' else '已写入的 checkpoint 出现身份或有效性错误：'+str(item['checkpoint_identity_quality_errors']) if item['status']=='invalid_checkpoint' else '本地采集快照与 outcome 哈希尚未齐备；需重新只读采集，不判实验失败。' if item['status']=='incomplete_collection' else '尚未完整，只作 checkpoint；已写行身份/环境/TTL/质量逐项检查无错，不给验收或收益结论。'
            lines+=['',note,'']
            continue
        counts=item['counts'];q=item['quality']
        lines += ['',f"Exact contract：{item['contract_recomputed']['contract_passed']}；冻结 checker 退出 {item['gate_exit_code']}；远端 gate 与离线复算一致：{item['remote_gate_matches_recomputed']}；outcome 已采集制品哈希一致：{item['outcome_artifacts_match']}。",f"warm/load 成功请求 {counts['warmup']['successes']:,}/{counts['load']['successes']:,}，失败 {counts['warmup']['failures']}/{counts['load']['failures']}；load client event-loop delay 最大 {fmt(q['max_client_event_loop_delay_ms'],3)} ms，启动延迟最大 {fmt(q['max_client_start_delay_ms'],3)} ms，采样间隔最大 {fmt(q['max_sampling_gap_ms'],3)} ms。四项 load quality 全通过：{q['all_four_quality_flags']}。",'']
        if name=='smoke':
            lines+=['| 路由 | baseline/candidate 成功数 | 状态码 |','|---|---:|---|']
            for row in item['routes']:lines += [f"| {row['scenario']} | "+' / '.join(str(r['requests']) for r in row['rows'])+' | '+' / '.join(','.join(r['statuses']) for r in row['rows'])+' |']
            lines+=['','302 仅对应预期登录重定向；JSON/API 和业务 origin 分别由冻结 harness 验证。短 smoke 只说明有效性。','']
        else:
            lines+=['| pair / 次序 | RPS base→fix | Δ RPS | P99 ms base→fix | Δ P99 | 合计峰值 MiB base→fix | Δ RSS | CPU ms/成功 base→fix (Go+Rust) |','|---|---:|---:|---:|---:|---:|---:|---:|']
            for p in item['pairs']:
                b=p['baseline'];c=p['candidate'];d=p['relative_change']
                lines += [f"| {p['pair']+1} {p['order']} | {fmt(b['rps'])}→{fmt(c['rps'])} | {percent(d['rps'])} | {fmt(b['p99_ms'],0)}→{fmt(c['p99_ms'],0)} | {percent(d['p99_ms'])} | {fmt(b['combined_peak_rss_mib'])}→{fmt(c['combined_peak_rss_mib'])} | {percent(d['combined_peak_rss_mib'])} | {fmt(b['combined_cpu_ms_per_success'],3)}→{fmt(c['combined_cpu_ms_per_success'],3)} |"]
            if item['comparison_recomputed']:
                comp=item['comparison_recomputed'][0]
                lines += ['',f"冻结 compareRuns 的六对变化中位数：RPS {percent(comp['throughput_change_median'])}，P99 {percent(comp['p99_change_median'])}，合计 RSS {percent(comp['peak_rss_change_median']['combined'])}。门槛分别 ≥−5%、≤+10%、≤+5%；不要求额外改善，也不把单对越线误写成整组失败。",'']
                lines += [f"冻结工具的配对 bootstrap 95% 区间：RPS {' 至 '.join(percent(x) for x in comp['throughput_change_bootstrap_95'])}；P99 {' 至 '.join(percent(x) for x in comp['p99_change_bootstrap_95'])}。本批两区间均包含零，不声称修复带来显著加速。",'']
            lines+=['| 角色绝对值中位数 | Go CPU ms/成功 | Rust CPU ms/成功 | 合计平均核数 | Go 峰值 MiB | Rust 峰值 MiB |','|---|---:|---:|---:|---:|---:|']
            for role,v in item['role_metric_medians'].items():lines += [f"| {role} | {fmt(v['go_cpu_ms_per_success'],3)} | {fmt(v['rust_cpu_ms_per_success'],3)} | {fmt(v['combined_average_cores'],3)} | {fmt(v['go_peak_rss_mib'])} | {fmt(v['rust_peak_rss_mib'])} |"]
            lines+=['','CPU 与单进程 RSS 的每对原始值及变化完整保存在 SUMMARY.json；没有为 CPU 增加新验收门槛。','']
    lines+=['## 范围限制','']+['- '+x for x in summary['limitations']]
    (a.out/'REVIEW.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'status':summary['status'],'cases':{k:v['status'] for k,v in summary['cases'].items()},'output':str(a.out)},indent=2))
    raise SystemExit(1 if summary['status']=='failed' else 0)
if __name__=='__main__':main()
