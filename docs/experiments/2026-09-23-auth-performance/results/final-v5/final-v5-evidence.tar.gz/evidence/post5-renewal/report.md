# 鉴权性能实验结果

记录 12 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| grant_renewal/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-1/total-grants-130/renewals-64 | 6 | +153.2% | -51.5% | +133.0% … +171.5% | -60.2% … -48.7% | -0.1% | -1.2% | -0.7% |

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| grant_renewal/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-1/total-grants-130/renewals-64/baseline | 121.4 | 170.0 | 859.4 | 10625.0 | 39.67 → 39.67 | 35.67 → 35.67 | 0 |
| grant_renewal/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-1/total-grants-130/renewals-64/candidate | 304.2 | 82.0 | 625.0 | 4921.9 | 39.51 → 39.27 | 35.18 → 35.17 | 0 |

SQLite primary采样最大队列深度 0，最大队列等待 0.0ms，最大活动操作 0.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
