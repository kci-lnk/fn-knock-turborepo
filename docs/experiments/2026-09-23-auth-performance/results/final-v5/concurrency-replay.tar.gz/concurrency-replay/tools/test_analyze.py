#!/usr/bin/env python3
"""Synthetic offline tests; no actual measurements or network operations."""
import copy
import importlib.util
from pathlib import Path
import tempfile

sp=importlib.util.spec_from_file_location('analysis',Path(__file__).with_name('analyze.py'))
a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)

def fixture(c,pin,config):
    docs=dict(results=dict(schema_version=1,runs=[]),manifest=dict(schema_version=1,config=config,options=dict(pin['options'],concurrency=c),identities=[dict(variant=v['name'],component=k,path=v[k],sha256=pin['artifacts'][v[k]]['sha256']) for v in [config['baseline'],config['candidates'][0]] for k in ['go','rust']],harness_identity=dict(files=[dict(name=n,sha256=pin['tools']['files'][n]) for n in sorted(a.HARNESS_FILES)],control_binary_sha256=pin['control_binary']['sha256']),host=dict(kernel='synthetic-linux',node='synthetic-node')),contract=dict(complete_expected_trials=8,concurrency=c,contract_passed=True,performance_acceptance=False),validity=[])
    for route in pin['options']['routes']:
        for role in a.ROLES:
            v=config['baseline'] if role=='baseline' else config['candidates'][0]
            multiplier=1 if role=='baseline' else 2
            def measurement(ms):
                requests=ms//10*multiplier
                return dict(elapsed_ms=ms,successful_requests=requests,requests=requests,failures=0,successful_requests_per_second=requests*1000/ms,requests_per_second=requests*1000/ms,statuses={'200':requests},anomalies=[],latency_overflow=0,client_event_loop_delay_max_ms=10,client_start_delay_max_ms=1,p50_ms=1,p95_ms=4,p99_ms=10/multiplier)
            m=measurement(15000)
            resources={name:dict(cpu_seconds=1,cpu_ms_per_1000_success=1000000/m['successful_requests'],peak_rss_bytes=32*1048576,end_rss_bytes=30*1048576,peak_fds=10,peak_threads=4,before=dict(pid=100,start_ticks=100,cpu_seconds=1),after=dict(pid=100,start_ticks=100,cpu_seconds=2)) for name in a.PROCESSES}
            row=dict(scenario=route,pair=0,role=role,candidate='candidate5',variant=v['name'],directory=f'/synthetic/c{c}/{route}/{role}',variant_metadata=v['metadata'],env=v['env'],concurrency=c,cache_ttl_seconds=0,roles=a.ROLES,profiling=False,recovery_probe=False,seed=dict(scenario=route,accounts=1000,sessions=1000,ordinary_grants=100,total_grants=100,credential_kind='totp',renewal_tokens_per_phase=0),effective_runtime_env=dict(FN_KNOCK_RUNTIME_TARGET='linux',FN_KNOCK_TOKIO_WORKER_THREADS='2',FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT=None,FN_KNOCK_SQLITE_AUTH_READERS='1' if role=='candidate' else None,GLIBC_TUNABLES=None,LD_PRELOAD=None,MALLOC_ARENA_MAX=None,GOMEMLIMIT=None,GOGC=None,GOMAXPROCS=None),preflight=dict(status=200,expected='bootstrap' if route=='bootstrap' else 'origin',origin=None if route=='bootstrap' else 'auth-performance-owned-origin-v1',renewal=False),validation=dict(passed=True),quality=dict(sampling_ok=True,health_ok=True,client_ok=True,duration_ok=True,max_sampling_gap_ms=210),observation_counts=dict(process_samples=75,health_samples=15,timeout_phase_events=0),warmup=dict(measurement=measurement(5000)),measurement=m,resources=resources)
            for field in ['cache_control','cache_control_after']:row[field]=dict(runtime_verified=True,auth_cache_ttl_seconds=0,auth_cache_unauthorized_ttl_seconds=0)
            docs['results']['runs'].append(row)
        docs['validity'].append(dict(key=f'{route}/{c}/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0',complete_pairs=1,incomplete_pairs=0,invalid_runs=0,duplicate_runs=0,six_valid_pairs=False,rss_complete_pairs=1,recovery_probe=False,throughput_change_bootstrap_95=None,p99_change_bootstrap_95=None,throughput_change_median=1,p99_change_median=-0.5,paired_throughput_changes=[1],paired_p99_changes=[-0.5],peak_rss_change_median=dict(go=0,rust=0,combined=0),paired_peak_rss_changes=dict(go=[0],rust=[0],combined=[0])))
    return docs

def run():
    pin,config,_=a.load_pin(a.PLAN_DIRECTORY)
    for c in [1,16,64]:
        original=fixture(c,pin,config)
        good=a.analyze_group(c,original,pin,config)
        assert good['checks_passed'],good['errors']
        assert good['trials'][0]['processes']['go']['average_cpu_cores']==1/15
        changes=[
          ('wrong duration',lambda d:d['manifest']['options'].__setitem__('warmup',20)),
          ('wrong source',lambda d:d['results']['runs'][0].__setitem__('variant_metadata',{})),
          ('wrong hash',lambda d:d['manifest']['identities'][0].__setitem__('sha256','0'*64)),
          ('missing tool',lambda d:d['manifest']['harness_identity']['files'].pop()),
          ('wrong env',lambda d:d['results']['runs'][0]['effective_runtime_env'].__setitem__('FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT','32')),
          ('wrong seed',lambda d:d['results']['runs'][0]['seed'].__setitem__('accounts',100)),
          ('wrong TTL',lambda d:d['results']['runs'][0]['cache_control_after'].__setitem__('auth_cache_ttl_seconds',1)),
          ('missing trial',lambda d:d['results']['runs'].pop()),
          ('wrong quality',lambda d:d['results']['runs'][0]['quality'].__setitem__('client_ok',False)),
          ('wrong status',lambda d:d['results']['runs'][0]['measurement'].__setitem__('statuses',{'503':1500})),
          ('wrong arithmetic',lambda d:d['results']['runs'][0]['measurement'].__setitem__('successful_requests_per_second',777)),
          ('CPU absent',lambda d:d['results']['runs'][0]['resources']['client'].pop('cpu_seconds')),
          ('wrong contract',lambda d:d['contract'].__setitem__('performance_acceptance',True)),
          ('fabricated CI',lambda d:d['validity'][0].__setitem__('throughput_change_bootstrap_95',[0.5,1.5])),
          ('wrong validity change',lambda d:d['validity'][0].__setitem__('throughput_change_median',0.1)),
        ]
        for name,change in changes:
            modified=copy.deepcopy(original);change(modified)
            assert not a.analyze_group(c,modified,pin,config)['checks_passed'],name
        modified=copy.deepcopy(original)
        r=modified['results']['runs'][0];res=r['resources']['client'];res['cpu_seconds']=30;res['after']['cpu_seconds']=31;res['cpu_ms_per_1000_success']=30e6/r['measurement']['successful_requests']
        warning=a.analyze_group(c,modified,pin,config)
        assert warning['checks_passed'] and warning['warnings']
        # Frozen harness does not gate warmup.duration_ok: preserve the actual
        # overrun and false diagnostic while keeping response failures fatal.
        modified=copy.deepcopy(original)
        warm=modified['results']['runs'][0]['warmup'];warm['measurement']['elapsed_ms']=5802.480224609375
        warm['quality']=dict(duration_ok=False,client_ok=True,sampling_ok=True,health_ok=True,max_sampling_gap_ms=None)
        for key in ['requests_per_second','successful_requests_per_second']:
            warm['measurement'][key]=warm['measurement']['successful_requests']*1000/warm['measurement']['elapsed_ms']
        diagnostic=a.analyze_group(c,modified,pin,config)
        assert diagnostic['checks_passed'] and any('预热实际' in x for x in diagnostic['warnings'])
        assert diagnostic['trials'][0]['warmup_quality']['duration_ok'] is False
        warm['measurement']['failures']=1
        assert not a.analyze_group(c,modified,pin,config)['checks_passed']
    with tempfile.TemporaryDirectory(prefix='synthetic-layout-',dir=Path(__file__).parent) as td:
        d=Path(td)/'c1';d.mkdir();p=Path(str(d)+'.contract.json');p.write_text('{}')
        assert a.sidecar(d,'contract.json')==p
        (d/'contract.json').write_text('{}');assert a.sidecar(d,'contract.json')==d/'contract.json'
        (d/'contract.json').write_text('{"different":true}')
        try:a.sidecar(d,'contract.json');raise AssertionError('ambiguous layout accepted')
        except ValueError:pass
    print('Synthetic offline tests passed: three valid groups; 45 invalid mutations; CPU warning; warmup overrun warning preserves duration_ok=false while failures remain fatal; two layouts/conflict rejection. No network.')

if __name__=='__main__':run()
