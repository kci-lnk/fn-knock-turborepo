# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +186.6% | -62.7% | 不足6对 | 不足6对 | +1.5% | -2.5% | -0.5% |
| session_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +176.3% | -63.7% | 不足6对 | 不足6对 | +4.8% | +8.3% | +6.6% |
| grant_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +269.8% | -66.3% | 不足6对 | 不足6对 | +1.6% | -2.4% | -0.2% |
| auto_ip_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +104.6% | -50.8% | 不足6对 | 不足6对 | +0.2% | -22.1% | -11.6% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 137.3 | 515.0 | 336.3 | 9677.9 | 45.20 → 45.20 | 43.93 → 43.57 | 0 |
| bootstrap/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 393.5 | 192.0 | 427.5 | 3194.2 | 45.89 → 45.49 | 42.82 → 38.52 | 0 |
| session_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 174.0 | 419.0 | 453.7 | 8917.3 | 43.69 → 43.69 | 44.59 → 43.23 | 0 |
| session_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 480.8 | 152.0 | 455.0 | 2927.7 | 45.81 → 45.69 | 48.29 → 36.46 | 0 |
| grant_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 279.3 | 255.0 | 390.6 | 3473.0 | 45.36 → 45.02 | 37.68 → 37.41 | 0 |
| grant_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1032.9 | 86.0 | 481.2 | 1001.0 | 46.11 → 46.11 | 36.77 → 36.63 | 0 |
| auto_ip_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 82.0 | 825.0 | 671.9 | 20429.7 | 44.50 → 44.50 | 50.11 → 49.13 | 0 |
| auto_ip_hit/64/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 167.8 | 406.0 | 394.5 | 6597.7 | 44.59 → 44.59 | 39.03 → 38.18 | 0 |

SQLite primary采样最大队列深度 100，最大队列等待 357.0ms，最大活动操作 5.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
