"""Offline summary of already copied, completed one-pair post5 stages."""
import datetime
import hashlib
import json
import argparse
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-dir', type=Path, default=Path(__file__).parent,
                    help='Directory containing case/results.json and case/manifest.json; offline only')
parser.add_argument('--plan-dir', type=Path, default=Path(__file__).parent / 'frozen-plan')
parser.add_argument('--output-prefix', type=Path, default=Path('/tmp/fn-knock-auth-post5-parameter-review'))
args = parser.parse_args()
root = args.input_dir.resolve()
plan = args.plan_dir.resolve()
jobs = {j['name']: j for j in json.loads((plan / 'jobs.json').read_text())}
pins = json.loads((plan / 'bundle-manifest.json').read_text())
names = [n for n in jobs if n.startswith(('grants-', 'explore-', 'profile-'))]
available = [n for n in names if (root / n / 'results.json').is_file()]
summary = {'schema_version': 1, 'purpose': 'Read-only post5 size/parameter/profile exploration',
           'updated_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'generator': {'path': str(Path(__file__).resolve()), 'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
           'remote_root': '/tmp/fn-knock-auth-performance-20260923/post5-all-final',
           'input_directory': str(root), 'plan_directory': str(plan),
           'expected_stages': names, 'missing_stages': [n for n in names if n not in available],
           'all_expected_stages_complete': len(available) == len(names),
           'profile_reader_4_complete': 'profile-reader-4' in available,
           'performance_acceptance': False, 'stages': [], 'input_files': {}}

def component(r, name):
    resource = r['resources'][name]
    return {'cpu_ms_per_success': resource['cpu_ms_per_1000_success'] / 1000,
            'average_cores': resource['cpu_seconds'] / (r['measurement']['elapsed_ms'] / 1000),
            'sampled_peak_rss_mib': resource['peak_rss_bytes'] / 1048576}

def differences(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        return [item for key in sorted(set(a) | set(b))
                for item in differences(a.get(key), b.get(key), path + '/' + key)]
    return [] if a == b else [{'path': path, 'baseline': a, 'candidate': b}]

def role(r):
    parts = {name: component(r, name) for name in ['go', 'rust', 'client', 'fixture']}
    total = {key: parts['go'][key] + parts['rust'][key] for key in parts['go']}
    profile = r.get('operation_profile')
    primary = None
    if profile:
        operations = profile['operations']
        execution = [o for o in operations if o['kind'] == 'sqlite_primary']
        admission = [o for o in operations if o['kind'] == 'sqlite_admission' and o['label'] == 'sqlite_primary']
        denominator = r['measurement']['successful_requests']
        primary = {'executor_calls_per_success': sum(o['calls'] for o in execution) / denominator,
                   'executor_wall_ms_per_success': sum(o['total_wall_ms'] for o in execution) / denominator,
                   'admission_wall_ms_per_success': sum(o['total_wall_ms'] for o in admission) / denominator if admission else None}
    return {'variant': r['variant'], 'rps': r['measurement']['successful_requests_per_second'],
            'p99_ms': r['measurement']['p99_ms'], 'successful_requests': r['measurement']['successful_requests'],
            'elapsed_ms': r['measurement']['elapsed_ms'], 'components': parts, 'service': total,
            'process_identity': {name: {'pid': r['resources'][name]['before']['pid'],
                                       'start_ticks': r['resources'][name]['before']['start_ticks']}
                                 for name in ['go', 'rust']},
            'operation_profile': profile, 'primary_profile': primary}

for name in names:
    if name not in available:
        continue
    stage = root / name
    result = json.loads((stage / 'results.json').read_text())
    manifest = json.loads((stage / 'manifest.json').read_text())
    for basename in ['results.json', 'manifest.json']:
        data = (stage / basename).read_bytes()
        summary['input_files'][name + '/' + basename] = {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    job = jobs[name]
    config = json.loads((plan / 'configs' / (job['config'] + '.json')).read_text())
    assert manifest['config'] == config, name + ': changed config'
    variant_differences = differences(config['baseline'], config['candidates'][0])
    if name.startswith(('explore-reader-', 'profile-reader-')):
        assert {d['path'] for d in variant_differences} == {'/name', '/env/FN_KNOCK_SQLITE_AUTH_READERS'}
    elif name.startswith('explore-compiler-'):
        assert {d['path'] for d in variant_differences} == {'/name', '/rust', '/metadata/opt_level', '/metadata/rust_opt_level'}
    variants = [config['baseline'], *config['candidates']]
    assert len(variants) == 2
    expected_identities = {(v['name'], component_name, v[component_name], pins['artifacts'][v[component_name]]['sha256'])
                           for v in variants for component_name in ['go', 'rust']}
    actual_identities = {(i['variant'], i['component'], i['path'], i['sha256']) for i in manifest['identities']}
    assert len(manifest['identities']) == 4 and actual_identities == expected_identities, name + ': identity role/path mismatch'
    for identity in manifest['identities']:
        assert identity['sha256'] == pins['artifacts'][identity['path']]['sha256'], name + ': changed binary'
    for identity in manifest['harness_identity']['files']:
        assert identity['sha256'] == pins['tools_snapshot_manifest']['files'][identity['name']], name + ': changed harness'
    assert manifest['harness_identity']['control_binary_sha256'] == '897cfef2a9f4b1fdf7330e66acbe7b4449945875fa2ac99ac9ab63632fc2d398'
    aliases = {'cache-ttl': 'cacheTtl', 'credential-kind': 'credentialKind', 'recovery-probe': 'recoveryProbe', 'profile-idle':'profileIdle'}
    for key, value in job['options'].items():
        expected = value.split(',') if key in ('routes', 'roles') else bool(value) if key in ('profile', 'recovery-probe') else value
        assert manifest['options'][aliases.get(key, key)] == expected, (name, key)
    rows = result['runs']
    routes = job['options']['routes'].split(',')
    expected = {(route, 0, side) for route in routes for side in ['baseline', 'candidate']}
    assert len(rows) == len(expected) and {(r['scenario'], r['pair'], r['role']) for r in rows} == expected
    assert len({r['directory'] for r in rows}) == len(rows)
    for r in rows:
        assert r['validation']['passed'] and r['measurement']['failures'] == 0
        assert all(r['quality'][k] for k in ['sampling_ok', 'health_ok', 'client_ok', 'duration_ok'])
        assert r['seed']['accounts'] == r['seed']['sessions'] == 1000
        assert r['seed']['ordinary_grants'] == job['options']['grants']
        assert r['seed']['total_grants'] == r['seed']['ordinary_grants']
        assert r['seed']['credential_kind'] == 'totp' and r['seed']['renewal_tokens_per_phase'] == 0
        for key in ['cache_control', 'cache_control_after']:
            assert r[key]['runtime_verified'] and r[key]['auth_cache_ttl_seconds'] == r[key]['auth_cache_unauthorized_ttl_seconds'] == 0
        assert r['effective_runtime_env']['FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT'] is None
        assert r['effective_runtime_env']['FN_KNOCK_TOKIO_WORKER_THREADS'] == '2'
        assert r['effective_runtime_env']['FN_KNOCK_RUNTIME_TARGET'] == 'linux'
        for tuning in ['GLIBC_TUNABLES','LD_PRELOAD','MALLOC_ARENA_MAX','GOMEMLIMIT','GOGC','GOMAXPROCS']:
            assert r['effective_runtime_env'][tuning] is None
        variant = config['baseline'] if r['role'] == 'baseline' else config['candidates'][0]
        assert r['variant'] == variant['name'] and r['candidate'] == config['candidates'][0]['name']
        assert r['concurrency'] == job['options']['concurrency']
        assert r['variant_metadata'] == variant['metadata'] and r['env'] == variant['env']
        assert r['effective_runtime_env']['FN_KNOCK_SQLITE_AUTH_READERS'] == variant['env'].get('FN_KNOCK_SQLITE_AUTH_READERS')
        for process in ['go', 'rust']:
            before, after = r['resources'][process]['before'], r['resources'][process]['after']
            assert (before['pid'],before['start_ticks']) == (after['pid'],after['start_ticks'])
    groups = []
    for route in routes:
        values = {r['role']: r for r in rows if r['scenario'] == route}
        comparison = next(c for c in result['comparison'] if c['key'].startswith(route + '/'))
        assert comparison['complete_pairs'] == 1 and comparison['incomplete_pairs'] == comparison['invalid_runs'] == comparison['duplicate_runs'] == 0
        groups.append({'scenario': route, 'baseline': role(values['baseline']), 'candidate': role(values['candidate']), 'comparison': comparison})
    summary['stages'].append({'name': name, 'options': manifest['options'], 'valid_trials': len(rows),
                             'identities': manifest['identities'],
                             'variant_metadata': {'baseline': config['baseline']['metadata'], 'candidate':config['candidates'][0]['metadata']},
                             'variant_differences': variant_differences,
                             'identity_and_workload_contract_passed': True,
                             'profiling': bool(job['options']['profile']), 'groups': groups})

large = next((s for s in summary['stages'] if s['name']=='grants-10000'), None)
large_note = ''
if large:
    g = large['groups'][0]
    large_note = f"grants10000的15秒窗口只有基线{g['baseline']['successful_requests']}/候选{g['candidate']['successful_requests']}次成功请求，P99尾部样本很少。"
stage_index = {s['name']: s for s in summary['stages']}
findings = []
reader4 = stage_index.get('explore-reader-4')
if reader4:
    g = next(g for g in reader4['groups'] if g['scenario'] == 'auto_ip_hit')
    c = g['comparison']
    cpu_change = g['candidate']['components']['rust']['cpu_ms_per_success'] / g['baseline']['components']['rust']['cpu_ms_per_success'] - 1
    findings.append(f"reader4的auto-IP出现明显单对回退：RPS{c['throughput_change_median']:+.1%}，P99{c['p99_change_median']:+.1%}，服务RSS{c['peak_rss_change_median']['combined']:+.1%}，Rust CPU/成功请求{cpu_change:+.1%}。grant/session收益不能抵消此路径风险，也不能证明其他并发/规模的结论。")
for level in ['s', '2', '3']:
    stage = stage_index.get('explore-compiler-' + level)
    if stage:
        rps = [g['comparison']['throughput_change_median'] for g in stage['groups']]
        rss = [g['comparison']['peak_rss_change_median']['combined'] for g in stage['groups']]
        findings.append(f"compiler {level}的四路RPS变化范围{min(rps):+.1%}至{max(rps):+.1%}，服务RSS变化{min(rss):+.1%}至{max(rss):+.1%}。这是速度与内存取舍，单对不能决定替换默认z。")
findings.append('所有探索只有1对；不据此调整reader1/z默认。profile只用于定位下一步调查方向，不能与无profile短测混合统计或声称正式收益验收。')
summary['findings'] = findings
lines = ['# post5 规模、参数与 profile 离线审阅', '',
         '仅离线读取各case的results.json/manifest.json，并验证完整trial集合；本次收集仅复制已完成并写入completed-cases的阶段。未访问业务端口、未启动负载。所有规模/参数组仅1对，不能作六对收益验收或据此改变默认。profile 与性能短测分开解读。', '',
         '规模组是旧base5→最终candidate5，c1；参数组是最终candidate5-z-reader1→单因素变体，c16。均TOTP、accounts/sessions1000、mobility关闭、正负TTL0、Tokio2、正常capacity无覆盖。非profile组每trial warm5/load15；1pair固定AB顺序，各组也有时间顺序，不能估计顺序偏差。'+large_note, '',
         '每组manifest.config与冻结对应config逐字段相同，完整四条variant/component/path/SHA身份与固定制品匹配；每trial角色名、metadata、env/有效env、并发和TTL均已核对。reader组只改变reader数量；compiler组只改变Rust路径及opt元数据，均以最终z/reader1为基线。未使用primary队列health字段推断auth reader队列。', '',
         'CPU ms/成功请求 = cpu_ms_per_1000_success / 1000；平均核数 = 进程CPU秒 / 实际请求窗口秒。包含同窗口后台CPU，不等于请求延迟。服务RSS是Go/Rust各自采样峰值之和，两峰不保证同时发生；不是VmHWM、空闲回收值或无泄漏证明。', '',
         '| 阶段/路由 | RPS 基线→候选 (变化) | P99 ms 基线→候选 (变化) | 服务RSS MiB 基线→候选 (变化) | Rust CPU ms/成功请求 | Go CPU ms/成功请求 |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
fmt = lambda x: 'null' if x is None else f'{x:.3f}'
pct = lambda x: f'{x*100:+.1f}%'
for stage in summary['stages']:
    if stage['profiling']:
        continue
    for g in stage['groups']:
        a,b,c = g['baseline'],g['candidate'],g['comparison']
        lines.append(f"| {stage['name']}/{g['scenario']} | {a['rps']:.2f}→{b['rps']:.2f} ({pct(c['throughput_change_median'])}) | {a['p99_ms']:.1f}→{b['p99_ms']:.1f} ({pct(c['p99_change_median'])}) | {a['service']['sampled_peak_rss_mib']:.2f}→{b['service']['sampled_peak_rss_mib']:.2f} ({pct(c['peak_rss_change_median']['combined'])}) | {fmt(a['components']['rust']['cpu_ms_per_success'])}→{fmt(b['components']['rust']['cpu_ms_per_success'])} | {fmt(a['components']['go']['cpu_ms_per_success'])}→{fmt(b['components']['go']['cpu_ms_per_success'])} |")
lines += ['', '## 单对探索观察', ''] + ['- ' + finding for finding in findings]
lines += ['', '## Profile（独立30秒capture、idle5秒）', '',
          '以下是进程级共享recorder的executor jobs与admission scopes，不是SQL statement数，也不保证都来自前景请求。所有auth reader slot共用recorder；kind=sqlite_auth_read 是执行，kind=sqlite_admission且label=sqlite_auth_read 是入场等待。checkpoint gate等待及提交到worker开始执行间的调度延迟不包含在这两类wall time内。primary数据按kind=sqlite_primary及admission同名label单独求和；不能从overall admission减auth推算primary，因为overall还包含其他reader。primary queue的health字段只属于primary，不代表auth pool；health ping来自另一reader。旧版没有admission instrumentation，null表示不可观测，不能读为零等待。累计wall/request可叠加多个job与并发等待，不是请求延迟分解百分比。idle5秒没有load期的周期health采样，不直接从load扣除idle值。', '',
          '执行wall/CPU包含SQLite闭包内查询、解析和投影等工作，并非只计SQL引擎耗时。profile中的吞吐带有instrumentation成本，不替代无profile短测。旧auto-IP路径没有观察到auth-reader执行，相关null不能推断为存在一条零成本auth查询。执行成本随reader增加的原因仍需进一步归因，本表不能单独确定是分配器、锁或CPU竞争。', '',
          '| 阶段/路由/角色 | auth jobs/成功请求 | auth执行wall ms/成功请求 | auth执行CPU ms/成功请求 | auth admission ms/成功请求 | primary jobs/成功请求 | primary admission ms/成功请求 | auth未结束scope | 总dropped |',
          '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for stage in summary['stages']:
    if not stage['profiling']:
        continue
    for g in stage['groups']:
        for side in ['baseline','candidate']:
            p=g[side]['operation_profile']; a=p['auth_reader']; primary=g[side]['primary_profile']
            lines.append(f"| {stage['name']}/{g['scenario']}/{side} | {fmt(a['executor_calls_per_success'])} | {fmt(a['executor_wall_ms_per_success'])} | {fmt(a['executor_cpu_ms_per_success'])} | {fmt(a['admission_wall_ms_per_success'])} | {fmt(primary['executor_calls_per_success'])} | {fmt(primary['admission_wall_ms_per_success'])} | {a['unfinished_scopes']} | {p['dropped_operations']} |")
profiles = [g[side]['operation_profile'] for s in summary['stages'] if s['profiling']
            for g in s['groups'] for side in ['baseline', 'candidate']]
lines += ['', f"已完成{len(profiles)}个profile capture；dropped总计{sum(p['dropped_operations'] for p in profiles)}，全部kind未结束scope总计{sum(p['unfinished_scopes'] for p in profiles)}。"]
lines += ['', '完成阶段：' + ', '.join(s['name'] for s in summary['stages']),
          '', '状态：' + ('profile-reader-4已完成，本审阅在此停止，不监测soak。' if summary['profile_reader_4_complete'] else '尚未到profile-reader-4结束；只列已完成阶段。'), '']
args.output_prefix.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
args.output_prefix.with_suffix('.md').write_text('\n'.join(lines))
print(json.dumps({'stages':[s['name'] for s in summary['stages']], 'trials':sum(s['valid_trials'] for s in summary['stages']), 'stopped':summary['profile_reader_4_complete']}))
