# post5 soak/recovery 离线复算

本目录保存从已完成 `post5-all-final` 读取的六份JSON、其SHA256、冻结计划片段及纯离线生成脚本。没有复制大型soak raw文件或二进制，也没有访问业务端口、启动实验或修改远端。

在任意本机位置运行：

```sh
python3 summarize.py --input-dir /absolute/COLLECTED \
  --output-dir /absolute/OUTPUT
```

输入目录须有以下相对路径：

```text
soak/results.json
soak/manifest.json
soak.soak-summary.json
recovery/results.json
recovery/manifest.json
recovery.validity.json
```

默认使用脚本旁 `frozen-plan/`，可用 `--plan-dir` 指定等价目录。脚本只读取本地JSON，核对固定config/制品身份、trial角色、有效env、TTL、计数和quality，再生成 `STABILITY-REVIEW.md`、`STABILITY-SUMMARY.json`。输入不完整或不满足本次固定合同会报错，不跳过失败；脚本不执行SSH、服务请求或负载。

RSS/FD/线程/goroutine中位数来自现成 `soak.soak-summary.json`；脚本仅核对其计数和首末5分钟桶的一致性，没有重新读取原始采样重算中位数。恢复时间按冻结 `auth-performance-recovery.mjs` 定义解释：burst阶段收尾以后开始计时，测量到一个完整两秒连续成功窗口结束，不是首次成功时刻。

CPU ms/成功请求为进程CPU秒×1000/成功请求数，平均核数为进程CPU秒/实际负载秒。已有comparison仅作原始证据保留；soak是单候选、recovery只有一对且容量被刻意压到32，均不替代正式性能验收。

`input-files.json` 记录最初收集的六个文件hash；输出JSON再次记录输入hash与生成器hash。冻结manifest把source与binary相联，这是声明及构建证据，不是从二进制反推源码。运行时manifest只记录8个直接使用的harness/helper，外层suite/check/report四个脚本没有运行时hash字段；本分析只声称已核对可观察的8个和control binary。

本复跑包的 recovery/results.json 有20处自由文本按收集器规则脱敏；数值及状态字段保留。source-input-files.json 记录原始六文件哈希，collection-hashes.json 记录原始到包内文件的哈希映射。重生成后的报告正文与原分析逐字节一致，JSON仅输入文件哈希变化；完整原始指标另在最终证据归档中提供。
