# audit6 后半段只读监测和离线复跑

**最终收尾状态：TTL1六对12trial已完成并通过；用户要求尽快收尾，soak按用户请求中止，未作30分钟完成验收，recovery未执行。整批audit6不标passed。收到收尾指令后已停止远端读取；停止后的outcome和清理证据由root另存，本包不伪造该证据。**

本目录只分析 Go4d → Go669 审计修复的增量：Rust 源码同为5fdd，仅随对应 Go commit 重新绑定构建。它不替代原92/d4 → 优化候选的收益证据，也不把历史273个trial算到修复后的产品。

冻结合同副本在 `frozen-plan/`，manifest SHA256 为 `87e69d8e1dedce80e7ddb6ea574fa1145975123cdca60b3b662f0637a78002ce`。`frozen-tools/` 是从本仓复制并按合同核验的12个脚本，统计仍调用原 `compareRuns` / `comparisonFailures` / `summarizeSoak`；未重写bootstrap或修改门槛。

范围为 `session-ttl1` 六对12trial、`soak-ttl1` 单候选30分钟1trial、`recovery` 双角色2trial，共15trial。前半段的30trial由root另行复核；batch outcome覆盖45trial，但不能替代本报告范围外的逐行验收。

## 只读收集

以下命令仅从指定远端目录读取固定JSON、Markdown和完成标记；不会向远端写入、访问业务端口或启动负载。`status`可在运行中调用；`collect`必须等该阶段outcome存在，即使失败也保留outcome和已有文件。不自动重跑负载。

```sh
python3 -B pull.py status
python3 -B pull.py collect --case session-ttl1
python3 -B pull.py collect --case soak-ttl1
python3 -B pull.py collect --case recovery
python3 -B pull.py batch
```

soak完成后额外读取 `results.json` 中唯一、严格位于固定case目录的 `result.json`，用于本地复算趋势；其他trial不额外下载大型raw。`source-files.json`保存源绝对路径、SHA256、大小和逐字节收集SHA。文件保存在 `inputs/`；重复收集只接受完全相同的已完成内容。不存在的可选sidecar不会被伪造成空结果。

`status/` 是只读观察快照，不参与收益计算。状态写入时刻可能正遇到远端 `results.json` 写入，需要稍后重新观察；读取异常不等于产品失败。

## 完全离线复跑

```sh
node analyze.mjs --partial   # 已收集阶段，不能声称整批通过
node analyze.mjs             # 本收尾包会拒绝：soak/recovery及整批完成证据缺失
```

支持独立的归档目录；默认值均相对于分析脚本所在目录，不依赖旧 `/tmp` 位置：

```sh
node /path/to/analyze.mjs \
  --input-dir /archive/inputs \
  --plan-dir /archive/frozen-plan \
  --tools-dir /archive/frozen-tools \
  --source-index /archive/source-files.json \
  --out /local/replayed-analysis
```

默认输入布局保留原case相对路径，如 `INPUT/session-ttl1/results.json`、`INPUT/session-ttl1.outcome.json`、`INPUT/soak-ttl1/<trial>/result.json`，以及batch的 `outcome.json`、`prepared-manifest.json`。也支持root统一collector的布局：case sidecar为 `INPUT/session-ttl1/{outcome,contract,gate}.json`，batch文件位于 `INPUT/support/`。`raw_result_file` 字段保持原远端绝对路径，不会尝试打开远端绝对路径。

`--source-index`接受本地 `source-files.json`（相对输入名到 `{source_path, source_sha256, collected_sha256, bytes, byte_preserved:true}` 的映射），或者root的 `collection.json`（`collected[]`包含 `source, relative, source_sha256, collected_sha256, source_bytes, collected_bytes`）。后者按照 `source` 去除冻结 `remote_batch` 前缀，再用 `relative` 映射到 `--input-dir`。输入核对收集SHA；outcome中的源证据核对源SHA。JSON重编码/脱敏可能使二者不同，不强行把收集SHA当作原文件SHA。

输出 `analysis[-partial]/{TAIL-REVIEW.md,TAIL-SUMMARY.json}` 及本地重跑的合同报告。输入SHA、冻结配置和工具SHA、每trial身份/TTL/seed/进程、outcome与合同、原门槛、soak raw/aggregate/summary一致性均检查。只计算每请求CPU毫秒与平均核数等描述指标；RPS/P99配对区间复用冻结工具，CPU和资源趋势不新增统计门槛。

本次实际只运行TTL1检查，未执行soak raw重算或恢复验收。`completion-note.json`是root转达用户收尾指令的本地说明，不是远端测量结果。最小复跑包不含SSH收集器或运行中状态快照；仅需Node和Python3标准库，使用 `node analyze.mjs --partial`。

`recovery_elapsed_ms` 包含完整两秒连续成功窗，起点在burst worker排空与阶段收尾以后；它不是第一次请求恢复延迟。503只表示实际观察到拒绝压力，不能确定容量拒绝在哪层。稳定session负载没有主动注销，不能替代此次修复的确定性并发回归测试。
