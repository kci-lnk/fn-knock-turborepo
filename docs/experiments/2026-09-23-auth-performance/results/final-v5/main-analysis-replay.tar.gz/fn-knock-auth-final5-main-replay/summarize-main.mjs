import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { compareRuns, comparisonFailures } from './auth-performance-lib.mjs';

const dir = path.dirname(fileURLToPath(import.meta.url));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const inputs = {};
const read = async (name) => {
  const bytes = await readFile(path.join(dir, name));
  inputs[name] = { sha256: sha(bytes), bytes: bytes.length };
  return JSON.parse(bytes);
};
const result = await read('results.json');
const manifest = await read('manifest.json');
const acceptance = await read('acceptance.json');
const libPath = path.join(dir, 'auth-performance-lib.mjs');
const libSha = sha(await readFile(libPath));
assert.equal(libSha, manifest.harness_identity.files.find(x => x.name === 'auth-performance-lib.mjs').sha256);
assert.equal(inputs['results.json'].sha256, acceptance.inputs.results.sha256);
assert.equal(inputs['manifest.json'].sha256, acceptance.inputs.manifest.sha256);
assert.equal(acceptance.passed, true);
assert.equal(acceptance.phase, 'main');
assert.deepEqual(acceptance.failures, []);
const runs = result.runs;
const comparisons = compareRuns(runs);
assert.deepEqual(comparisons, result.comparison);
assert.equal(runs.length, 108);
assert.equal(comparisons.length, 9);
const routes = acceptance.expected.routes;
const targets = acceptance.expected.target_routes;
const median = (a) => {
  assert.ok(a.length && a.every(Number.isFinite));
  const sorted = [...a].sort((x,y) => x-y);
  return sorted.length % 2 ? sorted[sorted.length >> 1] : (sorted[sorted.length/2-1] + sorted[sorted.length/2])/2;
};
const sum = a => a.reduce((x,y) => x+y,0);
const statuses = (rows, phase='measurement') => rows.reduce((out,row) => {
  const measurement = phase === 'measurement' ? row.measurement : row.warmup.measurement;
  for(const [code,count] of Object.entries(measurement.statuses)) out[code]=(out[code]??0)+count;
  return out;
}, {});
const identities = manifest.identities;
const processRecords = [];
const processIdentities = {go:new Set(), rust:new Set(), client:new Set(), fixture:new Set()};
const directories = new Set();
const roleVariants = {baseline:manifest.config.baseline, candidate:manifest.config.candidates[0]};
for (const row of runs) {
  assert.ok(routes.includes(row.scenario));
  assert.equal(row.validation.passed, true);
  assert.equal(row.measurement.failures, 0);
  assert.equal(row.warmup.measurement.failures, 0);
  assert.equal(row.measurement.latency_overflow, 0);
  assert.equal(row.measurement.anomalies.length, 0);
  assert.ok(['sampling_ok','health_ok','client_ok','duration_ok'].every(k => row.quality[k] === true));
  assert.ok(!directories.has(row.directory)); directories.add(row.directory);
  const variant = roleVariants[row.role];
  assert.equal(row.variant, variant.name);
  assert.deepEqual(row.variant_metadata, variant.metadata);
  assert.deepEqual(row.env, variant.env);
  assert.equal(row.effective_runtime_env.FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT, null);
  assert.equal(row.effective_runtime_env.FN_KNOCK_TOKIO_WORKER_THREADS, '2');
  assert.equal(row.effective_runtime_env.FN_KNOCK_SQLITE_AUTH_READERS, row.role === 'candidate' ? '1' : null);
  for(const name of ['cache_control','cache_control_after']) {
    assert.equal(row[name].runtime_verified,true);
    assert.equal(row[name].auth_cache_ttl_seconds,0);
    assert.equal(row[name].auth_cache_unauthorized_ttl_seconds,0);
  }
  const processes = {};
  for(const component of ['go','rust','client','fixture']) {
    const resource = row.resources[component];
    assert.equal(resource.before.pid,resource.after.pid);
    assert.equal(resource.before.start_ticks,resource.after.start_ticks);
    assert.equal(resource.before.pid,row.warmup.resources[component].after.pid);
    assert.equal(resource.before.start_ticks,row.warmup.resources[component].after.start_ticks);
    const key = `${resource.before.pid}:${resource.before.start_ticks}`;
    if(component==='go'||component==='rust') assert.ok(!processIdentities[component].has(key));
    processIdentities[component].add(key);
    assert.ok(Math.abs(resource.cpu_ms_per_1000_success / 1000 - resource.cpu_seconds * 1000 / row.measurement.successful_requests) < 1e-9);
    processes[component] = {pid:resource.before.pid,start_ticks:resource.before.start_ticks,stable_before_after:true};
  }
  processRecords.push({scenario:row.scenario,pair:row.pair,role:row.role,directory:row.directory,processes});
}

const groups = routes.map(route => {
  const group = comparisons.find(c => c.key.startsWith(route+'/'));
  const recorded = acceptance.comparison.find(c => c.key === group.key);
  for (const key of Object.keys(group)) assert.deepEqual(group[key], recorded[key]);
  const gate = targets.includes(route) ? 'improvement' : 'no_regression';
  const failures = comparisonFailures([group], {requireSixPairs:true,requireImprovement:gate==='improvement'});
  assert.deepEqual(failures,[]);
  assert.equal(recorded.gate,gate);
  const roles = {};
  for(const role of ['baseline','candidate']) {
    const rows = runs.filter(r=>r.scenario===route && r.role===role).sort((a,b)=>a.pair-b.pair);
    assert.deepEqual(rows.map(r=>r.pair),[0,1,2,3,4,5]);
    const values = read => rows.map(read);
    const metric = read => {const samples=values(read);return {median:median(samples),samples};};
    roles[role] = {
      successful_rps:metric(r=>r.measurement.successful_requests_per_second),
      p99_ms:metric(r=>r.measurement.p99_ms),
      elapsed_ms:metric(r=>r.measurement.elapsed_ms),
      successful_requests_total:sum(values(r=>r.measurement.successful_requests)),
      failed_requests_total:sum(values(r=>r.measurement.failures)),statuses:statuses(rows),
      components:Object.fromEntries(['go','rust','client','fixture'].map(component => [component,{
        cpu_ms_per_success:metric(r=>r.resources[component].cpu_ms_per_1000_success/1000),
        cpu_seconds:metric(r=>r.resources[component].cpu_seconds),
        average_cores:metric(r=>r.resources[component].cpu_seconds/(r.measurement.elapsed_ms/1000)),
        sampled_peak_rss_bytes:metric(r=>r.resources[component].peak_rss_bytes),
        end_rss_bytes:metric(r=>r.resources[component].end_rss_bytes),
      }])),
      combined_service_sampled_peak_rss_bytes:metric(r=>r.resources.go.peak_rss_bytes+r.resources.rust.peak_rss_bytes),
      service_cpu_ms_per_success:metric(r=>(r.resources.go.cpu_ms_per_1000_success+r.resources.rust.cpu_ms_per_1000_success)/1000),
      service_average_cores:metric(r=>(r.resources.go.cpu_seconds+r.resources.rust.cpu_seconds)/(r.measurement.elapsed_ms/1000)),
    };
  }
  return {scenario:route,gate,gate_passed:true,comparison:group,roles,
    ratio_of_role_medians_change:{successful_rps:roles.candidate.successful_rps.median/roles.baseline.successful_rps.median-1,p99_ms:roles.candidate.p99_ms.median/roles.baseline.p99_ms.median-1},
    paired_cpu_ms_per_success_change:Object.fromEntries(['go','rust','client'].map(component=>{
      const before=roles.baseline.components[component].cpu_ms_per_success.samples;
      const after=roles.candidate.components[component].cpu_ms_per_success.samples;
      const samples=before.map((value,index)=>after[index]/value-1);
      return [component,{samples,median:median(samples),confidence_interval:null}];
    })),
  };
});
const summary = {
  schema_version:1, purpose:'Offline final v5 main matrix analysis; no new load',
  inputs, generator:{path:fileURLToPath(import.meta.url),sha256:sha(await readFile(fileURLToPath(import.meta.url)))}, statistical_implementation:{path:libPath,sha256:libSha,functions:['compareRuns','comparisonFailures'],comparison_matches_input_and_acceptance:true,bootstrap_reimplemented:false},
  acceptance:{passed:acceptance.passed,phase:'main',target_groups:6,guard_groups:3,failures:[]},
  manifest_options:manifest.options,host:manifest.host,identities,harness_identity:manifest.harness_identity,
  source_metadata:Object.fromEntries(Object.entries(roleVariants).map(([role,v])=>[role,v.metadata])),
  method:{role_medians:'unweighted medians of six independent trial metrics; not pooled request percentiles',paired_change:'median(candidate_i/baseline_i-1), i=pair0..5',paired_ci:'copied/recomputed through frozen compareRuns, no new bootstrap implementation',cpu_ms_per_success:'process CPU seconds *1000 / successful requests; includes synchronous and background work in snapshot window',average_cores:'process CPU seconds / request measurement elapsed seconds; 1.0 means approximately one core continuously occupied, not a configured thread/core count',rss:'sampled RSS peaks; service combined is sum of Go/Rust per-trial peaks, which need not occur simultaneously',p99:'trial percentile from 1 ms histogram; table shows median of six such values',success:'scenario-defined semantic success, including expected HTTP302 for miss guards',db_freshness:'unique trial directories plus frozen harness creation contract; no independent database-content attestation'},
  quality:{trials:108,valid_trials:108,load_successful_requests:sum(runs.map(r=>r.measurement.successful_requests)),load_failures:0,warmup_failures:0,load_statuses:statuses(runs),warmup_statuses:statuses(runs,'warmup'),latency_overflow:0,load_anomalies:0,
    load_elapsed_ms:{min:Math.min(...runs.map(r=>r.measurement.elapsed_ms)),max:Math.max(...runs.map(r=>r.measurement.elapsed_ms))},
    maximum_sampling_gap_ms:Math.max(...runs.map(r=>r.quality.max_sampling_gap_ms)),
    maximum_client_event_loop_delay_ms:Math.max(...runs.map(r=>r.measurement.client_event_loop_delay_max_ms)),
    maximum_client_start_delay_ms:Math.max(...runs.map(r=>r.measurement.client_start_delay_max_ms)),
    process_sample_observations:sum(runs.map(r=>r.observation_counts.process_samples)),health_sample_observations:sum(runs.map(r=>r.observation_counts.health_samples)),timeout_phase_event_count:sum(runs.map(r=>r.observation_counts.timeout_phase_events)),
    unique_trial_directories:directories.size,unique_processes:Object.fromEntries(Object.entries(processIdentities).map(([name,set])=>[name,set.size])),warmup_to_load_and_load_before_after_process_identity_stable:true,
    ttl_before_and_after_zero_all_trials:true,normal_capacity_override_absent_all_trials:true,raw_trial_timeseries_available_locally:false},
  chronology:{first_trial_started_at:runs[0].started_at,last_trial_started_at:runs.at(-1).started_at,last_requests_finished_at:new Date(Math.max(...runs.map(r=>r.requests_finished_at_epoch_ms))).toISOString()},
  groups,process_identity_records:processRecords,
};
const fmt=(v,d=1)=>v.toFixed(d), pct=v=>`${v>=0?'+':''}${fmt(v*100)}%`, interval=a=>a.map(pct).join(' … ');
const lines=[
  '# 最终 v5 主矩阵分析', '',
  '**108/108 trial 有效；六个目标组通过收益门槛，三个保护组通过回归门槛。** 所有结论仅针对本次固定合成配置。复用冻结 `compareRuns` / `comparisonFailures`，结果与原 `results.json` 及 `acceptance.json` 逐字段一致，未重写 bootstrap、未新增负载。', '',
  '配置：c16、最多2个客户端 Worker（实际8+8）、TOTP、1000 accounts / 1000 sessions / 100 grants、mobility关闭、正负缓存TTL0；每trial预热20秒、测量60秒；六对交替AB/BA。Rust z/fat LTO/CGU1、候选reader1、Tokio workers2；bridge容量未覆盖（Go默认1024、当前四CPU Linux Rust默认64）。', '',
  '## 成功吞吐与尾延迟', '',
  '两端绝对值分别是六个trial的中位数；变化和95%区间来自同编号配对的相对变化。两端中位数的比值不是配对变化中位数，不能混用。P99来自1ms直方图；下表是六个trial P99的中位数，不是把全部请求合并后的P99。', '',
  '| 路由 | 门槛 | RPS 基线→候选 | 配对吞吐变化 [95%] | P99 ms 基线→候选 | 配对P99变化 [95%] |',
  '| --- | --- | ---: | --- | ---: | --- |',
];
for(const g of groups)lines.push(`| ${g.scenario} | ${g.gate==='improvement'?'收益通过':'保护通过'} | ${fmt(g.roles.baseline.successful_rps.median)} → ${fmt(g.roles.candidate.successful_rps.median)} | ${pct(g.comparison.throughput_change_median)} [${interval(g.comparison.throughput_change_bootstrap_95)}] | ${fmt(g.roles.baseline.p99_ms.median)} → ${fmt(g.roles.candidate.p99_ms.median)} | ${pct(g.comparison.p99_change_median)} [${interval(g.comparison.p99_change_bootstrap_95)}] |`);
lines.push('', 'challenge 是 challenge/signature 生成API，不验证一次完整登录；session_miss 是不断变化的无效session cookie，预期302且不得到达业务上游。“成功请求”表示符合这些场景语义，不能当作成功授权数量。两者吞吐区间均跨零，P99未变化，结论是通过回归保护，不能声称显著加速。grant_miss 虽改善明显，仍是预声明保护组，不事后升级为目标组。', '');
for(const name of ['challenge','session_miss']) {const g=groups.find(g=>g.scenario===name);lines.push(`- ${name}：吞吐两个中位数的比值变化为 ${pct(g.ratio_of_role_medians_change.successful_rps)}，配对变化中位数为 ${pct(g.comparison.throughput_change_median)}；验收采用后者。`);}
lines.push('', '## RSS', '', '以下为负载窗口采样峰值，不是生命周期VmHWM、空闲回收值或无泄漏证明。合计先在每个trial加Go与Rust各自峰值，再求中位数；两峰可能不同时发生。配对RSS变化来自现有比较器；本工具未为RSS新增置信区间。', '', '| 路由 | Go峰值MiB 基线→候选 | Rust峰值MiB 基线→候选 | 合计峰值MiB 基线→候选 | 配对合计变化 |', '| --- | ---: | ---: | ---: | ---: |');
for(const g of groups){const pair=(read)=>`${fmt(read(g.roles.baseline)/1048576,2)} → ${fmt(read(g.roles.candidate)/1048576,2)}`;const delta=g.comparison.peak_rss_change_median.combined;lines.push(`| ${g.scenario} | ${pair(r=>r.components.go.sampled_peak_rss_bytes.median)} | ${pair(r=>r.components.rust.sampled_peak_rss_bytes.median)} | ${pair(r=>r.combined_service_sampled_peak_rss_bytes.median)} | ${delta>=0?'+':''}${fmt(delta*100,2)}% |`);}
lines.push('', '## CPU 成本及平均占用核数', '', '每格均为六个trial中位数；CPU毫秒/成功请求由进程CPU差值归一化，不是请求延迟，也不区分前景请求与同窗口后台任务。平均核数=进程CPU秒/请求窗口实际秒数，1.0约等于持续占用一个核；不是线程数或配置核数。客户端CPU包括Node主进程、Worker和采样工作；fixture另计于JSON。CPU来自/proc时钟tick（本次HZ=100），不做线程级归因。未为CPU新增置信区间。', '', '| 路由 | Go CPU ms/请求 基线→候选 | Rust CPU ms/请求 基线→候选 | 客户端 CPU ms/请求 基线→候选 | Go平均核数 基线→候选 | Rust平均核数 基线→候选 | 客户端平均核数 基线→候选 |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: |');
for(const g of groups){const cell=(component,metric)=>`${fmt(g.roles.baseline.components[component][metric].median,3)} → ${fmt(g.roles.candidate.components[component][metric].median,3)}`;lines.push(`| ${g.scenario} | ${cell('go','cpu_ms_per_success')} | ${cell('rust','cpu_ms_per_success')} | ${cell('client','cpu_ms_per_success')} | ${cell('go','average_cores')} | ${cell('rust','average_cores')} | ${cell('client','average_cores')} |`);}
lines.push('', '吞吐提高后，单位请求CPU下降与每秒占用核数上升可以同时发生。Go并非所有场景都降低单位成本：auto_ip_miss应保留其上升观察，不能把总体收益归为两进程每条路由都更省CPU。不同路由流量协议不同，不把各路由RPS或百分比相加。CPU表反映进程总量，不能据此把提升百分比分摊给某个Go/Rust优化提交。', '', '## 质量、身份和证据边界', '',
  `- 负载期共 ${summary.quality.load_successful_requests.toLocaleString('en-US')} 次符合预期的请求，错误0；预热错误0、直方图溢出0、anomaly0。负载状态码合计：${JSON.stringify(summary.quality.load_statuses)}。`,
  `- 实际负载时长 ${fmt(summary.quality.load_elapsed_ms.min/1000,3)}–${fmt(summary.quality.load_elapsed_ms.max/1000,3)}秒；最大采样间隔 ${fmt(summary.quality.maximum_sampling_gap_ms,3)}ms，最大客户端事件循环延迟 ${fmt(summary.quality.maximum_client_event_loop_delay_ms,3)}ms，最大启动偏差 ${fmt(summary.quality.maximum_client_start_delay_ms,3)}ms；108组quality全部通过。`,
  `- 共 ${summary.quality.process_sample_observations} 次process采样和 ${summary.quality.health_sample_observations} 次health观察；摘要记录timeout phase事件 ${summary.quality.timeout_phase_event_count}。本地三份输入不含108份raw时序/日志，不能复核队列峰值、缓存health的独立性或据无事件断言没有等待。`,
  '- 108个独立trial目录、108个不同Go进程身份和108个不同Rust进程身份（PID+start_ticks）；每个进程在warmup结束至load结束身份稳定。客户端和fixture各复用一个进程；不能说所有组成进程每trial均重启。目录唯一及冻结harness流程支持独立DB设置，但这里未另检每个DB文件内容。',
  '- 所有trial的前后gRPC读回均确认正负TTL0；capacity override缺省，候选reader1；role metadata与manifest一致。制品源SHA来自构建/manifest记录，二进制哈希用于核对，不声称能从二进制反推源码。',
  '', '| 角色 | Rust源码 | Go源码 |', '| --- | --- | --- |',
  ...Object.entries(roleVariants).map(([role,v])=>`| ${role} | \`${v.metadata.main_commit}\` | \`${v.metadata.go_commit}\` |`),
  '', '| 变体/组件 | SHA256 |', '| --- | --- |', ...identities.map(i=>`| ${i.variant}/${i.component} | \`${i.sha256}\` |`),
  '', `记录的请求窗口最后结束时间：${summary.chronology.last_requests_finished_at}。主矩阵只证明上述c16/规模/TTL0配置；不能代替缓存开启、有限续期、单因素编译/reader、其他并发、故障恢复或30分钟持续负载。也不能由mobility关闭的HTTP结果归因到mobility开启的旧N+1方法诊断。`,
  '', '## 可复核文件', '', '- [汇总JSON](MAIN-SUMMARY.json) 保留每组两端六样本、配对统计、CPU/RSS、全部进程身份和输入hash。', '- [生成脚本](summarize-main.mjs) 仅读取本目录三个输入和冻结统计库；运行 `node summarize-main.mjs` 可复算本片段。', '- [results.json](results.json)、[manifest.json](manifest.json)、[acceptance.json](acceptance.json) 保持原样。',
);
await writeFile(path.join(dir,'MAIN-SUMMARY.json'),JSON.stringify(summary,null,2)+'\n');
await writeFile(path.join(dir,'MAIN-ANALYSIS.md'),lines.join('\n')+'\n');
console.log(JSON.stringify({trials:runs.length,groups:groups.length,acceptance_passed:true,artifacts:['MAIN-ANALYSIS.md','MAIN-SUMMARY.json'],input_sha256:Object.fromEntries(Object.entries(inputs).map(([k,v])=>[k,v.sha256]))},null,2));
