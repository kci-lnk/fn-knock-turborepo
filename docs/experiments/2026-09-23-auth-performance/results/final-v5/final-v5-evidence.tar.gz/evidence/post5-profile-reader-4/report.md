# 鉴权性能实验结果

记录 4 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| grant_hit/16/candidate5-z-reader4/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +58.4% | -26.1% | 不足6对 | 不足6对 | +0.5% | +4.4% | +2.4% |
| auto_ip_hit/16/candidate5-z-reader4/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -10.7% | +35.0% | 不足6对 | 不足6对 | +1.6% | +20.5% | +10.9% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| grant_hit/16/candidate5-z-reader4/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 1033.8 | 23.0 | 543.3 | 1024.2 | 40.73 → 39.91 | 35.70 → 35.68 | 0 |
| grant_hit/16/candidate5-z-reader4/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1637.1 | 17.0 | 374.4 | 1285.9 | 40.96 → 40.46 | 37.28 → 37.28 | 0 |
| auto_ip_hit/16/candidate5-z-reader4/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 174.1 | 103.0 | 464.4 | 6378.1 | 39.48 → 39.48 | 37.84 → 37.23 | 0 |
| auto_ip_hit/16/candidate5-z-reader4/cache-0/profile-on/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 155.5 | 139.0 | 509.4 | 14364.3 | 40.13 → 39.72 | 45.59 → 42.29 | 0 |

| 路由 / 角色 | executor调用/成功请求 | executor wall ms/成功请求 | executor CPU ms/成功请求 | admission等待 ms/成功请求 | idle executor调用/秒 |
| --- | ---: | ---: | ---: | ---: | ---: |
| candidate5-z-reader4/grant_hit/baseline/pair1 | 2.004 | 0.636 | 0.616 | 13.421 | 1.399 |
| candidate5-z-reader4/grant_hit/candidate/pair1 | 2.003 | 1.900 | 1.003 | 5.527 | 4.996 |
| candidate5-z-reader4/auto_ip_hit/baseline/pair1 | 3.028 | 4.614 | 4.536 | 79.211 | 2.798 |
| candidate5-z-reader4/auto_ip_hit/candidate/pair1 | 3.032 | 21.655 | 12.197 | 64.922 | 2.798 |

| 路由 / 角色 | auth reader调用/成功请求 | auth reader wall ms/成功请求 | auth reader CPU ms/成功请求 | auth reader admission等待 ms/成功请求 | idle auth reader调用/秒 |
| --- | ---: | ---: | ---: | ---: | ---: |
| candidate5-z-reader4/grant_hit/baseline/pair1 | 2.000 | 0.635 | 0.615 | 13.421 | n/a |
| candidate5-z-reader4/grant_hit/candidate/pair1 | 2.000 | 1.899 | 1.002 | 5.527 | n/a |
| candidate5-z-reader4/auto_ip_hit/baseline/pair1 | 3.000 | 4.606 | 4.530 | 79.211 | n/a |
| candidate5-z-reader4/auto_ip_hit/candidate/pair1 | 3.000 | 21.636 | 12.189 | 64.922 | n/a |

Operation recorder统计进程内executor job scope，包含同一捕获窗口的背景操作；每成功请求归一化不等于每请求精确SQL条数。一次executor job可能执行多条SQL。idle频率保留作背景参照，不自动扣减。profiling会增加开销，应另跑关闭profiling的性能A/B。
原overall executor合计primary与auth reader，overall admission合计全部入场label；auth_reader单独聚合全部auth reader slot，执行仅取kind=sqlite_auth_read，入场仅取kind=sqlite_admission且label=sqlite_auth_read。两者都不包含中间的checkpoint gate等待，也不提供逐slot分布；并行scope的累计wall可以超过捕获时长。旧报告缺少auth_reader时显示n/a。

SQLite primary采样最大队列深度 0，最大队列等待 0.0ms，最大活动操作 7.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
