#!/usr/bin/env python3
"""Offline path/collector-format tests; no new performance data or network."""
import hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(argv):
    p=subprocess.run([sys.executable,'-B',*map(str,argv)],capture_output=True,text=True)
    assert p.returncode==0,(argv,p.stdout,p.stderr)
    return p
def main():
    original=load(ROOT/'analysis/SUMMARY.json');assert original['status']=='passed'
    cases=[]
    with tempfile.TemporaryDirectory(prefix='audit6-offline-portability-') as temporary:
        tmp=Path(temporary);bundle=tmp/'unrelated-directory/bundle';bundle.mkdir(parents=True)
        for name in ['plan','tools','inputs']:shutil.copytree(ROOT/name,bundle/name)
        for name in ['summarize.py','adapt-collector.py']:shutil.copyfile(ROOT/name,bundle/name)
        run([bundle/'summarize.py'])
        relocated=load(bundle/'analysis/SUMMARY.json')
        assert relocated==original,'moving the bundle changed the independent result'
        cases.append({'case':'relocated_bundle_identical_summary','passed':True})
        # This fixture changes JSON encoding ONLY, as the standard collector
        # does. It is not a fresh collection or new performance observation.
        collector=tmp/'synthetic-collector';collector.mkdir()
        plan=load(bundle/'plan/manifest.json');mapping={'prepared-manifest.json':'support/prepared-manifest.json'}
        for case in ['smoke','session-ttl0']:
            for name in ['results.json','manifest.json']:mapping[f'{case}/{name}']=f'{case}/{name}'
            for name in ['outcome.json','contract.json','gate.json','report.md']:mapping[f'{case}.{name}']=f'{case}/{name}'
        records=[]
        for source_relative,collected_relative in mapping.items():
            source=ROOT/'inputs'/source_relative;dest=collector/collected_relative;dest.parent.mkdir(parents=True,exist_ok=True)
            if source.suffix=='.json':dest.write_text(json.dumps(load(source),ensure_ascii=False,separators=(',',':'))+'\n')
            else:shutil.copyfile(source,dest)
            records.append({'source':plan['remote_batch']+'/'+source_relative,'relative':collected_relative,'source_sha256':sha(source),'source_bytes':source.stat().st_size,'collected_sha256':sha(dest),'collected_bytes':dest.stat().st_size})
        assert any(r['source_sha256']!=r['collected_sha256'] for r in records)
        (collector/'collection.json').write_text(json.dumps({'synthetic_format_test_only':True,'collected':records},indent=2)+'\n')
        view=tmp/'mapped-view';run([bundle/'adapt-collector.py','--collection',collector,'--out',view])
        run([bundle/'summarize.py','--input',view,'--out',tmp/'mapped-analysis'])
        mapped=load(tmp/'mapped-analysis/SUMMARY.json')
        assert mapped['status']=='passed' and mapped['cases']==original['cases'],'collector encoding changed metrics/contracts/gates'
        cases.append({'case':'collector_source_and_normalized_hashes_distinct_same_results','passed':True})
        # A changed collected file must fail before a view is created.
        bad=collector/'smoke/results.json';bad.write_text(bad.read_text()+' ')
        p=subprocess.run([sys.executable,'-B',str(bundle/'adapt-collector.py'),'--collection',str(collector),'--out',str(tmp/'rejected-view')],capture_output=True,text=True)
        assert p.returncode!=0 and not (tmp/'rejected-view').exists()
        cases.append({'case':'changed_collected_bytes_rejected_before_copy','passed':True})
    print(json.dumps({'offline_format_tests_only':True,'original_evidence_modified':False,'network_access':False,'cases':cases},indent=2))
if __name__=='__main__':main()
