# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -1.3% | -3.6% | 不足6对 | 不足6对 | -0.7% | +0.7% | +0.0% |
| session_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +35.3% | -18.2% | 不足6对 | 不足6对 | -3.0% | +0.9% | -1.2% |
| grant_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +58.1% | -21.7% | 不足6对 | 不足6对 | +5.4% | +4.0% | +4.8% |
| auto_ip_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -7.9% | +33.3% | 不足6对 | 不足6对 | +4.4% | +20.3% | +12.2% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 394.8 | 56.0 | 411.4 | 3176.5 | 40.26 → 39.89 | 37.20 → 36.32 | 0 |
| bootstrap/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 389.8 | 54.0 | 374.0 | 3176.2 | 39.99 → 39.83 | 37.47 → 36.94 | 0 |
| session_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 488.5 | 44.0 | 467.6 | 2931.2 | 42.44 → 42.36 | 38.16 → 35.23 | 0 |
| session_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 660.8 | 36.0 | 455.6 | 2910.3 | 41.15 → 40.80 | 38.50 → 35.75 | 0 |
| grant_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 1040.0 | 23.0 | 539.2 | 1013.7 | 40.91 → 40.91 | 35.28 → 35.28 | 0 |
| grant_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1643.7 | 18.0 | 366.5 | 1276.1 | 43.13 → 42.75 | 36.71 → 36.66 | 0 |
| auto_ip_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 166.4 | 111.0 | 487.0 | 6658.7 | 39.21 → 39.21 | 37.48 → 36.63 | 0 |
| auto_ip_hit/16/candidate5-z-reader4/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 153.2 | 148.0 | 501.5 | 14556.9 | 40.93 → 40.93 | 45.09 → 42.11 | 0 |

SQLite primary采样最大队列深度 26，最大队列等待 11.0ms，最大活动操作 1.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
