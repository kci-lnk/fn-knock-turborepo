# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +3.4% | -17.2% | 不足6对 | 不足6对 | +5.7% | +7.1% | +6.4% |
| session_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +13.5% | -11.1% | 不足6对 | 不足6对 | -1.5% | +4.0% | +1.1% |
| grant_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +8.6% | -14.3% | 不足6对 | 不足6对 | +4.5% | +3.1% | +3.8% |
| auto_ip_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +24.8% | -16.8% | 不足6对 | 不足6对 | -0.2% | +5.1% | +2.4% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 385.3 | 64.0 | 426.7 | 3242.4 | 39.19 → 39.19 | 36.33 → 35.78 | 0 |
| bootstrap/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 398.5 | 53.0 | 447.7 | 3129.0 | 41.43 → 41.43 | 38.91 → 38.18 | 0 |
| session_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 479.1 | 45.0 | 483.3 | 2931.5 | 40.64 → 40.55 | 37.89 → 34.86 | 0 |
| session_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 543.9 | 40.0 | 463.9 | 2393.2 | 40.04 → 40.04 | 39.40 → 36.46 | 0 |
| grant_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 996.6 | 28.0 | 555.3 | 1041.2 | 39.52 → 39.52 | 35.31 → 35.18 | 0 |
| grant_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1082.6 | 24.0 | 543.4 | 942.8 | 41.28 → 41.24 | 36.42 → 36.39 | 0 |
| auto_ip_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 166.7 | 107.0 | 481.7 | 6648.1 | 39.12 → 38.89 | 38.02 → 37.16 | 0 |
| auto_ip_hit/16/candidate5-s-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 208.0 | 89.0 | 459.3 | 5202.6 | 39.03 → 38.97 | 39.95 → 39.09 | 0 |

SQLite primary采样最大队列深度 23，最大队列等待 13.0ms，最大活动操作 1.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
