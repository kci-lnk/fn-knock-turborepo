# post5 参数/profile 离线复算

`summarize.py` 只读取本地 JSON，不调用 SSH、数据库、服务或负载工具。输入为标准 case 目录结构：

```text
INPUT/
  grants-1000/results.json
  grants-1000/manifest.json
  grants-10000/...
  explore-reader-2/...
  explore-reader-4/...
  explore-compiler-s/...
  explore-compiler-2/...
  explore-compiler-3/...
  profile-primary/...
  profile-reader-2/...
  profile-reader-4/...
```

只分析已存在 results.json 的 case；已存在但不完整、无效或身份/参数不匹配的 case 会报错，不跳过失败。尚未复制的 case 不会被虚构为通过。`profile-reader-4` 完整时汇总标记停止，脚本不读取 soak/recovery。

```sh
python3 summarize.py --input-dir /absolute/COLLECTOR_CASES \
  --output-prefix /absolute/OUTPUT/post5-parameter-review
```

输出父目录须已存在，生成 `.md` 与 `.json`。默认冻结输入来自脚本旁 `frozen-plan/`，也可显式传 `--plan-dir`。这里复制的 plan/config/identity 文本逐字节来自已冻结 post5-plan；原目录和 scripts5 未被修改。输入 JSON 的 SHA256 记录于输出；运行时 source/binary 关联仍依赖原构建和manifest证据，不能从二进制反推源码。

相对RPS/P99/RSS变化直接使用结果中的原 `comparison`，不重写bootstrap、不增加统计验收。CPU ms/成功请求由 `cpu_ms_per_1000_success/1000`，平均核数由 `cpu_seconds/(elapsed_ms/1000)`；完整每进程指标保留在JSON。profile直接采用冻结工具的 `auth_reader` 分类，primary仅按明确kind/label筛选。job≠SQL、旧admission不可观测、checkpoint/调度间隙、背景及idle不可直接扣减等限制写入报告。

`pull.py` 是本次一次性 SSH 只读复制辅助程序，与离线分析分离；复算不需要它。它只复制 completed-cases 中已完成的JSON/报告到本机，不调用业务端口、不修改远端、不启动负载；本次读到 profile-reader-4 完成后停止调用。
