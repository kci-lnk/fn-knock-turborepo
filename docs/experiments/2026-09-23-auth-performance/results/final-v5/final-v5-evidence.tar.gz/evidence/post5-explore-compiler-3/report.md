# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +6.3% | +10.9% | 不足6对 | 不足6对 | -0.8% | +31.0% | +14.6% |
| session_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +22.8% | -15.9% | 不足6对 | 不足6对 | -0.3% | +33.9% | +16.5% |
| grant_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +15.3% | -13.0% | 不足6对 | 不足6对 | -0.1% | +34.8% | +16.3% |
| auto_ip_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +39.0% | -28.8% | 不足6对 | 不足6对 | -1.1% | +33.6% | +15.7% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 386.8 | 55.0 | 416.4 | 3188.2 | 38.98 → 38.80 | 36.82 → 36.46 | 0 |
| bootstrap/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 411.2 | 61.0 | 417.5 | 2968.1 | 38.66 → 38.63 | 48.24 → 47.74 | 0 |
| session_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 489.2 | 44.0 | 473.4 | 2886.7 | 39.52 → 39.46 | 38.15 → 35.06 | 0 |
| session_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 600.9 | 37.0 | 445.3 | 2161.1 | 39.40 → 39.40 | 51.09 → 48.12 | 0 |
| grant_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 1048.7 | 23.0 | 540.5 | 1006.7 | 39.70 → 38.92 | 35.46 → 35.46 | 0 |
| grant_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1209.3 | 20.0 | 513.4 | 842.3 | 39.64 → 39.58 | 47.79 → 47.76 | 0 |
| auto_ip_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 166.1 | 111.0 | 476.8 | 6614.6 | 39.99 → 39.90 | 37.64 → 36.78 | 0 |
| auto_ip_hit/16/candidate5-3-reader1/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 230.9 | 79.0 | 446.4 | 4686.1 | 39.54 → 39.54 | 50.27 → 49.40 | 0 |

SQLite primary采样最大队列深度 24，最大队列等待 10.0ms，最大活动操作 2.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
