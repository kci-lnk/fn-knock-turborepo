#!/usr/bin/env python3
"""Read-only post-experiment PID/start-time and owned-process check."""
import json,shlex,subprocess
from pathlib import Path
remote=r'''
import datetime,json,os,subprocess
from pathlib import Path
root='/tmp/fn-knock-auth-performance-20260923'
expected={7257:('Sat Sep 12 14:46:53 2026','go-reauth-proxy'),7676:('Sat Sep 12 14:46:54 2026','server-admin-rs'),761442:('Mon Sep 21 19:48:11 2026','go-reauth-proxy'),761490:('Mon Sep 21 19:48:12 2026','server-admin-rs')}
production=[]
for pid,(start,name) in expected.items():
 r=subprocess.run(['ps','-p',str(pid),'-o','lstart=,comm='],capture_output=True,text=True,env={**os.environ,'LC_ALL':'C'})
 fields=r.stdout.split();production.append({'pid':pid,'start_time_host_local':' '.join(fields[:5]) if fields else None,'program':' '.join(fields[5:]) if fields else None})
remaining=[]
owned_scripts={root+'/scripts5/auth-performance.mjs',root+'/scripts5/auth-performance-suite.mjs'}
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  exe=os.readlink(p/'exe');argv=(p/'cmdline').read_bytes().split(b'\0');args=[x.decode('utf8','replace') for x in argv if x]
  if exe.startswith(root+'/') or any(a in owned_scripts for a in args):remaining.append({'pid':int(p.name),'executable':exe,'kind':'owned binary' if exe.startswith(root+'/') else 'owned harness'})
 except (OSError,ProcessLookupError):pass
ok=all((x['start_time_host_local'],x['program'])==expected[x['pid']] for x in production)
print(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_pids_and_start_times_unchanged':ok,'production':production,'remaining_experiment_processes':remaining,'scope':'Read-only process evidence. The harness uses anonymous unshare --net namespaces; no persistent named network namespace is created.'},indent=2))
raise SystemExit(0 if ok and not remaining else 1)
'''
r=subprocess.run(['ssh','-oBatchMode=yes','-oConnectTimeout=10','root@192.168.31.98','python3 -B -c '+shlex.quote(remote)],capture_output=True,text=True)
print(r.stdout,end='')
if r.stderr:print(r.stderr,end='',file=__import__('sys').stderr)
raise SystemExit(r.returncode)
