#!/usr/bin/env python3
"""Prepared evidence collector. No load, service requests, remote writes or binaries.
Default: show. Explicit collect: read-only SSH export to a NEW local directory.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import stat
import subprocess
import sys

MAX_FILE_BYTES = 128 * 1024 * 1024
SAFE_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")
SENSITIVE = re.compile(r"(?:^|_)(?:secret|password|passwd|token|cookie|authorization|hmac|private_key|credential)(?:_|$)", re.I)
OPAQUE = re.compile(r"^(?:error|message|stack|stderr|stdout|body|request_body|response_body|request_headers|response_headers|headers)$", re.I)
LEAK = re.compile(r"-----BEGIN (?:[A-Z ]*PRIVATE KEY)|\b(?:Bearer|Basic)\s+[A-Za-z0-9+/_.=-]+|(?im:^\s*(?:set-cookie|cookie|authorization)\s*:)|\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|\b(?:authperf-session|authperf-grant)-(?:[A-Za-z0-9_.=-]+)")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()

def sensitive_key(key):
    normalized = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", key).replace("-", "_")
    # Kind labels are part of the workload; numeric credential/cookie counters remain intact.
    return key not in ("credential_kind", "credentialKind") and bool(SENSITIVE.search(normalized))

def sanitize(value, redact=False, counts=None):
    if counts is None:
        counts = [0]
    if isinstance(value, str):
        if redact or LEAK.search(value):
            counts[0] += 1
            return "[REDACTED]"
        return value
    if isinstance(value, list):
        return [sanitize(v, redact, counts) for v in value]
    if isinstance(value, dict):
        return {k: sanitize(v, redact or sensitive_key(k) or bool(OPAQUE.match(k)), counts) for k, v in value.items()}
    return value

def safe_relative(relative):
    p = PurePosixPath(relative)
    assert not p.is_absolute() and p.parts and all(SAFE_NAME.fullmatch(x) and x not in (".", "..") for x in p.parts), "unsafe destination path"
    return p

def safe_source(source, root):
    p, r = PurePosixPath(source), PurePosixPath(root)
    assert p.is_absolute() and ".." not in p.parts and p != r and r in p.parents, "source outside allowlisted root"
    current = Path(p.anchor)
    for component in p.parts[1:]:
        current /= component
        st = current.lstat()
        assert not stat.S_ISLNK(st.st_mode), "source has a symlink component"
    return Path(source)

def read_stable(source, root):
    p = safe_source(source, root)
    with p.open("rb") as stream:
        before = os.fstat(stream.fileno())
        assert stat.S_ISREG(before.st_mode) and before.st_size <= MAX_FILE_BYTES, "source is not a bounded regular file"
        data = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(stream.fileno())
    assert (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino), "file changed while reading"
    assert len(data) == before.st_size, "file length changed"
    return data

def remote_export(spec):
    root = spec["remote_root"]
    sent, missing = [], []
    def emit(value):
        print(json.dumps(value, ensure_ascii=False, allow_nan=False), flush=True)
    def export(source, relative, required=True):
        safe_relative(relative)
        try:
            data = read_stable(source, root)
        except FileNotFoundError:
            missing.append(dict(source=source, relative=relative, required=required))
            return
        redactions = [0]
        if source.endswith(".json"):
            collected = encode(sanitize(json.loads(data), counts=redactions))
        else:
            assert source.endswith((".md", ".txt", ".sh")), "unreviewed file type"
            # Text files are explicit reviewed generated reports/markers/frozen runners only.
            # Fail closed rather than retain text matching token/header/private-key patterns.
            text = data.decode("utf-8")
            assert not LEAK.search(text), "possible secret in allowlisted text; manual safe extract required"
            collected = data
        record = dict(source=source, relative=relative, source_sha256=sha(data), collected_sha256=sha(collected), source_bytes=len(data), collected_bytes=len(collected), redacted_strings=redactions[0])
        sent.append(record)
        emit(dict(kind="file", **record, content_base64=base64.b64encode(collected).decode()))
    for job in spec["jobs"]:
        output, name = job["output"], job["name"]
        assert SAFE_NAME.fullmatch(name)
        for leaf in ("results.json", "manifest.json"):
            export(output + "/" + leaf, name + "/" + leaf)
        for leaf in job["sidecars"]:
            export(output + "." + leaf, name + "/" + leaf)
        for leaf in job.get("optional_sidecars", []):
            export(output + "." + leaf, name + "/" + leaf, False)
        try:
            directory = safe_source(output, root)
            entries = sorted(directory.iterdir())
        except FileNotFoundError:
            entries = []
        for child in entries:
            assert not child.is_symlink(), "symlink entry in trial directory"
            if child.is_dir():
                assert SAFE_NAME.fullmatch(child.name)
                export(str(child / "result.json"), name + "/" + child.name + "/result.json", False)
    for item in spec["extras"]:
        export(item["source"], item["relative"], item["required"])
    changed = []
    for item in sent:
        try:
            if sha(read_stable(item["source"], root)) != item["source_sha256"]:
                changed.append(item["source"])
        except (FileNotFoundError, AssertionError):
            changed.append(item["source"])
    emit(dict(kind="end", collected=sent, missing=missing, sources_changed_during_collection=changed, source_consistency_checked=True))

def review(destination, spec):
    destination = Path(destination)
    index = json.loads((destination / "collection.json").read_text())
    errors, warnings, summaries = [], [], []
    def check(ok, message):
        if not ok:
            errors.append(message)
    by_source = {i["source"]: i for i in index["collected"]}
    by_relative = {i["relative"]: i for i in index["collected"]}
    index_hashes_path = destination / "INDEX-SHA256.json"
    if index_hashes_path.is_file():
        for filename, expected_hash in json.loads(index_hashes_path.read_text()).items():
            safe_relative(filename)
            check(sha((destination / filename).read_bytes()) == expected_hash, "index/review envelope hash mismatch: " + filename)
    check(len(by_relative) == len(index["collected"]), "duplicate collected path")
    check(index.get("source_consistency_checked") is True, "source consistency not checked")
    check(not index["sources_changed_during_collection"], "sources changed during collection")
    check(index.get("review_spec_sha256") == sha(encode(spec)), "review spec changed")
    master = index.get("master_plan", {})
    master_path = destination / "MASTER-COLLECTION-PLAN.json"
    check(master.get("source_sha256") == spec["plan_source_sha256"] and master_path.is_file() and sha(master_path.read_bytes()) == master.get("collected_sha256"), "master plan provenance mismatch")
    for item in index["collected"]:
        safe_relative(item["relative"])
        data = (destination / item["relative"]).read_bytes()
        check(sha(data) == item["collected_sha256"], "collected hash mismatch: " + item["relative"])
    for item in index["missing"]:
        if item["required"]:
            errors.append("required evidence missing: " + item["relative"])
    def load(relative):
        if relative not in by_relative:
            return None
        return json.loads((destination / relative).read_text())
    def check_gate_hashes(value, origin):
        if isinstance(value, dict):
            if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str):
                ref = by_source.get(value["path"])
                if ref is None:
                    errors.append("gate input not collected: " + origin + ": " + value["path"])
                else:
                    check(ref["source_sha256"] == value["sha256"], "gate/source hash mismatch: " + origin)
            for item in value.values():
                check_gate_hashes(item, origin)
        elif isinstance(value, list):
            for item in value:
                check_gate_hashes(item, origin)
    total = 0
    for job in spec["jobs"]:
        name, opts = job["name"], job["expected_options"]
        aggregate, manifest = load(name + "/results.json"), load(name + "/manifest.json")
        if aggregate is None or manifest is None:
            continue
        rows = aggregate.get("runs", [])
        total += len(rows)
        expected = {(route, pair, role) for route in opts["routes"] for pair in range(opts["pairs"]) for role in opts["roles"]}
        keys = [(r.get("scenario"), r.get("pair"), r.get("role")) for r in rows]
        check(len(rows) == job["expected_trials"] and set(keys) == expected and len(set(keys)) == len(keys), name + ": trial matrix incomplete/duplicate")
        for route in opts["routes"]:
            for pair in range(opts["pairs"]):
                observed_roles = [r["role"] for r in rows if r.get("scenario") == route and r.get("pair") == pair]
                roles = opts["roles"] if pair % 2 == 0 else list(reversed(opts["roles"]))
                check(observed_roles == roles, name + ": AB/BA order mismatch")
        for key, value in opts.items():
            check(manifest.get("options", {}).get(key) == value, name + ": manifest option mismatch: " + key)
        identities = manifest.get("identities", [])
        check(len(identities) == 4, name + ": expected four configured artifact identities")
        for identity in identities:
            check(spec["artifact_hashes"].get(identity["path"]) == identity["sha256"], name + ": artifact hash mismatch")
        harness = manifest.get("harness_identity", {})
        check(len(harness.get("files", [])) == 8, name + ": missing eight harness file identities")
        for item in harness.get("files", []):
            check(spec["tools_hashes"].get(item["name"]) == item["sha256"], name + ": tool hash mismatch")
        check(harness.get("control_binary_sha256") == spec["control_sha256"], name + ": control hash mismatch")
        raw_files = [r for r in by_relative if r.startswith(name + "/") and r.endswith("/result.json")]
        check(len(raw_files) == len(rows), name + ": raw/aggregate trial counts differ")
        valid, failed_requests, profiles, recoveries, raw_seen = 0, 0, 0, 0, set()
        for row in rows:
            raw_source = row.get("raw_result_file", row.get("directory", "") + "/result.json")
            item = by_source.get(raw_source)
            check(item is not None, name + ": raw trial missing")
            if item is None:
                continue
            raw_seen.add(raw_source)
            raw = load(item["relative"])
            for field in ("scenario", "pair", "role", "measurement", "resources", "quality", "validation", "seed", "cache_control", "cache_control_after"):
                check(raw.get(field) == row.get(field), name + ": raw/aggregate mismatch: " + field)
            config = manifest.get("config", {})
            variant = config.get("baseline", {}) if row.get("role") == "baseline" else (config.get("candidates") or [{}])[0]
            check(raw.get("variant") == variant.get("name") and raw.get("env") == variant.get("env", {}) and raw.get("variant_metadata") == variant.get("metadata", {}), name + ": variant/runtime metadata mismatch")
            effective = raw.get("effective_runtime_env", {})
            check(effective.get("FN_KNOCK_RUNTIME_TARGET") == "linux" and effective.get("FN_KNOCK_TOKIO_WORKER_THREADS") == "2", name + ": runtime target/worker mismatch")
            if not opts.get("recoveryProbe"):
                check(effective.get("FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT") is None, name + ": unexpected bridge capacity override")
            check(raw.get("profiling") is opts.get("profile", False) and raw.get("recovery_probe") is opts.get("recoveryProbe", False), name + ": diagnostic workload mismatch")
            valid += raw.get("validation", {}).get("passed") is True
            failed_requests += raw.get("measurement", {}).get("failures", 0)
            for field in ("sampling_ok", "health_ok", "client_ok", "duration_ok"):
                check(raw.get("quality", {}).get(field) is True, name + ": quality false/missing: " + field)
            for field in ("cache_control", "cache_control_after"):
                cache = raw.get(field, {})
                check(cache.get("runtime_verified") is True and cache.get("auth_cache_ttl_seconds") == opts["cacheTtl"] and cache.get("auth_cache_unauthorized_ttl_seconds") == opts["cacheTtl"], name + ": live TTL unverified/mismatched")
            seed = raw.get("seed", {})
            for field, option in [("credential_kind", "credentialKind"), ("accounts", "accounts"), ("sessions", "sessions"), ("ordinary_grants", "grants")]:
                check(seed.get(field) == opts[option], name + ": seed mismatch: " + field)
            renewal = row.get("scenario") == "grant_renewal"
            check(seed.get("renewal_tokens_per_phase") == (opts.get("renewals", 8) if renewal else 0), name + ": renewal token count mismatch")
            check(seed.get("total_grants") == opts["grants"] + int(renewal) + 2 * seed.get("renewal_tokens_per_phase", 0), name + ": total grant count mismatch (includes independent renewal preflight)")
            if renewal:
                measure = raw.get("measurement", {})
                check(measure.get("successful_requests") == seed.get("renewal_tokens_per_phase") and measure.get("all_tokens_consumed") is True, name + ": finite renewal batch incomplete")
            check(bool(raw.get("samples")) and bool(raw.get("runtime_health")), name + ": raw resource/health samples missing")
            if opts.get("profile"):
                profiles += 1
                op = raw.get("operation_profile", {})
                check(raw.get("profile_capture", {}).get("capture", {}).get("status") == "stopped", name + ": profile capture not stopped")
                check(op.get("dropped_operations") == 0 and "auth_reader" in op and "profile_idle" in raw, name + ": profile incomplete/dropped")
                check(op.get("successful_request_denominator") == raw.get("measurement", {}).get("successful_requests"), name + ": profile denominator mismatch")
            if opts.get("recoveryProbe"):
                recoveries += 1
                recovery = raw.get("recovery", {})
                check(recovery.get("passed") is True and recovery.get("performance_claim_allowed") is False, name + ": recovery failed/missing")
                check(raw.get("effective_runtime_env", {}).get("FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT") == "32", name + ": recovery capacity override not 32")
                check(bool(recovery.get("checks")) and recovery.get("recovery_elapsed_ms", float("inf")) <= 10000, name + ": recovery deadline/check missing")
        check(len(raw_seen) == len(rows), name + ": raw trial reused")
        check(valid == len(rows) and failed_requests == 0, name + ": request/validation failures")
        for sidecar in job["sidecars"]:
            if sidecar.endswith(".json"):
                gate = load(name + "/" + sidecar)
                if gate is not None:
                    if isinstance(gate, list):
                        check(bool(gate), name + ": empty validity comparison")
                        for group in gate:
                            check(group.get("invalid_runs") == 0 and group.get("duplicate_runs") == 0 and group.get("incomplete_pairs") == 0 and group.get("complete_pairs") == opts["pairs"], name + ": invalid comparison group")
                    else:
                        check_gate_hashes(gate.get("inputs", {}), name + "/" + sidecar)
                        for field in ("passed", "contract_passed", "completed_30_minutes_without_request_or_quality_failure"):
                            if field in gate:
                                check(gate[field] is True, name + ": sidecar gate false: " + field)
        summaries.append(dict(name=name, trials=len(rows), expected=job["expected_trials"], valid=valid, failed_requests=failed_requests, raw_files=len(raw_files), profile_trials=profiles, recovery_trials=recoveries))
    main_gate = load("support/post5-all-final/main.acceptance.json")
    if main_gate:
        check(main_gate.get("passed") is True, "main acceptance failed")
        check_gate_hashes(main_gate.get("inputs", {}), "main.acceptance.json")
    for relative, expected_lines in [("support/post5-all-final/completed-cases.txt", [j["name"][6:] for j in spec["jobs"] if j["name"].startswith("post5-")]), ("support/concurrency-v5-supplement-final/completed-groups.txt", ["c1", "c16", "c64"])]:
        if relative in by_relative:
            check((destination / relative).read_text().splitlines() == expected_lines, "completed marker order/integrity mismatch: " + relative)
    check(total == spec["expected_trials"], "total trial count mismatch")
    warnings.extend(["Collection integrity/contract review does not rerun acceptance or establish new performance claims.", "RSS/FD/thread/Go goroutine trends need review in soak-summary; its completion flag does not impose a leak threshold.", "Missing failed-run exception strings are privacy-redacted; the original remote files remain the source evidence.", "Hashes bind original source bytes to redacted collected bytes; gate inputs must match source hashes, not collected hashes."])
    return dict(schema_version=1,complete_and_consistent=not errors,expected_trials=spec["expected_trials"],observed_trials=total,jobs=summaries,errors=errors,warnings=warnings)

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "remote":
        remote_export(json.load(sys.stdin))
        return
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["show", "collect", "verify", "selftest"], nargs="?", default="show")
    parser.add_argument("--spec", default=str(Path(__file__).with_name("review-spec.json")))
    parser.add_argument("--host", default="root@192.168.31.98")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    spec = json.loads(Path(args.spec).read_text())
    if args.action == "show":
        print(json.dumps(dict(prepared_only=True,expected_trials=spec["expected_trials"],jobs=[dict(name=j["name"],trials=j["expected_trials"],sidecars=j["sidecars"]) for j in spec["jobs"]],extras=spec["extras"],policy=spec["policy"]), indent=2))
        return
    if args.action == "selftest":
        canary = "private-canary-not-a-real-secret"
        data = {"apiToken": canary, "Cookie": [canary], "nested": {"password_hash": canary}, "error": canary, "credential_kind": "password", "renewal_tokens_per_phase": 64, "set_cookie_count": 64, "message": "error " + canary, "plain": "Bearer abcdef0123"}
        redacted = sanitize(data)
        assert canary not in json.dumps(redacted)
        assert redacted["credential_kind"] == "password" and redacted["renewal_tokens_per_phase"] == 64 and redacted["set_cookie_count"] == 64
        for bad in ("../x", "/tmp/x", "foo/../../x"):
            try:
                safe_relative(bad)
                raise RuntimeError("unsafe path accepted")
            except AssertionError:
                pass
        assert sum(j["expected_trials"] for j in spec["jobs"]) == 261
        print("Offline canary/path/spec selftests passed. No SSH, collection or load.")
        return
    parser.error("--out NEW_LOCAL_DIRECTORY is required") if args.out is None else None
    if args.action == "verify":
        result = review(args.out, spec)
        print(json.dumps(result, indent=2))
        sys.exit(0 if result["complete_and_consistent"] else 2)
    master_source = Path(spec["plan_source"]).read_bytes()
    assert sha(master_source) == spec["plan_source_sha256"], "master collection plan changed; review spec before collecting"
    args.out.mkdir(parents=False, exist_ok=False)
    script = Path(__file__).read_text()
    cmd = ["ssh", "-oBatchMode=yes", "-oConnectTimeout=10", args.host, "python3 -B -c " + shlex.quote(script) + " remote"]
    child = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    child.stdin.write(json.dumps(spec))
    child.stdin.close()
    end, collected = None, []
    try:
        for line in child.stdout:
            record = json.loads(line)
            if record["kind"] == "file":
                relative = safe_relative(record["relative"])
                data = base64.b64decode(record.pop("content_base64"), validate=True)
                assert sha(data) == record["collected_sha256"], "transfer checksum mismatch"
                target = args.out / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb") as stream:
                    stream.write(data)
                record.pop("kind")
                collected.append(record)
            elif record["kind"] == "end":
                end = record
            else:
                raise AssertionError("unexpected export record")
        assert child.wait() == 0 and end is not None, "export failed/incomplete; partial local evidence retained"
        assert collected == end["collected"], "export index mismatch"
        end.pop("kind")
        master_collected = encode(sanitize(json.loads(master_source)))
        (args.out / "MASTER-COLLECTION-PLAN.json").write_bytes(master_collected)
        end.update(schema_version=1,host=args.host,review_spec_sha256=sha(encode(spec)),collector_sha256=sha(script.encode()),policy=spec["policy"],master_plan=dict(source=spec["plan_source"],source_sha256=sha(master_source),collected_sha256=sha(master_collected)))
        (args.out / "collection.json").write_bytes(encode(end))
        (args.out / "REVIEW-SPEC.json").write_bytes(encode(spec))
        result = review(args.out, spec)
        (args.out / "REVIEW.json").write_bytes(encode(result))
        hashes = {name:sha((args.out / name).read_bytes()) for name in ("collection.json", "REVIEW-SPEC.json", "REVIEW.json", "MASTER-COLLECTION-PLAN.json")}
        (args.out / "INDEX-SHA256.json").write_bytes(encode(hashes))
        print(json.dumps(dict(output=str(args.out),files=len(collected),trials=result["observed_trials"],complete_and_consistent=result["complete_and_consistent"],errors=result["errors"]), indent=2))
        sys.exit(0 if result["complete_and_consistent"] else 2)
    finally:
        if child.poll() is None:
            child.terminate()  # Stops only this local SSH reader, never experiment processes.
            child.wait()

if __name__ == "__main__":
    main()
