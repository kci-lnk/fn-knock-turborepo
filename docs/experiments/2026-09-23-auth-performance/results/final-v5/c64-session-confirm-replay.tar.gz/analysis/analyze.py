#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Portable offline report for the independent c64 session confirmation only."""
import argparse,datetime,hashlib,importlib.util,json,math,statistics
from pathlib import Path

PIN='35899a5ade46d210c2da17fa3c018d4b31ff569d2586a1e458c262a88b38b408'
BASE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def finite(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)
def change(a,b):return a/b-1 if finite(a) and finite(b) and b>0 else None
def median(v):return statistics.median(v) if v and all(finite(x) for x in v) else None
def num(v,d=2):return f'{v:.{d}f}' if finite(v) else '缺失'
def pct(v):return f'{v*100:+.2f}%' if finite(v) else '缺失'

def evaluate_gate(g):
 if not isinstance(g,dict):return None
 at_least=lambda value,limit:finite(value) and value>=limit-1e-12
 at_most=lambda value,limit:finite(value) and value<=limit+1e-12
 rps_ci=g.get('throughput_change_bootstrap_95') or [None,None]
 p99_ci=g.get('p99_change_bootstrap_95') or [None,None]
 conditions=dict(exact_six_complete_pairs=g.get('complete_pairs')==6 and g.get('six_valid_pairs') is True,valid_unique_complete=g.get('invalid_runs')==0 and g.get('duplicate_runs')==0 and g.get('incomplete_pairs')==0 and g.get('recovery_probe') is False,rps_no_worse_than_minus5_percent=at_least(g.get('throughput_change_median'),-0.05),p99_no_worse_than_plus10_percent=at_most(g.get('p99_change_median'),0.1),six_rss_pairs=g.get('rss_complete_pairs')==6,combined_peak_rss_growth_no_more_than5_percent=at_most(g.get('peak_rss_change_median',{}).get('combined'),0.05))
 targets=dict(rps=at_least(g.get('throughput_change_median'),0.1) and len(rps_ci)==2 and finite(rps_ci[0]) and rps_ci[0]>0,p99=at_most(g.get('p99_change_median'),-0.15) and len(p99_ci)==2 and finite(p99_ci[1]) and p99_ci[1]<0)
 conditions['at_least_one_improvement_target']=any(targets.values())
 return dict(passed=all(conditions.values()),conditions=conditions,improvement_targets=targets,throughput_paired95=rps_ci,p99_paired95=p99_ci)

def analyze(folder):
 pin=load(BASE/'plan.json');assert sha(BASE/'plan.json')==PIN,'frozen plan changed'
 assert sha(BASE/'variants5.json')==pin['input_config_sha256']
 assert sha(BASE/'contract_checker.py')==pin['files']['check-plan.py']
 spec=importlib.util.spec_from_file_location('contract_checker',BASE/'contract_checker.py');cc=importlib.util.module_from_spec(spec);spec.loader.exec_module(cc)
 source=load(folder/'SOURCE-HASHES.json');records={r['name']:r for r in source['files'] if r['exists']}
 errors=[];warnings=[]
 for name,meta in records.items():
  if sha(folder/name)!=meta['collected_sha256']:errors.append('本地收集SHA不符：'+name)
 docs={name:load(folder/name) for name in records if name.endswith('.json')}
 result=docs.get('session_hit/results.json',{'runs':[]});manifest=docs.get('session_hit/manifest.json');rows=result.get('runs',[]);outcome=docs.get('outcome.json')
 exact=None
 if manifest:
  exact=cc.contract(pin,load(BASE/'variants5.json'),manifest,result)
  pending={'exact 12 trials','unique trial directories','AB/BA alternating order'}
  errors.extend(exact['errors'] if outcome or len(rows)>=12 else [e for e in exact['errors'] if e not in pending])
 else:
  if outcome:errors.append('已结束但缺harness manifest')
 if 'prepared-manifest.json' in records and records['prepared-manifest.json']['source_sha256']!=PIN:errors.append('远端prepared manifest不等于冻结计划')
 trials=[]
 for r in rows:
  m=r.get('measurement',{});elapsed=m.get('elapsed_ms');resources={}
  for name in ['go','rust','client','fixture']:
   resource=r.get('resources',{}).get(name,{});cpu=resource.get('cpu_seconds');rss=resource.get('peak_rss_bytes')
   if not finite(cpu) or not finite(rss):errors.append(f"pair{r.get('pair')}/{r.get('role')}缺{name}CPU/RSS")
   resources[name]=dict(cpu_seconds=cpu,average_cpu_cores=cpu*1000/elapsed if finite(cpu) and finite(elapsed) and elapsed>0 else None,peak_rss_bytes=rss,peak_rss_mib=rss/1048576 if finite(rss) else None,cpu_ms_per_1000_success=resource.get('cpu_ms_per_1000_success'),peak_fds=resource.get('peak_fds'),peak_threads=resource.get('peak_threads'),end_rss_bytes=resource.get('end_rss_bytes'))
  peaks=[resources[n]['peak_rss_bytes'] for n in ['go','rust']];rss=sum(peaks) if all(finite(x) for x in peaks) else None
  quality=r.get('quality',{});quality_metrics=dict(loop_max_ms=m.get('client_event_loop_delay_max_ms'),client_start_max_ms=m.get('client_start_delay_max_ms'),sampling_gap_max_ms=quality.get('max_sampling_gap_ms'),**{k:quality.get(k) for k in ['sampling_ok','health_ok','client_ok','duration_ok']})
  t=dict(pair=r.get('pair'),role=r.get('role'),scenario=r.get('scenario'),successful_requests=m.get('successful_requests'),failures=m.get('failures'),elapsed_ms=elapsed,rps=m.get('successful_requests_per_second'),p99_ms=m.get('p99_ms'),resources=resources,combined_peak_rss_bytes=rss,combined_peak_rss_mib=rss/1048576 if finite(rss) else None,quality=quality_metrics,validation_passed=r.get('validation',{}).get('passed'),warmup_elapsed_ms=r.get('warmup',{}).get('measurement',{}).get('elapsed_ms'),warmup_quality=r.get('warmup',{}).get('quality'),observations=r.get('observation_counts'))
  trials.append(t)
  if finite(resources['client']['average_cpu_cores']) and resources['client']['average_cpu_cores']>=1.7:warnings.append(f"pair{t['pair']}/{t['role']}客户端接近2核，需排查客户端限制")
  if finite(resources['fixture']['average_cpu_cores']) and resources['fixture']['average_cpu_cores']>=0.85:warnings.append(f"pair{t['pair']}/{t['role']}fixture接近单核，需排查原点限制")
  if (t['warmup_quality'] or {}).get('duration_ok') is False:warnings.append(f"pair{t['pair']}/{t['role']}warm duration_ok=false，实际{t['warmup_elapsed_ms']}ms；冻结harness只以warm响应正确性作为gate")
 pairs=[]
 for index in range(6):
  seen=[t for t in trials if t['pair']==index];roles={t['role']:t for t in seen}
  if len(seen)!=2 or set(roles)!= {'baseline','candidate'}:continue
  a,b=roles['baseline'],roles['candidate'];rss_change={n:change(b['resources'][n]['peak_rss_bytes'],a['resources'][n]['peak_rss_bytes']) for n in ['go','rust']};rss_change['combined']=change(b['combined_peak_rss_bytes'],a['combined_peak_rss_bytes'])
  p=dict(pair=index,order='AB' if index%2==0 else 'BA',baseline=a,candidate=b,rps_change=change(b['rps'],a['rps']),p99_change=change(b['p99_ms'],a['p99_ms']),peak_rss_change=rss_change)
  pairs.append(p)
 aggregate=dict(complete_pairs=len(pairs),rps_change_median=median([p['rps_change'] for p in pairs]),p99_change_median=median([p['p99_change'] for p in pairs]),peak_rss_change_median={k:median([p['peak_rss_change'][k] for p in pairs]) for k in ['go','rust','combined']},roles={role:dict(rps_median=median([t['rps'] for t in trials if t['role']==role]),p99_ms_median=median([t['p99_ms'] for t in trials if t['role']==role]),combined_peak_rss_mib_median=median([t['combined_peak_rss_mib'] for t in trials if t['role']==role])) for role in ['baseline','candidate']})
 gate=docs.get('session_hit.gate.json');gate_group=gate[0] if isinstance(gate,list) and len(gate)==1 else None
 gate_review=evaluate_gate(gate_group)
 if gate_group:
  for stored,computed in [('throughput_change_median',aggregate['rps_change_median']),('p99_change_median',aggregate['p99_change_median'])]:
   if not finite(gate_group.get(stored)) or not finite(computed) or not math.isclose(gate_group[stored],computed,rel_tol=1e-9,abs_tol=1e-9):errors.append('gate与本地配对计算不符：'+stored)
  for key in ['go','rust','combined']:
   value=gate_group.get('peak_rss_change_median',{}).get(key);computed=aggregate['peak_rss_change_median'][key]
   if not finite(value) or not finite(computed) or not math.isclose(value,computed,rel_tol=1e-9,abs_tol=1e-9):errors.append('gate与RSS计算不符：'+key)
 if outcome:
  for name,expected in outcome.get('evidence',{}).items():
   if name not in records or expected['sha256']!=records[name]['source_sha256']:errors.append('outcome/source SHA缺失或不符：'+name)
  contract=docs.get('session_hit.contract.json')
  if not contract or contract.get('contract_passed') is not True:errors.append('远端exact contract未通过/缺失')
  else:
   for item in contract.get('inputs',{}).values():
    match=next((v for v in records.values() if v.get('source')==item['path']),None)
    if not match or match['source_sha256']!=item['sha256']:errors.append('远端contract/source SHA不符')
  if outcome.get('passed') is not True:errors.append('独立确认runner失败；保留原outcome和gate')
  if outcome.get('gate_flags')!=['--require-six-pairs','--require-improvement']:errors.append('gate flags不符')
  if not gate_review or not gate_review['passed']:errors.append('冻结门槛复核未通过/缺数据')
  if not gate_group:errors.append('最终gate不是单一session_hit组/缺失')
  if len(rows)!=12 or len(pairs)!=6:errors.append('最终未齐exact12/6pairs')
 return dict(schema_version=1,independent_confirmation=True,previous_trials_count=261,previous_trials_included=False,read_at_utc=source['read_at_utc'],state='finished' if outcome else 'running',observed_trials=len(rows),complete_pairs=len(pairs),errors=errors,warnings=warnings,review_checks_passed=not errors,final_acceptance_passed=outcome.get('passed') is True and not errors if outcome else None,plan_sha256=PIN,product_sources=pin['product_sources'],artifact_sha256={k:v['sha256'] for k,v in pin['artifacts'].items()},options=pin['options'],aggregate=aggregate,pairs=pairs,trials=trials,remote_contract=docs.get('session_hit.contract.json'),frozen_gate=gate,gate_review=gate_review,outcome=outcome,input_hashes=records,analyzer_sha256=sha(Path(__file__)),notes=['本次只有独立12条，不与原261条或原c16正式六对混算。','中途单pair或不足6pair只作checkpoint，不是验收。','最终gate由原冻结check-auth-performance --require-six-pairs --require-improvement执行；本工具只复核既有结果，不运行gate或负载。','RSS是Go与Rust各自采样峰值之和；CPU核数=CPU秒/实测elapsed秒。','raw时间曲线未下载，本报告不推断泄漏或RPC/cache命中率。'])

def render(r):
 a=r['aggregate'];lines=['# c64 session_hit 独立六对确认','',f"状态：{r['state']}；{r['observed_trials']}/12 trials，{r['complete_pairs']}/6完整pair。最终验收：{r['final_acceptance_passed']}。",'', '本次12条与原261条分开。c64、clients2、N1000/session1000/grants100、TOTP、TTL0、reader1/z、Tokio2、正常capacity不覆盖；warm20/load60，AB/BA交替。','', '| Pair/顺序 | RPS baseline→candidate | RPS变化 | P99ms baseline→candidate | P99变化 | Go+Rust峰RSS MiB baseline→candidate | RSS变化 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
 for p in r['pairs']:
  x,y=p['baseline'],p['candidate'];lines.append(f"| {p['pair']}/{p['order']} | {num(x['rps'])}→{num(y['rps'])} | {pct(p['rps_change'])} | {num(x['p99_ms'])}→{num(y['p99_ms'])} | {pct(p['p99_change'])} | {num(x['combined_peak_rss_mib'])}→{num(y['combined_peak_rss_mib'])} | {pct(p['peak_rss_change']['combined'])} |")
 lines+=['',f"当前配对中位变化：RPS {pct(a['rps_change_median'])}；P99 {pct(a['p99_change_median'])}；RSS合计 {pct(a['peak_rss_change_median']['combined'])}（Go {pct(a['peak_rss_change_median']['go'])}、Rust {pct(a['peak_rss_change_median']['rust'])}）。不足6对不作gate判断。",'', '| Pair/角色 | CPU核 Go/Rust/client/fixture | 峰RSS MiB Go/Rust | load秒 | loop最大ms | gap最大ms | load质量 |','| --- | ---: | ---: | ---: | ---: | ---: | --- |']
 for t in r['trials']:
  cpu='/'.join(num(t['resources'][n]['average_cpu_cores'],3) for n in ['go','rust','client','fixture']);rss='/'.join(num(t['resources'][n]['peak_rss_mib']) for n in ['go','rust']);ok=all(t['quality'][k] is True for k in ['sampling_ok','health_ok','client_ok','duration_ok']);lines.append(f"| {t['pair']}/{t['role']} | {cpu} | {rss} | {num(t['elapsed_ms']/1000 if finite(t['elapsed_ms']) else None,3)} | {num(t['quality']['loop_max_ms'])} | {num(t['quality']['sampling_gap_max_ms'])} | {ok} |")
 lines+=['','## 错误与限制','']+(['- '+e for e in r['errors']] or ['- 当前已写结果未发现身份、响应或load质量错误。'])+['- '+w for w in r['warnings']]+['- '+n for n in r['notes']]
 if r['frozen_gate']:lines+=['','## 原冻结gate','', '```json',json.dumps(r['frozen_gate'],indent=2,ensure_ascii=False),'```']
 lines+=['','完整角色中位数、分进程CPU/RSS/FD/线程、artifact/source SHA、逐对数据、质量与outcome见 review.json。','']
 return '\n'.join(lines)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,default=BASE/'inputs');p.add_argument('--out',type=Path,default=BASE);args=p.parse_args();r=analyze(args.input);args.out.mkdir(exist_ok=True);(args.out/'review.json').write_text(json.dumps(r,indent=2,ensure_ascii=False,allow_nan=False)+'\n');(args.out/'review.md').write_text(render(r));print(json.dumps({k:r[k] for k in ['state','observed_trials','complete_pairs','errors','warnings','final_acceptance_passed']},ensure_ascii=False));raise SystemExit(0 if not r['errors'] else 2)
if __name__=='__main__':main()
