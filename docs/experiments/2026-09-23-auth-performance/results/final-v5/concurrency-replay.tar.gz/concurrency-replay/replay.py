#!/usr/bin/env python3
"""Offline replay of the unchanged corrected concurrency5 analyzer."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(data):
    return hashlib.sha256(data).hexdigest()


def normalize(report):
    report = copy.deepcopy(report)
    # Moving the bundle changes only local input paths. Keep all input hashes,
    # byte counts, identities, numeric results, errors and warnings unchanged.
    for item in report['inputs']:
        item.pop('path')
    return report


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True, help='new output directory')
    args = parser.parse_args()
    for item in json.loads((root / 'FILES-SHA256.json').read_text())['files']:
        path = root / item['file']
        if sha(path.read_bytes()) != item['sha256']:
            raise SystemExit('Bundle checksum mismatch: ' + item['file'])
    subprocess.run([
        sys.executable, '-B', str(root / 'tools/analyze.py'),
        '--input', str(root / 'inputs'), '--plan', str(root / 'plan'),
        '--out', str(args.out.resolve()),
    ], check=True)
    expected = json.loads((root / 'expected/analysis.json').read_text())
    actual = json.loads((args.out / 'analysis.json').read_text())
    assert normalize(actual) == normalize(expected), 'Results differ beyond relocated input paths'
    assert (args.out / 'analysis.md').read_bytes() == (root / 'expected/analysis.md').read_bytes(), 'Markdown differs'
    fingerprint = sha(json.dumps(normalize(actual), sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode())
    result = {
        'passed': True,
        'input_checksums_verified': True,
        'analysis_equal_except_local_input_paths': True,
        'markdown_byte_identical': True,
        'trial_count': actual['observed_trials'],
        'warning_count': len(actual['warnings']),
        'normalized_analysis_sha256': fingerprint,
        'markdown_sha256': sha((args.out / 'analysis.md').read_bytes()),
        'analyzer_sha256': sha((root / 'tools/analyze.py').read_bytes()),
    }
    (args.out / 'REPLAY-VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
