#!/usr/bin/env python3
"""Offline concurrency5 review. No network, process execution, load or compilation."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

PIN_MANIFEST_SHA256 = "0616fe8895470b17f51a33594116dc43a0e6ba4f936cdb266cc9176a424bc0e5"
PLAN_DIRECTORY = Path("/tmp/fn-knock-auth-concurrency5-prep")
HARNESS_FILES = {"run-auth-performance-isolated.sh", "auth-performance.mjs", "auth-performance-lib.mjs", "auth-performance-worker.mjs", "auth-performance-seed.py", "auth-performance-profile.mjs", "auth-performance-recovery.mjs", "auth-performance-soak.mjs"}
ROLES = ["baseline", "candidate"]
PROCESSES = ["go", "rust", "client", "fixture"]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)

def close(a, b):
    return finite(a) and finite(b) and math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-7)

def ratio(after, before):
    return after / before - 1 if finite(after) and finite(before) and before > 0 else None

def read_json(path, inputs):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError("缺少普通 JSON 文件：" + str(path))
    data = path.read_bytes()
    if len(data) > 128 * 1024 * 1024:
        raise ValueError("JSON 超出 128 MiB 上限：" + str(path))
    inputs.append(dict(path=str(path.absolute()), sha256=digest(data), bytes=len(data)))
    return json.loads(data)

def load_pin(directory):
    inputs = []
    pin = read_json(directory / "manifest.json", inputs)
    if inputs[0]["sha256"] != PIN_MANIFEST_SHA256:
        raise ValueError("冻结 concurrency5 manifest SHA 不符，需重新审阅计划")
    for name, expected in pin["files"].items():
        path = directory / name
        if not path.is_file() or path.is_symlink() or digest(path.read_bytes()) != expected:
            raise ValueError("冻结计划文件 SHA 不符：" + name)
    config = read_json(directory / "variants5.json", inputs)
    if pin["options"]["warmup"] != 5 or pin["options"]["seconds"] != 15 or pin["trial_count"] != 24:
        raise ValueError("只支持已审阅的 warm5/load15、24 trial 计划")
    return pin, config, inputs

def sidecar(directory, filename):
    nested, sibling = directory / filename, Path(str(directory) + "." + filename)
    present = [p for p in [nested, sibling] if p.exists()]
    if len(present) == 2 and nested.read_bytes() != sibling.read_bytes():
        raise ValueError("两种布局的旁侧文件内容不同：" + filename)
    if not present:
        raise ValueError("缺少旁侧文件：" + str(nested) + " 或 " + str(sibling))
    return present[0]

def analyze_group(concurrency, documents, pin, config):
    results, manifest, contract, validity = [documents[k] for k in ["results", "manifest", "contract", "validity"]]
    errors, warnings = [], []
    def check(ok, detail):
        if not ok:
            errors.append(detail)
    routes = pin["options"]["routes"]
    check(results.get("schema_version") == 1 and manifest.get("schema_version") == 1, "schema_version 不符")
    check(manifest.get("config") == config, "manifest config 与冻结 variants5 不符")
    expected_options = dict(pin["options"], concurrency=concurrency)
    for field, expected in expected_options.items():
        value=manifest.get("options", {}).get(field)
        check(type(value) is type(expected) and value == expected, "options." + field + " 不符")
    expected_identity = {(v["name"], component, v[component], pin["artifacts"][v[component]]["sha256"]) for v in [config["baseline"], config["candidates"][0]] for component in ["go", "rust"]}
    identities = manifest.get("identities", [])
    check(len(identities) == 4 and {(i.get("variant"), i.get("component"), i.get("path"), i.get("sha256")) for i in identities} == expected_identity, "四个制品身份与冻结计划不符")
    harness = manifest.get("harness_identity", {})
    files = harness.get("files", [])
    check(len(files) == 8 and {i.get("name") for i in files} == HARNESS_FILES, "8 个 harness 文件身份不完整/重复")
    for item in files:
        check(pin["tools"]["files"].get(item.get("name")) == item.get("sha256"), "harness SHA 不符：" + str(item.get("name")))
    check(harness.get("control_binary_sha256") == pin["control_binary"]["sha256"], "control binary SHA 不符")
    expected_contract=dict(complete_expected_trials=8, concurrency=concurrency, contract_passed=True, performance_acceptance=False)
    check(contract == expected_contract and all(type(contract.get(k)) is type(v) for k,v in expected_contract.items()), "contract.json 不符或未通过")
    rows = results.get("runs", [])
    expected_rows = {(route, 0, role) for route in routes for role in ROLES}
    check(len(rows) == 8 and {(r.get("scenario"), r.get("pair"), r.get("role")) for r in rows} == expected_rows, "必须恰好 4 路由×pair0×双角色 = 8 trials")
    check(len({r.get("directory") for r in rows}) == 8 and all(isinstance(r.get("directory"), str) for r in rows), "trial directory 缺失或复用")
    check([(r.get("scenario"), r.get("role")) for r in rows] == [(route, role) for route in routes for role in ROLES], "固定顺序 route→baseline→candidate 不符")
    summaries = []
    for row in rows:
        route, role = row.get("scenario"), row.get("role")
        label = str(route) + "/" + str(role)
        def row_check(ok, detail):
            check(ok, label + "：" + detail)
        if role not in ROLES or route not in routes:
            continue
        variant = config["baseline"] if role == "baseline" else config["candidates"][0]
        row_check(row.get("candidate") == "candidate5" and row.get("variant") == variant["name"], "variant 名称不符")
        row_check(row.get("variant_metadata") == variant["metadata"] and row.get("env") == variant["env"], "源码/编译/env metadata 不符")
        row_check(row.get("concurrency") == concurrency and row.get("cache_ttl_seconds") == 0 and row.get("roles") == ROLES, "并发/TTL/roles 不符")
        row_check(row.get("profiling") is False and row.get("recovery_probe") is False, "混入 profile/recovery")
        seed = dict(scenario=route, accounts=1000, sessions=1000, ordinary_grants=100, total_grants=100, credential_kind="totp", renewal_tokens_per_phase=0)
        row_check(all(row.get("seed", {}).get(k) == v for k, v in seed.items()), "种子规模/credential/renewal 不符")
        expected_env = dict(FN_KNOCK_RUNTIME_TARGET="linux", FN_KNOCK_TOKIO_WORKER_THREADS="2", FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT=None, FN_KNOCK_SQLITE_AUTH_READERS="1" if role == "candidate" else None, GLIBC_TUNABLES=None, LD_PRELOAD=None, MALLOC_ARENA_MAX=None, GOMEMLIMIT=None, GOGC=None, GOMAXPROCS=None)
        row_check(row.get("effective_runtime_env") == expected_env, "effective runtime env 不符")
        for field in ["cache_control", "cache_control_after"]:
            observed = row.get(field, {})
            row_check(observed.get("runtime_verified") is True and observed.get("auth_cache_ttl_seconds") == 0 and observed.get("auth_cache_unauthorized_ttl_seconds") == 0, field + " 未证实实际 TTL0")
        preflight = row.get("preflight", {})
        expected_preflight = dict(status=200, expected="bootstrap" if route == "bootstrap" else "origin", origin=None if route == "bootstrap" else "auth-performance-owned-origin-v1", renewal=False)
        row_check(all(preflight.get(k) == v for k, v in expected_preflight.items()), "preflight 未证实真实工作")
        row_check(row.get("validation", {}).get("passed") is True, "validation 未通过")
        quality = row.get("quality", {})
        row_check(all(quality.get(k) is True for k in ["sampling_ok", "health_ok", "client_ok", "duration_ok"]), "质量标记不全/失败")
        observation = row.get("observation_counts", {})
        row_check(all(finite(observation.get(k)) and observation[k] > 0 for k in ["process_samples", "health_samples"]), "缺 process/health 采样")
        for phase, measurement, seconds in [("warmup", row.get("warmup", {}).get("measurement", {}), 5), ("load", row.get("measurement", {}), 15)]:
            elapsed, success, requests, failures = [measurement.get(k) for k in ["elapsed_ms", "successful_requests", "requests", "failures"]]
            row_check(finite(elapsed) and elapsed >= seconds * 1000, phase + " actual elapsed 缺失/短于配置时间")
            # Frozen harness gates load quality and warmup response correctness.
            # Warmup duration/client quality is diagnostic, not an added gate.
            if phase == "load":
                row_check(finite(elapsed) and elapsed <= seconds * 1000 + max(500, seconds * 50), phase + " actual elapsed 超出协议容忍范围")
            row_check(finite(success) and success > 0 and success == requests and failures == 0, phase + " 请求计数/失败不符")
            row_check(measurement.get("statuses") == {"200": requests}, phase + " 包含非 200 状态")
            row_check(measurement.get("anomalies") == [] and measurement.get("latency_overflow") == 0, phase + " response anomaly/latency overflow")
            if finite(success) and finite(elapsed) and elapsed > 0:
                rps = success * 1000 / elapsed
                row_check(close(measurement.get("successful_requests_per_second"), rps) and close(measurement.get("requests_per_second"), rps), phase + " RPS 与实际 elapsed/计数不一致")
            for key in ["client_event_loop_delay_max_ms", "client_start_delay_max_ms"]:
                row_check(finite(measurement.get(key)) and 0 <= measurement[key], phase + " " + key + " 缺失/不合法")
                if phase == "load":
                    row_check(finite(measurement.get(key)) and measurement[key] <= 100, phase + " " + key + " 超限")
        measure = row.get("measurement", {})
        elapsed = measure.get("elapsed_ms")
        row_check(all(finite(measure.get(k)) and measure[k] >= 0 for k in ["p50_ms", "p95_ms", "p99_ms"]), "缺 latency quantile")
        if all(finite(measure.get(k)) for k in ["p50_ms", "p95_ms", "p99_ms"]):
            row_check(measure["p50_ms"] <= measure["p95_ms"] <= measure["p99_ms"], "latency quantile 顺序错误")
        row_check(finite(quality.get("max_sampling_gap_ms")) and 0 <= quality["max_sampling_gap_ms"] <= 1000, "采样 gap 缺失/超 1000 ms")
        processes = {}
        for name in PROCESSES:
            resource = row.get("resources", {}).get(name, {})
            for key in ["cpu_seconds", "cpu_ms_per_1000_success", "peak_rss_bytes", "end_rss_bytes", "peak_fds", "peak_threads"]:
                row_check(finite(resource.get(key)) and resource[key] >= 0, name + "." + key + " 缺失/不合法")
            cpu, success = resource.get("cpu_seconds"), measure.get("successful_requests")
            if finite(cpu) and finite(success) and success > 0:
                row_check(close(resource.get("cpu_ms_per_1000_success"), cpu * 1000000 / success), name + " CPU/千请求单位不符")
            before, after = resource.get("before", {}), resource.get("after", {})
            row_check(before.get("pid") is not None and before.get("pid") == after.get("pid") and before.get("start_ticks") is not None and before.get("start_ticks") == after.get("start_ticks"), name + " 进程身份在测量中变化/缺失")
            row_check(finite(before.get("cpu_seconds")) and finite(after.get("cpu_seconds")), name + " 缺少前后CPU快照")
            if finite(before.get("cpu_seconds")) and finite(after.get("cpu_seconds")):
                row_check(close(cpu, after["cpu_seconds"] - before["cpu_seconds"]), name + " CPU delta 不符")
            processes[name] = dict(cpu_seconds=cpu, average_cpu_cores=cpu * 1000 / elapsed if finite(cpu) and finite(elapsed) and elapsed > 0 else None, cpu_ms_per_1000_success=resource.get("cpu_ms_per_1000_success"), peak_rss_bytes=resource.get("peak_rss_bytes"), peak_rss_mib=resource["peak_rss_bytes"] / 1048576 if finite(resource.get("peak_rss_bytes")) else None, end_rss_bytes=resource.get("end_rss_bytes"), peak_fds=resource.get("peak_fds"), peak_threads=resource.get("peak_threads"))
        peaks = [processes[n]["peak_rss_bytes"] for n in ["go", "rust"]]
        combined_peak = sum(peaks) if all(finite(n) for n in peaks) else None
        workers = pin["fixture"]["effective_client_workers"][str(concurrency)]
        client_cpu, fixture_cpu = processes["client"]["average_cpu_cores"], processes["fixture"]["average_cpu_cores"]
        row_warnings = []
        warm = row.get("warmup", {})
        warm_measure = warm.get("measurement", {})
        warm_elapsed = warm_measure.get("elapsed_ms")
        if finite(warm_elapsed) and warm_elapsed > 5500:
            row_warnings.append(f"预热实际 {warm_elapsed:.3f}ms 超出5000+500ms诊断阈值；warmup.duration_ok={warm.get('quality',{}).get('duration_ok')}。冻结协议只将预热响应正确性作为gate，该时长偏差保留为警告，不能说所有阶段质量均通过")
        if any(finite(warm_measure.get(k)) and warm_measure[k] > 100 for k in ["client_event_loop_delay_max_ms", "client_start_delay_max_ms"]):
            row_warnings.append("预热客户端延迟超过100ms诊断阈值；冻结协议不以warmup.client_ok作为gate")
        if finite(client_cpu) and client_cpu >= workers * 0.85:
            row_warnings.append("客户端平均 CPU 达有效 worker 数的85%，需排查客户端限制；这是提示而非瓶颈证明")
        if finite(fixture_cpu) and fixture_cpu >= 0.85:
            row_warnings.append("fixture 平均 CPU 接近单核，需排查原点限制；这是提示而非瓶颈证明")
        if finite(measure.get("client_event_loop_delay_max_ms")) and measure["client_event_loop_delay_max_ms"] >= 80:
            row_warnings.append("客户端事件循环最大延迟接近100ms质量上限")
        if finite(quality.get("max_sampling_gap_ms")) and quality["max_sampling_gap_ms"] >= 800:
            row_warnings.append("资源采样间隔接近1000ms质量上限")
        if observation.get("timeout_phase_events", 0):
            row_warnings.append("已记录 timeout phase 事件，需回看 raw JSON 数值诊断")
        warnings.extend(label + "：" + w for w in row_warnings)
        summaries.append(dict(scenario=route, role=role, concurrency=concurrency, successful_requests=measure.get("successful_requests"), failures=measure.get("failures"), elapsed_ms=elapsed, warmup_elapsed_ms=warm_elapsed, warmup_quality=warm.get("quality"), rps=measure.get("successful_requests_per_second"), p50_ms=measure.get("p50_ms"), p95_ms=measure.get("p95_ms"), p99_ms=measure.get("p99_ms"), processes=processes, go_rust_peak_rss_sum_bytes=combined_peak, go_rust_peak_rss_sum_mib=combined_peak / 1048576 if finite(combined_peak) else None, effective_client_workers=workers, client_event_loop_delay_max_ms=measure.get("client_event_loop_delay_max_ms"), client_start_delay_max_ms=measure.get("client_start_delay_max_ms"), max_sampling_gap_ms=quality.get("max_sampling_gap_ms"), observation_counts=observation, quality={k:quality.get(k) for k in ["sampling_ok", "health_ok", "client_ok", "duration_ok"]}, warnings=row_warnings))
    expected_keys = {route + "/" + str(concurrency) + "/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0":route for route in routes}
    check(isinstance(validity, list) and len(validity) == 4 and {v.get("key") for v in validity} == set(expected_keys), "validity 必须恰好匹配四个 comparison group")
    comparisons = []
    for group in validity if isinstance(validity, list) else []:
        key = group.get("key")
        for field, expected in dict(complete_pairs=1,incomplete_pairs=0,invalid_runs=0,duplicate_runs=0,six_valid_pairs=False,rss_complete_pairs=1,recovery_probe=False).items():
            check(type(group.get(field)) is type(expected) and group.get(field) == expected, str(key) + "：validity." + field + " 不符")
        check(group.get("throughput_change_bootstrap_95") is None and group.get("p99_change_bootstrap_95") is None, "单对不应存在 CI")
        route = expected_keys.get(key)
        by_role = {r["role"]:r for r in summaries if r["scenario"] == route}
        if set(by_role) != set(ROLES):
            continue
        base, cand = [by_role[r] for r in ROLES]
        changes = dict(rps=ratio(cand["rps"],base["rps"]),p99=ratio(cand["p99_ms"],base["p99_ms"]),peak_rss_sum=ratio(cand["go_rust_peak_rss_sum_bytes"],base["go_rust_peak_rss_sum_bytes"]))
        for output_key, mean_key, list_key in [("rps","throughput_change_median","paired_throughput_changes"),("p99","p99_change_median","paired_p99_changes")]:
            change=changes[output_key]
            if change is not None:
                check(close(group.get(mean_key),change) and len(group.get(list_key,[])) == 1 and close(group[list_key][0],change), str(key)+"：validity change 与输入 trial 不一致")
        for proc in ["go","rust","combined"]:
            change=changes["peak_rss_sum"] if proc=="combined" else ratio(cand["processes"][proc]["peak_rss_bytes"],base["processes"][proc]["peak_rss_bytes"])
            values=group.get("paired_peak_rss_changes",{}).get(proc,[])
            check(close(group.get("peak_rss_change_median",{}).get(proc),change) and len(values)==1 and close(values[0],change),str(key)+"：RSS comparison 与 trial 不一致")
        comparisons.append(dict(scenario=route,concurrency=concurrency,baseline=base,candidate=cand,observed_single_pair_changes=changes))
    return dict(concurrency=concurrency,checks_passed=not errors,observed_trials=len(rows),expected_trials=8,errors=errors,warnings=warnings,host=manifest.get("host"),trials=summaries,comparisons=comparisons)

def render(report):
    num=lambda v,d=2: f"{v:.{d}f}" if finite(v) else "缺失"
    pct=lambda v: (f"{v*100:+.2f}%" if finite(v) else "不可定义")
    lines=["# 同规模并发补充：离线探索结果", "", "核对结果：" + ("24 条通过冻结合同与测量门禁；预热诊断偏差另列。" if report["checks_passed"] else "未通过，以下数据不得当作合格比较；保留异常供诊断。"), "", "协议：c1/c16/c64；每档4路由×1对、固定baseline→candidate；warm5秒/load15秒；N1000 accounts/session、100普通grant、TOTP、实际TTL0、候选reader1、Rust z、Tokio2。各档串行执行，时间噪声和固定AB顺序均未消除。", "", "这些是每格一次观测，不给置信区间、显著性、正式收益验收或默认参数建议。百分比仅描述本次配对变化。CPU核数=进程CPU秒÷实测墙钟秒；RSS合计是Go与Rust各自采样峰值相加，不是同步瞬时总峰值。"]
    for route in report["routes"]:
        lines += ["", "## " + route, "", "| 并发 | RPS 基线→候选 | 观测变化 | P99 ms 基线→候选 | 观测变化 | Go+Rust RSS MiB 基线→候选 |", "| --- | ---: | ---: | ---: | ---: | ---: |"]
        for group in report["groups"]:
            comp=next((x for x in group.get("comparisons",[]) if x["scenario"]==route),None)
            if comp is None:
                lines += [f"| c{group['concurrency']} | 缺失 | — | 缺失 | — | 缺失 |"]
                continue
            a,b,delta=comp["baseline"],comp["candidate"],comp["observed_single_pair_changes"]
            lines += [f"| c{group['concurrency']} | {num(a['rps'])} → {num(b['rps'])} | {pct(delta['rps'])} | {num(a['p99_ms'])} → {num(b['p99_ms'])} | {pct(delta['p99'])} | {num(a['go_rust_peak_rss_sum_mib'])} → {num(b['go_rust_peak_rss_sum_mib'])} |"]
        lines += ["", "| 并发/角色 | CPU核 Go / Rust / client / fixture | RSS MiB Go / Rust / client / fixture | warm/load秒 | loop最大ms | 采样gap最大ms | load质量 |", "| --- | ---: | ---: | ---: | ---: | ---: | --- |"]
        for group in report["groups"]:
            for t in [x for x in group.get("trials",[]) if x["scenario"]==route]:
                cpu=" / ".join(num(t['processes'][p]['average_cpu_cores'],3) for p in PROCESSES)
                rss=" / ".join(num(t['processes'][p]['peak_rss_mib']) for p in PROCESSES)
                quality="通过" if all(v is True for v in t['quality'].values()) else "失败/缺失"
                seconds=t['elapsed_ms']/1000 if finite(t['elapsed_ms']) else None
                warm_seconds=t['warmup_elapsed_ms']/1000 if finite(t['warmup_elapsed_ms']) else None
                lines += [f"| c{t['concurrency']}/{t['role']} | {cpu} | {rss} | {num(warm_seconds,3)} / {num(seconds,3)} | {num(t['client_event_loop_delay_max_ms'])} | {num(t['max_sampling_gap_ms'])} | {quality} |"]
    lines += ["", "## 异常与提示", ""]
    lines += ["- "+e for e in report['errors']] or ["- 未发现合同、身份、数量、响应和正式测量质量门禁异常。"]
    lines += ["- "+w for w in report['warnings']] or ["- 未触发客户端/fixture CPU及采样接近上限提示；这并不能单独证明服务端是唯一瓶颈。"]
    lines += ["", "JSON另保留每个进程CPU秒、CPU ms/千次成功、RSS、FD、线程、请求数、实测elapsed、client start delay、过程/health采样数量与输入SHA256。没有读取raw采样，不能从汇总反推RSS时间走势或遗漏的RPC/cache命中计数。", "", "输入hash与冻结源码/制品身份见同目录 `analysis.json`。", ""]
    return "\n".join(lines)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,help="含c1/c16/c64（或collection的concurrency5-c1等）的本地目录")
    for n in [1,16,64]:parser.add_argument("--c"+str(n),type=Path,help="该档输入目录，覆盖--input自动定位")
    parser.add_argument("--plan",type=Path,default=PLAN_DIRECTORY)
    parser.add_argument("--out",type=Path,required=True,help="全新本地输出目录")
    args=parser.parse_args()
    pin,config,inputs=load_pin(args.plan)
    groups=[]
    for n in pin['group_order']:
        directory=getattr(args,"c"+str(n))
        if directory is None:
            if args.input is None:parser.error("需要--input或所有--c1/--c16/--c64目录")
            matches=[p for p in [args.input/('c'+str(n)),args.input/('concurrency5-c'+str(n))] if p.is_dir()]
            if len(matches)!=1:
                groups.append(dict(concurrency=n,checks_passed=False,observed_trials=0,expected_trials=8,errors=["无法唯一定位输入目录"],warnings=[],trials=[],comparisons=[]))
                continue
            directory=matches[0]
        try:
            documents,read_errors={},[]
            for key in ['results','manifest','contract','validity']:
                try:
                    documents[key]=read_json(directory/(key+'.json') if key in ['results','manifest'] else sidecar(directory,key+'.json'),inputs)
                except (ValueError,OSError):
                    documents[key]=[] if key=='validity' else {}
                    read_errors.append(key+'.json 缺失/不完整/两种布局冲突')
            group=analyze_group(n,documents,pin,config)
            group['errors']=read_errors+group['errors']
            group['checks_passed']=not group['errors']
            groups.append(group)
        except (ValueError,KeyError,TypeError,IndexError,OSError) as error:
            groups.append(dict(concurrency=n,checks_passed=False,observed_trials=0,expected_trials=8,errors=["输入schema/文件错误："+type(error).__name__+"（请核对文件存在且结构完整）"],warnings=[],trials=[],comparisons=[]))
    errors=[f"c{g['concurrency']}：{e}" for g in groups for e in g['errors']]
    warnings=[f"c{g['concurrency']}：{e}" for g in groups for e in g['warnings']]
    hosts=[g.get('host') for g in groups if g.get('host')]
    if len(hosts)!=3 or any(h!=hosts[0] for h in hosts[1:]):errors.append("三档host kernel/Node身份缺失或不同")
    report=dict(schema_version=1,mode="exploratory_single_pair_only",performance_acceptance=False,default_change_allowed=False,checks_passed=not errors,expected_trials=24,observed_trials=sum(g['observed_trials'] for g in groups),routes=pin['options']['routes'],fixed_protocol=pin['options'],product_sources=pin['product_sources'],artifact_sha256={p:v['sha256'] for p,v in pin['artifacts'].items()},analyzer_sha256=digest(Path(__file__).read_bytes()),inputs=inputs,groups=groups,errors=errors,warnings=warnings,limitations=["单对固定AB，没有CI/显著性/正式收益验收。","组间串行执行，不能排除时间噪声。","CPU限制提示是启发式，不是瓶颈归因证据。","只读汇总与旁侧文件，不反推raw采样的时间曲线。","冻结协议不对warmup.duration_ok增加硬门禁；实际预热诊断与偏差保留。"])
    args.out.mkdir(exist_ok=False,parents=False)
    (args.out/'analysis.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    (args.out/'analysis.md').write_text(render(report))
    output_hashes={name:digest((args.out/name).read_bytes()) for name in ['analysis.json','analysis.md']}
    (args.out/'OUTPUT-SHA256.json').write_text(json.dumps(output_hashes,indent=2)+'\n')
    print(json.dumps(dict(output=str(args.out),checks_passed=report['checks_passed'],observed_trials=report['observed_trials'],errors=len(errors),warnings=len(warnings)),ensure_ascii=False))
    sys.exit(0 if report['checks_passed'] else 2)

if __name__ == '__main__':main()
