#!/usr/bin/env python3
"""Synthetic offline checks only. Never connects to SSH or reads experiment trials."""
import importlib.util
import json
from pathlib import Path
import tempfile

spec = importlib.util.spec_from_file_location("collector", Path(__file__).with_name("collect-final5.py"))
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

def run():
    with tempfile.TemporaryDirectory(prefix="synthetic-check-", dir=Path(__file__).parent) as folder:
        out = Path(folder)
        opts = dict(routes=["session_hit"], pairs=1, roles=["baseline", "candidate"], profile=False, recoveryProbe=False, cacheTtl=0, accounts=1, sessions=1, grants=1, credentialKind="totp")
        job = dict(name="synthetic", output="/synthetic/output", expected_options=opts, expected_trials=2, sidecars=["validity.json", "acceptance.json"])
        identities = [dict(path="/synthetic/" + name, sha256=str(i) * 64) for i, name in enumerate(["base-go", "base-rust", "candidate-go", "candidate-rust"], 1)]
        files = [dict(name="tool" + str(i), sha256=str(i) * 64) for i in range(8)]
        plan = c.encode(dict(jobs=[job]))
        rule = dict(jobs=[job], expected_trials=2, artifact_hashes={i["path"]:i["sha256"] for i in identities}, tools_hashes={i["name"]:i["sha256"] for i in files}, control_sha256="a" * 64, plan_source_sha256=c.sha(plan))
        variant = dict(name="synthetic", env={}, metadata={})
        manifest = dict(options=opts, identities=identities, harness_identity=dict(files=files, control_binary_sha256="a"*64), config=dict(baseline=variant,candidates=[variant]))
        rows = []
        objects = {"synthetic/manifest.json":manifest}
        for role in opts["roles"]:
            raw = dict(scenario="session_hit", pair=0, role=role, variant="synthetic", env={}, variant_metadata={}, profiling=False, recovery_probe=False, directory="/synthetic/output/"+role, raw_result_file="/synthetic/output/"+role+"/result.json", measurement=dict(failures=0,successful_requests=100), resources={}, quality={k:True for k in ["sampling_ok","health_ok","client_ok","duration_ok"]}, validation=dict(passed=True), seed=dict(credential_kind="totp", accounts=1, sessions=1, ordinary_grants=1, renewal_tokens_per_phase=0), effective_runtime_env=dict(FN_KNOCK_RUNTIME_TARGET="linux",FN_KNOCK_TOKIO_WORKER_THREADS="2",FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT=None), samples=[{}], runtime_health=[{}])
            raw["seed"]["total_grants"] = 1
            for key in ("cache_control","cache_control_after"):
                raw[key] = dict(runtime_verified=True,auth_cache_ttl_seconds=0,auth_cache_unauthorized_ttl_seconds=0)
            objects["synthetic/"+role+"/result.json"] = raw
            rows.append({k:v for k,v in raw.items() if k not in ("samples","runtime_health")})
        objects["synthetic/results.json"] = dict(runs=rows)
        objects["synthetic/validity.json"] = [dict(invalid_runs=0,duplicate_runs=0,incomplete_pairs=0,complete_pairs=1)]
        objects["synthetic/acceptance.json"] = dict(passed=True,inputs=dict(results=dict(path="/synthetic/output/results.json",sha256=c.sha(c.encode(objects["synthetic/results.json"])))))
        entries = []
        for relative,value in objects.items():
            data=c.encode(value);p=out/relative;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(data)
            entries.append(dict(relative=relative,source="/synthetic/output/"+relative.removeprefix("synthetic/"),source_sha256=c.sha(data),collected_sha256=c.sha(data)))
        (out/"MASTER-COLLECTION-PLAN.json").write_bytes(plan)
        index=dict(collected=entries,missing=[],sources_changed_during_collection=[],source_consistency_checked=True,review_spec_sha256=c.sha(c.encode(rule)),master_plan=dict(source_sha256=c.sha(plan),collected_sha256=c.sha(plan)))
        (out/"collection.json").write_bytes(c.encode(index))
        result=c.review(out,rule)
        assert result["complete_and_consistent"],result["errors"]
        # A gate input is checked against source hash, not the sanitized collected hash.
        acceptance=objects["synthetic/acceptance.json"]
        acceptance["inputs"]["results"]["sha256"]="0"*64
        p=out/"synthetic/acceptance.json";p.write_bytes(c.encode(acceptance))
        entry=next(i for i in entries if i["relative"]=="synthetic/acceptance.json")
        entry["collected_sha256"]=c.sha(p.read_bytes());(out/"collection.json").write_bytes(c.encode(index))
        result=c.review(out,rule)
        assert any("gate/source hash mismatch" in x for x in result["errors"])
        # Trial count and transfer integrity violations are visible, not silently ignored.
        p=out/"synthetic/results.json";p.write_bytes(c.encode(dict(runs=rows[:1])))
        result=c.review(out,rule)
        assert any("collected hash mismatch" in x for x in result["errors"])
        assert any("trial matrix incomplete" in x for x in result["errors"])
    print("Offline synthetic review tests passed (validity array, hashes, gate provenance, trial count). No experiment collection performed.")

if __name__ == "__main__":
    run()
