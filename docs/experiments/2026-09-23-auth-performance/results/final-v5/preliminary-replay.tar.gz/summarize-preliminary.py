#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline, experiment-specific smoke evidence review; never runs a workload.

Uses Python's standard library. Input files are immutable downloaded summaries.
No bootstrap, performance gate, or concurrency-scaling inference is performed.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path

CASES = {
    'accounts1000-c16-v5': dict(routes=['bootstrap', 'session_hit', 'auto_ip_hit'], concurrency=16, clients=2, sessions=1000, accounts=1000, grants=100, credentialKind='totp', warmup=3, seconds=8, renewals=64),
    'smoke-v5-c1': dict(routes=['bootstrap', 'challenge', 'session_api', 'session_hit', 'session_miss', 'grant_hit', 'grant_miss', 'grant_renewal', 'auto_ip_hit', 'auto_ip_miss'], concurrency=1, clients=1, sessions=1, accounts=1, grants=1, credentialKind='totp', warmup=1, seconds=3, renewals=8),
    'smoke-v5-c64': dict(routes=['bootstrap', 'challenge', 'session_hit', 'grant_hit', 'auto_ip_hit'], concurrency=64, clients=2, sessions=100, accounts=100, grants=100, credentialKind='totp', warmup=3, seconds=8, renewals=64),
    'password-v5-c16': dict(routes=['session_api', 'session_hit', 'auto_ip_hit', 'auto_ip_miss'], concurrency=16, clients=2, sessions=1000, accounts=1000, grants=100, credentialKind='password', warmup=3, seconds=8, renewals=64),
}
IDENTITIES = {
    'baseline': dict(name='base5', rust='d4f8805f39d9f4480bf83f4382ba59e5f49e7dc4', go='92d4c0cb5495d57801d52893a8f0e8496a1c9182', rust_sha256='6aee890974e6caa7f961e4c6778fdca00c23886880fb00286d7ccc1c8256bfa2', go_sha256='88a6ef9a80bab166eaf49ba96a620e98dced25a527d0dc5ad653ff7ac15139eb'),
    'candidate': dict(name='candidate5', rust='5fddf896eaf9b1cf3eb300c08315320498c943b8', go='4d15fa32764e26df58b16930d0e2503a90880002', rust_sha256='08bdd768e0e239d5fad08ac7c987ff9fbc5f1c1d26fbbbeb1d6bc6e3f56b3bd9', go_sha256='603188b385a10abb7bf1d6a6f8798c2234e0beafcc692e5abda0e7112a48eab6'),
}
MARKER = 'auth-performance-owned-origin-v1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def review(directory):
    errors, inputs, cases = [], [], []
    process_ids = {'go': set(), 'rust': set()}
    trial_directories = set()
    first_harness = None

    def check(condition, detail):
        if not condition:
            errors.append(detail)

    downloads = json.loads((directory / 'download-manifest.json').read_text())
    for item in downloads['files']:
        relative = '/'.join(item['source'].split('/')[-2:])
        path = directory / relative
        check(sha(path) == item['sha256'], f'{relative}: checksum mismatch')
        inputs.append(dict(file=relative, sha256=sha(path), bytes=path.stat().st_size))

    for name, expected in CASES.items():
        manifest = json.loads((directory / name / 'manifest.json').read_text())
        result = json.loads((directory / name / 'results.json').read_text())
        rows, options = result['runs'], manifest['options']
        for key, value in {**expected, 'pairs': 1, 'cacheTtl': 0, 'profile': False, 'recoveryProbe': False, 'roles': ['baseline', 'candidate'], 'hz': 100}.items():
            check(options.get(key) == value, f'{name}: options.{key}')
        check(len(rows) == len(expected['routes']) * 2, f'{name}: trial count')
        observed = [(r['pair'], r['scenario'], r['role']) for r in rows]
        required = [(0, route, role) for route in expected['routes'] for role in ['baseline', 'candidate']]
        check(observed == required, f'{name}: exact route/role/pair order')
        harness = manifest['harness_identity']
        if first_harness is None:
            first_harness = harness
        check(harness == first_harness, f'{name}: harness differs')
        check(harness['control_binary_sha256'] == '897cfef2a9f4b1fdf7330e66acbe7b4449945875fa2ac99ac9ab63632fc2d398', f'{name}: control identity')
        for evidence in sorted((directory / 'evidence').iterdir()):
            matching = [x for x in harness['files'] if x['name'] == evidence.name]
            check(len(matching) == 1 and matching[0]['sha256'] == sha(evidence), f'{name}: evidence/{evidence.name} differs')
        for role, identity in IDENTITIES.items():
            variant = manifest['config']['baseline'] if role == 'baseline' else manifest['config']['candidates'][0]
            check(variant['name'] == identity['name'], f'{name}: variant name')
            check(variant['metadata']['main_commit'] == identity['rust'] and variant['metadata']['go_commit'] == identity['go'], f'{name}: source metadata')
            for component in ['go', 'rust']:
                hits = [x for x in manifest['identities'] if x['variant'] == identity['name'] and x['component'] == component]
                check(len(hits) == 1 and hits[0]['sha256'] == identity[component + '_sha256'], f'{name}: {role}/{component} hash')
        load_counts, warm_counts = collections.Counter(), collections.Counter()
        summaries = []
        for row in rows:
            tag = f"{name}/{row['scenario']}/{row['role']}"
            identity = IDENTITIES[row['role']]
            metadata = row['variant_metadata']
            check(row['variant'] == identity['name'] and row['candidate'] == 'candidate5', f'{tag}: role identity')
            check(metadata['main_commit'] == identity['rust'] and metadata['go_commit'] == identity['go'], f'{tag}: source identity')
            for key, value in dict(opt_level='z', rust_opt_level='z', lto='fat', codegen_units=1, rust_profile='release', go_buildvcs=False).items():
                check(metadata.get(key) == value, f'{tag}: metadata.{key}')
            check(row['concurrency'] == expected['concurrency'], f'{tag}: concurrency')
            check(row['cache_ttl_seconds'] == 0 and row['profiling'] is False and row['recovery_probe'] is False, f'{tag}: experiment mode')
            runtime = row['effective_runtime_env']
            check(runtime['FN_KNOCK_RUNTIME_TARGET'] == 'linux' and runtime['FN_KNOCK_TOKIO_WORKER_THREADS'] == '2', f'{tag}: runtime')
            check(runtime['FN_KNOCK_AUTH_BRIDGE_MAX_IN_FLIGHT'] is None, f'{tag}: capacity override')
            check(runtime['FN_KNOCK_SQLITE_AUTH_READERS'] == ('1' if row['role'] == 'candidate' else None), f'{tag}: reader mode')
            for key in ['GLIBC_TUNABLES', 'LD_PRELOAD', 'MALLOC_ARENA_MAX', 'GOMEMLIMIT', 'GOGC', 'GOMAXPROCS']:
                check(runtime[key] is None, f'{tag}: unexpected {key}')
            renewal = row['scenario'] == 'grant_renewal'
            seed = row['seed']
            check(seed['scenario'] == row['scenario'] and seed['credential_kind'] == expected['credentialKind'], f'{tag}: seed kind')
            for field in ['accounts', 'sessions']:
                check(seed[field] == expected[field], f'{tag}: seed.{field}')
            check(seed['ordinary_grants'] == expected['grants'], f'{tag}: ordinary grants')
            check(seed['renewal_tokens_per_phase'] == (expected['renewals'] if renewal else 0), f'{tag}: renewal pool')
            check(seed['total_grants'] == expected['grants'] + (1 + 2 * expected['renewals'] if renewal else 0), f'{tag}: total grants')
            for point in ['cache_control', 'cache_control_after']:
                control = row[point]
                check(control['runtime_verified'] is True and control['auth_cache_ttl_seconds'] == 0 and control['auth_cache_unauthorized_ttl_seconds'] == 0, f'{tag}: {point}')
            check(row['validation']['passed'] is True, f'{tag}: recorded validation')
            route = row['scenario']
            expectation = 'redirect' if route in ['session_miss', 'grant_miss', 'auto_ip_miss'] else 'session' if route == 'session_api' else 'renewal' if renewal else route if route in ['bootstrap', 'challenge'] else 'origin'
            status = 302 if expectation == 'redirect' else 200
            preflight = row['preflight']
            check(preflight['expected'] == expectation and preflight['status'] == status, f'{tag}: preflight')
            if expectation in ['origin', 'renewal']:
                check(preflight['origin'] == MARKER, f'{tag}: preflight origin marker')
            if renewal:
                check(preflight['renewal'] is True, f'{tag}: preflight renewal')
                check(row['measurement']['requests'] == expected['renewals'] and row['measurement']['all_tokens_consumed'] is True, f'{tag}: finite load tokens')
            for phase, data, counts in [('warmup', row['warmup'], warm_counts), ('load', row, load_counts)]:
                measurement = data['measurement']
                check(measurement['failures'] == 0 and measurement['requests'] == measurement['successful_requests'] and measurement['requests'] > 0, f'{tag}/{phase}: request failures')
                check(measurement['statuses'] == {str(status): measurement['requests']}, f'{tag}/{phase}: statuses')
                check(measurement['anomalies'] == [] and measurement['latency_overflow'] == 0, f'{tag}/{phase}: anomalies/overflow')
                check(sum(n for _, n in measurement['histogram_ms']) == measurement['requests'], f'{tag}/{phase}: histogram total')
                check(all(data['quality'][k] is True for k in ['sampling_ok', 'health_ok', 'client_ok', 'duration_ok']), f'{tag}/{phase}: quality')
                counts.update(measurement['statuses'])
            check(row['directory'] not in trial_directories, f'{tag}: reused trial directory')
            trial_directories.add(row['directory'])
            for component in ['go', 'rust']:
                snapshots = [row['warmup']['resources'][component][point] for point in ['before', 'after']] + [row['resources'][component][point] for point in ['before', 'after']]
                identities = [(x['pid'], x['start_ticks']) for x in snapshots]
                check(len(set(identities)) == 1, f'{tag}: {component} restarted')
                check(identities[0] not in process_ids[component], f'{tag}: {component} reused across trials')
                process_ids[component].add(identities[0])
            summaries.append(dict(route=route, role=row['role'], pair=row['pair'], successful_requests=row['measurement']['successful_requests'], warmup_successful_requests=row['warmup']['measurement']['successful_requests'], elapsed_ms=row['measurement']['elapsed_ms'], seed=seed, preflight=preflight, quality=row['quality'], observation_counts=row['observation_counts']))
        cases.append(dict(name=name, trials=len(rows), options=expected, load_requests=sum(load_counts.values()), load_statuses=dict(load_counts), warmup_requests=sum(warm_counts.values()), warmup_statuses=dict(warm_counts), max_client_event_loop_delay_ms=max(r['measurement']['client_event_loop_delay_max_ms'] for r in rows), max_client_start_delay_ms=max(r['measurement']['client_start_delay_max_ms'] for r in rows), max_sampling_gap_ms=max(r['quality']['max_sampling_gap_ms'] for r in rows), timeout_phase_events=sum(r['observation_counts']['timeout_phase_events'] for r in rows), rows=summaries))
    return dict(schema_version=1, purpose='exploratory_and_correctness_smoke_only', formal_performance_acceptance=False, passed=not errors, errors=errors, inputs=inputs, identities=IDENTITIES, harness_identity=first_harness, evidence_files=[dict(file='evidence/' + p.name, sha256=sha(p)) for p in sorted((directory / 'evidence').iterdir())], total_trials=sum(c['trials'] for c in cases), total_load_requests=sum(c['load_requests'] for c in cases), total_warmup_requests=sum(c['warmup_requests'] for c in cases), unique_process_identities={k:len(v) for k,v in process_ids.items()}, unique_trial_directories=len(trial_directories), cases=cases)


def markdown(summary):
    lines = ['# 最终 v5 预备 smoke 离线审查', '', f"四组共 **{summary['total_trials']} 个 trial**，证据校验结果：**{'通过' if summary['passed'] else '失败'}**。每组每路由仅1对；这是探索和正确性 smoke，不是六对正式收益验收，不计算显著性或宣称性能改进。", '', '| 批次 | c / worker | 账户/session/普通grant | 凭证 | warm/load 发起窗 | trial | 测量请求 | 预热请求 |', '| --- | --- | --- | --- | --- | ---: | ---: | ---: |']
    for case in summary['cases']:
        o=case['options']
        lines.append(f"| {case['name']} | {o['concurrency']}/{o['clients']} | {o['accounts']}/{o['sessions']}/{o['grants']} | {o['credentialKind']} | {o['warmup']}/{o['seconds']}秒 | {case['trials']} | {case['load_requests']:,} | {case['warmup_requests']:,} |")
    lines += ['', f"测量共 {summary['total_load_requests']:,} 次、预热 {summary['total_warmup_requests']:,} 次符合预期的响应；各 trial 记录的失败/异常/直方图溢出均为0，预检和四项质量标志全部通过。测量200/302合计分别为137,126/14,280；302是期望拒绝，不等于授权成功。c64 的10个 trial 均为200、没有503；这只证明本次 N100 短窗完成，不能证明默认容量在任意规模均不会饱和。", '', '最大测量期客户端事件循环延迟 27.36ms、启动延迟 1.295ms、采样间隔 218.60ms。timeout phase 事件计数均为0；不能据此推断 SQLite 或 bridge 等待为0。warmup 没有周期健康采样。', '', 'c1 的 grant_renewal 每端仅8个独立 load token，全部消费；总 grant 数为18（1普通+1预检+8 warm+8 load），完成时间34.839/23.902ms，不是持续3秒的续期吞吐。原始结果含单对延迟/吞吐，但本报告不将其升级为正式收益。', '', '## 身份、隔离与语义范围', '', '- 基线 Rust d4f8805f / Go 92d4c0c；最终候选 Rust 5fddf896 / Go 4d15fa3。四个制品哈希与 v5 固定值完全一致，完整 SHA 见 JSON。各批次 harness/control 指纹一致；本地保存的 seeder、请求规格/验证器和 worker 源文件 SHA 均匹配运行 manifest。', '- 两端 z/fat/CGU1；candidate reader=1，baseline无reader覆盖；Linux、Tokio2、bridge容量无覆盖，正负缓存TTL在每次预检与结束均由runtime控制工具读回0。源码与binary关联仍以构建/运行manifest证据为准，本审查没有反编译或重新获取产品binary。', '- 44个独立Go、44个独立Rust PID/start-tick身份，各自从warmup前至load后保持一致，44个trial目录唯一；这些记录不能独立证明数据库内容全新。', '- 逐请求语义由同指纹worker实时验证：业务路由需origin特征头及正文；session API需authenticated=true；bootstrap需success及client IP；challenge需challenge/signature；miss需302、Location及无origin标记；renewal还需非删除grant Set-Cookie。结果摘要未保留完整响应body/header，本离线步骤核对验证器源码、状态和零失败记录，不能重新执行每次响应的语义判断。', '- password组只覆盖 session_api/session_hit/auto_ip_hit/auto_ip_miss，共8个trial。种子预先创建1000个AuthAccount及TOTP身份，session.method=PASSWORD、credentialId关联account、totpId关联sourceTotpId，权限mode=all；它覆盖已认证session的账户权限读取和auto-IP owner授权。没有执行密码登录、密码hash校验、错误密码、账户变更竞态或密码grant发放，不能称为密码登录性能测试。', '- 固定seeder明确设置mobility=false；seed摘要本身没有独立的mobility读回字段，故这是绑定seeder实现的配置证据，并非本次额外读取SQLite配置。', '', '## 比较边界与离线复跑', '', '**不能跨这些批次绘制并发曲线**：c1=N1，c64=N100，c16=N1000，凭证类型和route集合也不完全相同。同规模c1/c16/c64补测应另行分析。这44个trial不能与正式主矩阵凑成更多独立配对。', '', '仅从远端下载四组已完成的 results.json/manifest.json；没有访问业务端口、运行新负载或编译。download-manifest.json 保存来源和输入校验和；JSON另保留逐trial摘要及检查错误。脚本只读原始输入并覆盖自身生成的两个输出，可把整个目录复制到任意位置离线运行：', '', '```sh', 'python3 summarize-preliminary.py --directory .', '```', '', '复跑使用Python标准库，无仓库路径或/tmp外部依赖，不重新实现bootstrap统计，也不调用远端。输出 PRELIMINARY-REVIEW.md 与 PRELIMINARY-SUMMARY.json；失败时返回非零。']
    if summary['errors']:
        lines += ['', '## 校验失败', ''] + ['- '+x for x in summary['errors']]
    return '\n'.join(lines)+'\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    summary = review(args.directory.resolve())
    (args.directory/'PRELIMINARY-SUMMARY.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
    (args.directory/'PRELIMINARY-REVIEW.md').write_text(markdown(summary))
    print(json.dumps({'passed':summary['passed'], 'trials':summary['total_trials'], 'errors':summary['errors']}, ensure_ascii=False))
    raise SystemExit(0 if summary['passed'] else 1)


if __name__ == '__main__':
    main()
