# concurrency5 离线分析工具

状态：已完成真实补测离线分析。首版 `final-report/` 保留为分析器门禁不一致记录；修正结果在 `final-report-corrected/`。脚本没有网络、SSH、shell/process 调用或负载能力；只读取本地 JSON 与冻结计划，写入一个全新的本地输出目录。不修改输入、不执行 checker、不编译产品、不改仓库。

冻结依据是 `/tmp/fn-knock-auth-concurrency5-prep/manifest.json`，SHA256 为 `0616fe8895470b17f51a33594116dc43a0e6ba4f936cdb266cc9176a424bc0e5`。同时检查该 manifest 记录的 `variants5.json`、runner 与 README SHA。默认使用此准备目录，`--plan` 可指向它的原样副本；不允许静默更换冻结协议。

协议是 **warm5 秒 / load15 秒**，不是 warm20/load60。c1、c16、c64 各有 bootstrap、session_hit、grant_hit、auto_ip_hit 四路由 × 一对 baseline/candidate，共24条；每档固定 AB 顺序。规模固定 accounts=1000、sessions=1000、ordinary grants=100、TOTP、TTL0、无 profile/recovery；Rust z，候选 reader1，Tokio2，正常 bridge capacity 不覆盖。CLI clients2，实际 c1 为1个 worker，c16/c64 为2个。

## 输入布局

原始 runner 本地副本支持：

```text
BATCH/
  c1/results.json
  c1/manifest.json
  c1.contract.json
  c1.validity.json
  c16/...（同上）
  c64/...（同上）
```

也支持收集后的 `concurrency5-c1/`、`concurrency5-c16/`、`concurrency5-c64/`，每个目录内同时有 `results.json`、`manifest.json`、`contract.json`、`validity.json`。普通 `c1/contract.json` 的内置布局也可用。若 sibling 与目录内旁侧文件同时存在，必须逐字节相同，否则失败，避免误读两次不同收集结果。

真实数据使用命令如下；已生成该输出，复跑时把输出换成新的目录：

```sh
python3 -B /tmp/fn-knock-auth-concurrency5-analysis/analyze.py \
  --input /tmp/fn-knock-auth-final5-evidence-collection \
  --out /tmp/fn-knock-auth-concurrency5-analysis/final-report-corrected
```

也可直接指定三档的本地目录：

```sh
python3 -B /tmp/fn-knock-auth-concurrency5-analysis/analyze.py \
  --c1 /LOCAL/BATCH/c1 --c16 /LOCAL/BATCH/c16 --c64 /LOCAL/BATCH/c64 \
  --out /tmp/fn-knock-auth-concurrency5-analysis/final-report
```

路径中的 `/LOCAL/BATCH` 是使用说明占位符；真实输入为第一条命令中的完整只读收集目录。

## 检查与输出

输出 `analysis.md`（中文）、`analysis.json` 与 `OUTPUT-SHA256.json`。成功退出0，任何身份、协议、数量、响应、质量或旁侧校验失败退出2。缺失 contract/validity 时仍保留可读取的 trial 指标，并显著标记未通过；不把缺侧文件误认为成功，不尝试重跑数据或自动修复结果。

- 三档各恰好8条，唯一四路由×pair0×双角色，目录不复用，顺序为冻结 routes 的 baseline→candidate。
- manifest config/options 与冻结 plan 精确相符；检查源码/编译 metadata、四个产品制品 SHA、8个 harness SHA、control SHA、相同 kernel/Node。只检查记录的身份，不读取实际二进制，也不声称重新验证二进制当前内容。
- 种子1000账户/1000session/100普通grant/无renewal token、TOTP；候选 reader1、基线原单reader；Tokio2，capacity/allocator/Go runtime 等无额外覆盖；测量前后实际正/负TTL均为0。
- 验证 preflight status200，bootstrap 语义或真实 owned-origin marker；warm/load成功数、请求数、状态码、anomalies、latency overflow；RPS必须与实际elapsed和计数一致。load四个质量标记必须为true，并重新核对load15秒容忍范围、事件循环/start delay≤100ms、采样gap≤1000ms、有效process/health采样。warm必须达到配置5秒且响应正确；超出5.5秒诊断阈值或warm客户端延迟超100ms保留warning，不新增冻结协议没有的warm质量硬门禁。
- 每进程 CPU/RSS/FD/线程字段必须存在且有效；核对前后PID/start_ticks与CPU差值，CPU ms/千次成功的单位与分母。
- contract 必须明确8条、相应并发、passed=true、performance_acceptance=false；validity 必须是精确四组的数组，一对完整、无错误/重复/不完整、CI为null，其RPS/P99/RSS变化要与trial重新计算一致。

报告按路由展示三档两端RPS、P99和本次观测变化；另外列出每角色 Go/Rust/client/fixture 平均CPU核数、分进程峰值RSS、实测elapsed、event-loop最大延迟和sampling gap。JSON额外保留CPU秒、CPU ms/千次成功、FD/线程、client start delay和采样数量及所有输入SHA。

真实字段是 `resources.<process>.cpu_seconds`、`cpu_ms_per_1000_success`、`peak_rss_bytes`、`peak_fds`、`peak_threads`。平均CPU核数由 `cpu_seconds / (measurement.elapsed_ms / 1000)` 计算，不把CPU秒当占用率；RSS除以1048576得到MiB。Go+Rust RSS使用各自采样峰值相加，与现有比较器一致，不是同一时刻总RSS峰值。

CPU提示规则仅用于提醒：client平均CPU≥有效worker数×85%、fixture≥0.85核，或event-loop≥80ms、sampling gap≥800ms。前两者不是正式gate，也不能单独证明瓶颈；实际请求/质量gate失败则分析失败。c1只有1个worker，不使用“两核”阈值。客户端进程也包含控制线程/GC等，不能将该比值解释为精确worker利用率。

每格仅一次短窗口观测，没有单对CI、显著性或正式收益结论；不推荐据此改默认参数。串行三档与固定AB顺序可能受时间噪声影响。不得与早期 c1/N1 或 c64/N100 拼成同规模曲线，也不得与正式 warm20/load60 六对数据混合统计。

本工具只用汇总与旁侧文件，无法重算raw样本的时间走势或独立验证每个响应体；业务语义依据已有preflight、逐响应validator后的零failure和冻结harness身份。它不读取DB、凭据、日志、raw响应头或二进制，不输出未选择的自由文本错误/headers。

## 已执行的离线验证

```sh
python3 -B /tmp/fn-knock-auth-concurrency5-analysis/test_analyze.py
python3 -B /tmp/fn-knock-auth-concurrency5-analysis/analyze.py --help
```

测试完全采用虚构数据：三组成功fixture、45个失败变体（身份/数量/TTL/env/尺度/时长/质量/计数/缺CPU/合同/伪CI等）、CPU接近限制提示、两种旁侧布局及冲突拒绝。追加测试验证5802.480ms预热且duration_ok=false须保留warning，预热响应failure仍失败。测试临时文件只放本工具目录并自动清理。

## 首轮分析器门禁差异

真实 c64 baseline auto_ip_hit 的 warmup 实际为5802.480224609375ms，`warmup.quality.duration_ok=false`，448次预热响应均200、零失败。其load为15604.21240234375ms，位于15000+750ms范围，四个load质量标记和validation通过、零失败。冻结harness只检查预热响应正确性，未将warmup.duration_ok纳入总validation。首版分析器额外将5.5秒预热上限设为硬门禁，导致唯一误报；保留原报告，不修改任何输入。修正后明确warning，不能声称所有阶段质量均通过。该记录不代表性能实验重跑。
