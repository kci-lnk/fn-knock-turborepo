# 鉴权性能实验结果

记录 2 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| auto_ip_hit/16/candidate5/cache-0/profile-off/recovery-on/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +81.6% | -32.2% | 不足6对 | 不足6对 | -1.3% | -13.1% | -7.6% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| auto_ip_hit/16/candidate5/cache-0/profile-off/recovery-on/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 88.6 | 211.0 | 752.7 | 18638.0 | 39.37 → 39.29 | 43.91 → 43.54 | 0 |
| auto_ip_hit/16/candidate5/cache-0/profile-off/recovery-on/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 161.0 | 143.0 | 564.5 | 6491.9 | 38.84 → 38.84 | 38.14 → 37.76 | 0 |

| 恢复探测 / 角色 | burst状态码计数 | 2秒连续成功 | 恢复完成ms | 检查次数 |
| --- | --- | --- | ---: | ---: |
| candidate5/auto_ip_hit/baseline | {"200":185,"503":18182} | 是 | 2061.0 | 1 |
| candidate5/auto_ip_hit/candidate | {"200":288,"503":20974} | 是 | 2051.3 | 1 |

恢复探测的burst及恢复检查不进入性能measurement；只有实际观测到503/pressure证据时才能声称测试覆盖了饱和。恢复完成时间包含成功窗口本身，最后的health读取与采样清理可能在此之后结束。这些trial不能支持六对性能收益声明。

SQLite primary采样最大队列深度 14，最大队列等待 22.0ms，最大活动操作 0.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
