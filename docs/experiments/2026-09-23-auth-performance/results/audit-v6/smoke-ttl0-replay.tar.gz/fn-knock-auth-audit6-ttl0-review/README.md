# audit6 smoke / TTL0 本地复核包

本目录只收集 audit6 的 smoke18 与 session-ttl0 六对12 trial，不读取 TTL1、soak 或 recovery，不与任何 v5 数据合并。

两组已完成并通过，远端采集已停止。TTL0 六对配对中位变化为 RPS +0.4008%、P99 +1.1905%、Go+Rust 分别采样峰值 RSS 之和 +0.5518%，满足原非回退门槛。吞吐和 P99 的 95% 区间均包含零，不声称加速。全部数值、每对明细和范围限制见 `analysis/REVIEW.md` 与 `analysis/SUMMARY.json`。

`pull-readonly.py` 是限定文件清单的 SSH 只读采集器；只从固定 audit6-final 路径读取 JSON/报告，写入本地 inputs。它不运行服务、不访问业务端口、不修改远端。写入中的不完整 JSON 会留到下一次读取。两阶段完成后停止使用采集器。

离线分析无需 SSH、原服务、原绝对本地路径：

```sh
python3 -B summarize.py
# 或指定已复制的目录：
python3 -B summarize.py --input ./inputs --plan ./plan --tools ./tools --out ./analysis
```

结果为 `analysis/REVIEW.md` 和 `analysis/SUMMARY.json`，附 exact contract 和冻结 gate 的离线复算输出。只有两阶段都有完整 outcome 且所有复核通过，状态才为 passed；中途数据为 checkpoint。script 将直接读取已复制的冻结 check-plan.py，统计门槛由三份逐字节 SHA pin 的 scripts5 工具复算，没有另写 bootstrap 或验收算法。

plan 包是只读身份快照；本复核不运行其中的 run-audit6.sh。inputs 不包含大型 raw samples，因此此报告只能核对 harness 已保存的 quality/资源摘要，不能从原采样独立重建 RSS 峰值。资源单位与统计边界见报告。

## 标准 collector 的输入映射

依赖仅 Python 3 和 Node.js；无需第三方 Python 包。将整个本目录复制到任意位置，在该目录运行上述命令即可。脚本中的远端绝对路径仅用于核对已保存的身份字段，不访问这些路径。

Root 的统一 collector 使用 `case/{results,manifest,outcome,contract,gate}.json`、`case/report.md` 和 `support/prepared-manifest.json`。以下命令映射为一个**新目录**，不覆盖本包独立采集的 `inputs`：

前置条件：root 已用标准 collector 完成整份归档的 verify，包括索引哈希和采集期间源文件未变化的检查。此适配器仅检查本范围 13 份文件的映射、字节和已声明来源，不代替整份归档审核，也不独立校验 `INDEX-SHA256`、`source_consistency_checked` 或 `sources_changed_during_collection`。

```sh
python3 -B adapt-collector.py --collection /path/to/audit6-collection --out /path/to/NEW-smoke-ttl0-view
python3 -B summarize.py --input /path/to/NEW-smoke-ttl0-view --out /path/to/NEW-smoke-ttl0-analysis
```

适配器读取 `collection.json.collected` 中的 `source/relative/source_sha256/collected_sha256` 及字节数。它先验证实际归档字节的 collected 哈希，再将 source 哈希与 outcome 的原始证据哈希比较；collector 的 JSON 重新编码或脱敏会使两种哈希不同，不能混用。生成的 `source-index.json` 保留两者及 collection 索引哈希。最终合同、来源、有效参数和 gate 仍按冻结计划检查；适配器不校验本范围外的 TTL1/soak/recovery，也不读取 raw。

独立采集的 `collection.json` 保留当时写入本地的 20 份文件哈希/字节数；`inputs/*.outcome.json.evidence` 是远端 runner 记录的原始结果、manifest、contract、gate、report 源哈希，与本地副本逐字节吻合。outcome 本身、stderr 和 started 时间只有采集副本哈希，未另取独立远端哈希；prepared manifest 另受冻结计划 SHA pin。`REPLAY-MANIFEST.json` 记录这些来源区别，不补造证据。

## 已完成的离线工具验证

```sh
python3 -B test-analysis.py
python3 -B test-portability.py
```

第一组覆盖混合采集快照和缺测量字段的失败行；第二组覆盖换目录后完整 SUMMARY 相同、重新编码 JSON 的 collector 格式映射保持合同/指标/gate 相同、篡改归档字节立即拒绝。它们只用临时副本，不是新性能 trial。标准 collector 适配目前通过格式测试，真实完整 45 条 collector 的重放由 root 最后统一执行。
