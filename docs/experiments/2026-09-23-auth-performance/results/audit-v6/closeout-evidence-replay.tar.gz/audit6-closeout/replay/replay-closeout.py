#!/usr/bin/env python3
"""Offline audit6 completed-scope closeout replay. No SSH, listeners, binaries or workload."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path

FROZEN_MANIFEST_SHA='87e69d8e1dedce80e7ddb6ea574fa1145975123cdca60b3b662f0637a78002ce'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,msg):
    if not ok:raise ValueError(msg)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence',type=Path,required=True)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--tools',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--node',default='node')
    args=parser.parse_args();e=args.evidence.resolve();p=args.plan.resolve();t=args.tools.resolve();out=args.out.resolve()
    check(not out.exists(),'output already exists')
    check(sha(p/'manifest.json')==FROZEN_MANIFEST_SHA,'frozen plan identity')
    m=load(p/'manifest.json');index=load(e/'collection.json');by_source={i['source']:i for i in index['collected']}
    for name,value in m['tools']['files'].items():check(sha(t/name)==value,'frozen tool identity: '+name)
    out.mkdir(parents=True)
    stages=[]
    def run(name,command):
        r=subprocess.run(command,capture_output=True)
        (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
        stages.append({'name':name,'exit_code':r.returncode})
        check(r.returncode==0,'replay failed: '+name)
        return r.stdout
    run('collector-integrity',[sys.executable,str(Path(__file__).with_name('collect-final5.py')),'verify','--spec',str(e/'REVIEW-SPEC.json'),'--out',str(e)])
    run('frozen-plan',[sys.executable,str(p/'check-plan.py'),'verify'])
    names=[j['name'] for j in m['jobs'][:3]]
    batch=load(e/'support/outcome.json')
    check(batch['passed'] is False and batch['exit_code']==143 and batch['failed_case']=='soak-ttl1','original interrupted batch outcome')
    check((e/'support/completed-cases.txt').read_text().splitlines()==names,'completed cases')
    check(not (e/'support/completed-utc.txt').exists(),'must not claim batch completion')
    interrupted=load(e/'interrupted/soak-ttl1.outcome.json')
    check(interrupted['passed'] is False and interrupted['exit_code']==143,'interrupted soak outcome')
    check(all(interrupted['stages'][k]['executed'] is False for k in ['contract','gate','report']),'soak must not claim validation')
    for rel,identity in interrupted['evidence'].items():
        item=by_source.get(m['remote_batch']+'/'+rel)
        if item is not None:check(item['source_sha256']==identity['sha256'],'interrupted source identity')
        else:check(rel=='soak-ttl1.run.log','uncollected interruption evidence')
    for source in [m['remote_batch']+'/prepared-manifest.json',m['remote_bundle']+'/manifest.json']:
        check(by_source[source]['source_sha256']==FROZEN_MANIFEST_SHA,'remote frozen manifest')
    processes=[];directories=[];measure=warm=0;omitted=[];cases=[]
    for job in m['jobs'][:3]:
        name=job['name'];directory=e/name;rows=load(directory/'results.json')['runs'];outcome=load(directory/'outcome.json')
        check(outcome['passed'] is True and outcome['exit_code']==0 and outcome['case']==name,'case outcome: '+name)
        check(outcome['gate_flags']==(['--require-six-pairs'] if name.startswith('session-ttl') else []),'case flags: '+name)
        check(set(outcome['stages'])=={'harness','contract','gate','report'} and all(v['executed'] is True and v['exit_code']==0 for v in outcome['stages'].values()),'stage outcomes: '+name)
        for rel,identity in outcome['evidence'].items():
            source=m['remote_batch']+'/'+rel;item=by_source.get(source)
            if item is None:
                check(rel==name+'.run.log','uncollected outcome input: '+rel)
                omitted.append({'source':source,'reason':'Excluded logs; source SHA retained only, content not independently replayed.'})
            else:check(item['source_sha256']==identity['sha256'] and item['source_bytes']==identity['bytes'],'outcome input identity: '+rel)
        actual=json.loads(run(name+'-contract',[sys.executable,str(p/'check-plan.py'),'contract',name,str(directory)]))
        recorded=load(directory/'contract.json');actual.pop('inputs',None);recorded.pop('inputs',None)
        check(actual==recorded,'contract differs: '+name)
        if name=='soak-ttl1':
            source=rows[0]['raw_result_file'];raw=e/by_source[source]['relative']
            result=json.loads(run(name+'-summary',[args.node,str(t/'auth-performance-soak.mjs'),str(raw)]))
            check(result==load(directory/'soak-summary.json'),'soak differs')
            check(result['completed_30_minutes_without_request_or_quality_failure'] is True,'soak incomplete')
            check(load(directory/'gate.json')=={'passed':True,'completion_only':True,'resource_growth_gate':False},'soak gate')
        else:
            command=[args.node,str(t/'check-auth-performance.mjs'),str(directory/'results.json')]
            if name.startswith('session-ttl'):command.append('--require-six-pairs')
            check(json.loads(run(name+'-gate',command))==load(directory/'gate.json'),'gate differs: '+name)
        report_input=load(directory/'results.json')
        for row in report_input['runs']:
            source=row.get('raw_result_file',row.get('directory','')+'/result.json')
            check(source in by_source,'report raw source absent: '+source)
            row['raw_result_file']=str(e/by_source[source]['relative'])
        report_path=out/(name+'-report-input.json')
        report_path.write_text(json.dumps(report_input,indent=2)+'\n')
        report=run(name+'-report',[args.node,str(t/'report-auth-performance.mjs'),str(report_path)])
        check(report==(directory/'report.md').read_bytes(),'report differs: '+name)
        for r in rows:
            directories.append(r['directory']);measure+=r['measurement']['successful_requests'];warm+=r['warmup']['measurement']['successful_requests']
            for component in ['go','rust']:
                before=r['resources'][component]['before'];processes.append((component,before['pid'],before['start_ticks']))
        cases.append({'name':name,'trials':len(rows),'contract_equal':True,'gate_replayed':name!='soak-ttl1','soak_summary_equal':True if name=='soak-ttl1' else None,'report_equal':True})
    check(len(directories)==len(set(directories))==42,'42 unique completed trials')
    check(len(processes)==len(set(processes))==84,'84 unique completed product process identities')
    result={'schema_version':1,'completed_scope_replay_passed':True,'full_batch_completed':False,'interruption_exit_code':143,'frozen_manifest_sha256':FROZEN_MANIFEST_SHA,'completed_trials':42,'original_planned_trials':45,'unique_product_processes':84,'measurement_expected_responses':measure,'warmup_expected_responses':warm,'cases':cases,'stages':stages,'excluded_log_content':omitted,'notes':['This is offline replay, not new benchmark data.','Earlier 273 v5 trials are not pooled.','User requested prompt closeout. Soak interrupted before completion; recovery not executed. No passing claim for either.']}
    (out/'replay-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
