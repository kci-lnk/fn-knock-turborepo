# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +80.2% | -30.8% | 不足6对 | 不足6对 | +1.3% | -6.4% | -2.6% |
| session_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +50.5% | -27.3% | 不足6对 | 不足6对 | +0.0% | -7.3% | -3.6% |
| grant_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +139.3% | -44.4% | 不足6对 | 不足6对 | +0.9% | -2.2% | -0.6% |
| auto_ip_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +62.1% | -38.9% | 不足6对 | 不足6对 | -0.7% | -2.7% | -1.7% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 131.3 | 13.0 | 659.6 | 6184.7 | 36.41 → 36.41 | 37.66 → 37.66 | 0 |
| bootstrap/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 236.6 | 9.0 | 521.3 | 3274.2 | 36.90 → 36.56 | 35.24 → 35.07 | 0 |
| session_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 154.2 | 11.0 | 933.9 | 4760.1 | 38.97 → 38.97 | 37.36 → 37.36 | 0 |
| session_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 232.1 | 8.0 | 823.8 | 2950.6 | 38.98 → 38.98 | 34.62 → 34.34 | 0 |
| grant_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 193.0 | 9.0 | 883.7 | 3831.5 | 38.49 → 38.49 | 35.52 → 35.52 | 0 |
| grant_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 461.9 | 5.0 | 760.5 | 1207.8 | 38.84 → 38.64 | 34.74 → 34.74 | 0 |
| auto_ip_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 83.2 | 18.0 | 1104.9 | 10296.2 | 38.54 → 38.25 | 38.07 → 37.80 | 0 |
| auto_ip_hit/1/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 134.9 | 11.0 | 973.3 | 5938.7 | 38.26 → 38.21 | 37.05 → 37.05 | 0 |

SQLite primary采样最大队列深度 0，最大队列等待 0.0ms，最大活动操作 1.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
