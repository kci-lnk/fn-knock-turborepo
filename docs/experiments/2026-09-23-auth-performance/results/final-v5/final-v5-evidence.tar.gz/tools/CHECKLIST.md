# v5 最终收集准备与复核清单

状态：仅准备，没有执行收集、负载、编译、管理端请求或远端写入。审阅范围为冻结 `scripts5` 对应的收集器协议、post5 runner/jobs、并发补充 runner/manifest 与总收集计划。目录中的脚本只写调用者指定的新本地输出目录；远端 Python 通过 SSH 的 stdin/`-c` 执行只读导出，不在远端创建脚本、缓存或目录。

## 预期证据边界

总计划 `/tmp/fn-knock-auth-final5-all-collection-plan.json`：22 个 job、261 条 trial。

| 组 | trial 数 | 解释 |
| --- | ---: | --- |
| accounts1000-c16-v5 | 6 | 三路由，一对 |
| smoke-v5-c1 | 20 | 十路由，一对；renewal 为 8 个独立 token |
| smoke-v5-c64 | 10 | 五路由，一对，N100 |
| password-v5-c16 | 8 | 四路由，一对，N1000 Password AuthAccount |
| formal-v5-main | 108 | 九路由 × 六对 × 双角色 |
| post5-cache / renewal | 12 + 12 | 分别六对；TTL1 / TTL0 |
| post5-grants-1000 / 10000 | 2 + 2 | c1 普通 grant 规模探索 |
| post5 reader2 / reader4 | 8 + 8 | 四路由，一对 |
| post5 compiler s / 2 / 3 | 8 + 8 + 8 | 四路由，一对 |
| profile primary / reader2 / reader4 | 6 + 4 + 4 | 诊断数据，不能与未插桩收益混算 |
| candidate-only soak | 1 | auto_ip_hit，1800 秒；不是 A/B pair |
| recovery | 2 | 独立 MAX_IN_FLIGHT=32 故障注入 |
| concurrency c1 / c16 / c64 | 8 + 8 + 8 | 同规模短测，一对；不得当作六对正式收益 |

全齐时白名单预期至少 361 个源文件：261 个 raw trial、44 个 results/manifest、37 个必需 case 旁侧文件、19 个全局文件。`${output}.outcome.json` 若存在额外收集；post/concurrency runner 自己不生成该文件。收集目录另有 `collection.json`、`REVIEW-SPEC.json`、`MASTER-COLLECTION-PLAN.json`、`REVIEW.json` 和 `INDEX-SHA256.json`，不要把这些当 trial。

## 标准 collect 的缺口

原 `scripts/auth-performance-suite.mjs collect` 只保存每 job 的 `results.json`、`manifest.json`、可选 sibling `.outcome.json` 和每个直接子目录 `result.json`。它会静默跳过不存在的文件，没有固定 trial 数量验收。它不会保存下面的旁侧文件。

- post5 cache、renewal：各 `.acceptance.json` 和 `.report.md`。
- grants 两组、reader 两组、compiler 三组、profile 三组、recovery 一组：各 `.validity.json` 和 `.report.md`。`validity.json` 是 comparison **数组**，文件存在本身不证明 checker 退出成功；还要对应完成标记和无效/重复/不完整计数为零。
- soak：`.soak-summary.json` 和 `.report.md`。
- concurrency c1/c16/c64：各 `.contract.json`、`.validity.json`、`.report.md`。
- post batch：`main.acceptance.json`、`prepared-bundle-manifest.json`、`completed-cases.txt`。
- concurrency batch：`prepared-manifest.json`、`started-utc.txt`、`completed-utc.txt`、`completed-groups.txt`。
- 全局：`EXPERIMENT_PLAN5.json`、`host-environment.json`、`readiness5.json`；post 冻结计划/任务/runner/README/manifest；concurrency 冻结 manifest/runner/README。

Profile 没有必须额外搜寻的独立 profile 文件：`profile_idle`、`profile_start`、`profile_capture`、`operation_profile`、运行 TTL 读回等在 raw `result.json`。汇总 `results.json` 不含完整 `samples`、`runtime_health`、`timeout_phase_events`，必须保留全部 raw。`failure_health`、`failed_phase` 和 recovery burst/check 数据也需要 raw。

已在本仓另行保留的正式主矩阵本地复算报告、验收、构建 manifest、Go 直接 92→4d 六对微基准、语义测试记录与被否决 v4/旧候选归档是交付的其他组成部分；本 helper 不将它们与远端原始 trial 混入。root 仍须在最终报告链接这些已有文件。冻结工具实际源码可从已归档 tools snapshot/对应仓库 commit 复现，helper 保留其 SHA，不复制可执行二进制。

## 准备的命令（本次未执行 collect）

默认只展示计划；`selftest` 与 synthetic test 仅用本机虚构数据，不访问 SSH。

```sh
/tmp/fn-knock-auth-final5-collection-review/collect-final5.py show
python3 -B /tmp/fn-knock-auth-final5-collection-review/collect-final5.py selftest
python3 -B /tmp/fn-knock-auth-final5-collection-review/test-collector.py
```

等 post 和 concurrency 都退出并确认不再写这些结果后，再由 root 执行一次（路径必须不存在）：

```sh
python3 -B /tmp/fn-knock-auth-final5-collection-review/collect-final5.py collect \
  --out /tmp/fn-knock-auth-final5-evidence-collection
```

脚本不会等待/重试实验、发信号给实验进程、调用 checker、读服务端口或启动负载。缺文件或验收不一致会保留已收集文件并退出 2；不要把失败输出替换成成功结果。若读取 JSON 正在写入或文件格式损坏，导出失败，原远端证据不变。若 root 改了总计划，脚本会在收集前拒绝，应先更新清单而非绕过 hash。

完成后的纯本地复核（不重新收集）：

```sh
python3 -B /tmp/fn-knock-auth-final5-collection-review/collect-final5.py verify \
  --out /tmp/fn-knock-auth-final5-evidence-collection \
  > /tmp/fn-knock-auth-final5-evidence-verification.json
```

确认 `REVIEW.json.complete_and_consistent=true`、261/261、22 个 job 各自齐全，才可打包这一个新收集目录。`tar` 不要指向原始实验根目录。打包后另算 archive SHA256/bytes，记录到交付 manifest；不要给归档文件自身循环写入自己的 hash。这里不预先执行打包。

## 双 SHA 与完整性检查

- 每个白名单源文件在远端读取，记录原始 UTF-8 bytes 的 `source_sha256`。JSON 在远端去敏并规范化后传输，记录 `collected_sha256`。两个 hash 不必相同。
- 文件读取前后检查 inode/长度/mtime；导出全部文件后，再读所有已导出源文件核验 SHA 未变。结果写在 `sources_changed_during_collection`，必须为空。
- 本机收到的数据先验证 collected SHA 再写文件；`verify` 重算全部 collected SHA，并检查 review spec 与总计划 hash。它不单独核验 `INDEX-SHA256.json`；打包前须另按该文件核验四个本地索引/复核文件。`collection.json` 与 `INDEX-SHA256.json` 再由最终 tar SHA 绑定。
- `.acceptance.json.inputs.*.sha256` 必须匹配对应文件的 **source SHA**。不能拿去敏/pretty-print 后的 collected SHA 与 acceptance input 比较。两个冻结主计划路径都收集，避免 path 不同却内容相同造成错误映射。
- 各 job 使用冻结的 routes×pairs×roles，检查唯一 `(scenario,pair,role)`、AB/BA 顺序、raw 文件数量、raw 与 aggregate 的 measurement/resources/quality/validation/seed/TTL 相等。
- 核验配置选项、种子规模、普通/续期 token 数、四个已记录 artifact SHA、8 个 harness 文件 SHA、control SHA；此处是对 trial 保存的身份做复核，不声称重新哈希仍在远端的二进制。
- 对 profile 与 recovery 使用实际 JSON 字段；普通模式不允许 bridge capacity override。case 完成标记顺序必须与冻结 jobs 一致。

## 内容隐私白名单

只收集显式文件名。不复制整个实验目录，不读取 `data.db`/WAL/SHM、生成 config、`configs/`、`variants5.json`、seed 目录、key/token/session 文件、assets、任何二进制或 `.run.log`/runtime 日志。manifest 内的 fixture 路径和非凭据运行参数属于 provenance；其敏感字段字符串仍去敏。

原 collector 的敏感 key regex 只处理 snake_case/string，camelCase 或字符串数组可能漏过。本 helper 支持 camelCase、数组和嵌套敏感字符串，保留数字计数与 `credential_kind`，并去掉异常/message/body/header 字符串，防止错误消息带出凭据。JSON 中匹配 JWT、Bearer/Basic、Cookie header、PEM private key、synthetic session/grant token 的字符串整体替换。生成 report/marker 与已审 runner 是唯一允许的非 JSON 文件，命中明显秘密模式即拒绝；不尝试把不受控日志自动洗成公开文件。

去敏会使某些错误的自由文本变成 `[REDACTED]`；失败状态、计数、pressure/health/phase 数值保留，原始错误仍留远端。不应宣称本脚本是适用于任意 JSON 或任意日志的通用防泄漏工具。若出现此前未审阅的新字段/新 sidecar，先审阅 schema 并加白名单，不能放宽成递归复制所有 JSON。

## 最终人工判读

- 正式主矩阵 108 条、cache/renewal 各 12 条都独立保留。缓存 TTL1 是正常缓存开启工作负载，不是假定 100% 命中；没有已存 RPC/cache counter 就不计算精确命中率。
- renewal 是每 trial 64 个独立 token，使用 `measurement.elapsed_ms`（实测不足 1 秒），不能以配置上限 60 秒作分母。`all_tokens_consumed`、64 次成功、零 failures、真实业务 marker 与非删除 grant Set-Cookie 由已有 response validator 约束；没有独立 Set-Cookie 数量字段，勿虚构该计数。
- `profile_capture` stopped、dropped=0、请求分母与成功数相同；保留 idle 对照、operation 全列表、in-flight 与 auth-reader 子项。`sqlite_admission` 是等待 scope，`sqlite_primary/sqlite_auth_read` 是 executor job；都不等于 SQL 语句数，也不覆盖 checkpoint gate 等待。后台操作和短时窗口不能被忽略。
- soak 唯一 candidate raw 保留 1800 秒 elapsed、所有资源和 health 样本。检查零请求/质量失败、RSS/FD/线程的五分钟首尾中位与峰值、Go goroutine 有效样本数；OS 线程不能当 Rust async task 数。`completed_30_minutes_without_request_or_quality_failure` 没有 RSS 增长门槛，不证明无泄漏；报告实际走势与短时稳定性的边界。
- recovery 的 capacity32 是刻意故障注入，与正常 Go1024/Rust64 默认分开。burst 状态码/pressure、10秒内恢复连续2秒成功、恢复检查及后续正常 warm/load 都要保留。若 burst 没有503，不能声称已观察拒绝后的恢复。burst 的503不能并入正常性能 measurement。
- concurrency 补充 24 条同规模、同 warm5/load15、TTL0、N1000；仅单对探索，无收益/默认参数结论。c64 若出现503则如实保留失败；不能重跑替换初始失败结果。
- 对所有组报告 client 与 fixture CPU、事件循环延迟、采样 gap；若客户端接近两个 CPU，则吞吐受客户端限制的可能性需要说明。内存比较使用 Go+Rust 合计 RSS，同时保留分进程变化，不合并不同规模/credential/profile/recovery 组。

本次已执行的验证：脚本 import/语法、canary 敏感字段与数组、路径穿越拒绝、261-count spec、自造有效 comparison 数组、gate source SHA 不匹配、传输内容 SHA 不匹配、缺 trial 的离线测试。没有执行真实证据收集。
