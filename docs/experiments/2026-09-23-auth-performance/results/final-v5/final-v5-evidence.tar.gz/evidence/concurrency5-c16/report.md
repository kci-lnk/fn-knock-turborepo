# 鉴权性能实验结果

记录 8 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +165.0% | -57.6% | 不足6对 | 不足6对 | +4.3% | -12.1% | -4.2% |
| session_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +161.2% | -61.4% | 不足6对 | 不足6对 | +2.9% | -9.8% | -3.5% |
| grant_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +272.6% | -67.6% | 不足6对 | 不足6对 | -3.0% | -1.9% | -2.5% |
| auto_ip_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +114.9% | -54.2% | 不足6对 | 不足6对 | +1.9% | -11.3% | -5.0% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 147.4 | 132.0 | 473.0 | 8891.9 | 39.14 → 39.14 | 41.60 → 40.75 | 0 |
| bootstrap/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 390.6 | 56.0 | 412.3 | 3182.8 | 40.81 → 40.27 | 36.56 → 36.03 | 0 |
| session_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 186.2 | 114.0 | 575.4 | 8381.0 | 41.02 → 40.37 | 42.07 → 41.52 | 0 |
| session_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 486.5 | 44.0 | 462.7 | 2893.9 | 42.20 → 41.92 | 37.95 → 35.01 | 0 |
| grant_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 277.0 | 71.0 | 543.1 | 3547.2 | 41.73 → 41.73 | 35.91 → 35.91 | 0 |
| grant_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1032.0 | 23.0 | 538.3 | 1015.4 | 40.47 → 40.05 | 35.21 → 35.18 | 0 |
| auto_ip_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 83.1 | 225.0 | 801.6 | 20039.7 | 39.18 → 39.18 | 42.43 → 41.44 | 0 |
| auto_ip_hit/16/candidate5/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 178.6 | 103.0 | 461.3 | 6201.6 | 39.92 → 39.80 | 37.63 → 36.94 | 0 |

SQLite primary采样最大队列深度 24，最大队列等待 87.0ms，最大活动操作 5.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
