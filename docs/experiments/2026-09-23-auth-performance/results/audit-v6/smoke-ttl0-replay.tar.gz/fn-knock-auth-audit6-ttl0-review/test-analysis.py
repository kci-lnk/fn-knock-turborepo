#!/usr/bin/env python3
"""Offline failure-path tests on temporary synthetic copies; originals unchanged."""
import json,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
cases=[]
for kind in ['mixed_collection','failed_preflight_row']:
    with tempfile.TemporaryDirectory(prefix='auth-audit6-analysis-test-') as temporary:
        tmp=Path(temporary);inputs=tmp/'inputs';shutil.copytree(ROOT/'inputs',inputs)
        p=inputs/'smoke/results.json';r=json.loads(p.read_text())
        if kind=='mixed_collection':r['runs'].pop()
        else:
            for field in ['measurement','resources','quality','observation_counts']:r['runs'][-1].pop(field,None)
            r['runs'][-1]['validation']={'passed':False,'error':'SYNTHETIC preflight failure'}
            op=inputs/'smoke.outcome.json';o=json.loads(op.read_text());o.update(passed=False,exit_code=20);op.write_text(json.dumps(o))
        p.write_text(json.dumps(r))
        process=subprocess.run([sys.executable,'-B',str(ROOT/'summarize.py'),'--input',str(inputs),'--out',str(tmp/'out')],capture_output=True,text=True)
        result=json.loads((tmp/'out/SUMMARY.json').read_text())
        expected='incomplete_collection' if kind=='mixed_collection' else 'failed'
        assert result['cases']['smoke']['status']==expected,(kind,result,process.stderr)
        assert process.returncode==(0 if kind=='mixed_collection' else 1),(kind,process.returncode,process.stderr)
        cases.append({'case':kind,'passed':True})
print(json.dumps({'synthetic_only':True,'original_evidence_modified':False,'network_access':False,'cases':cases},indent=2))
