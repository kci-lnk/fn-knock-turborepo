# c64 session_hit 独立确认只读复核

本工具仅分析新确认实验的12条trial，**不纳入原261条**。冻结计划 SHA256 为 `35899a5ade46d210c2da17fa3c018d4b31ff569d2586a1e458c262a88b38b408`，源码为 Rust d4f8805f→5fddf896、Go92d4c0c→4d15fa3；四个制品和运行参数由同目录plan固定。

`pull.py` 通过SSH只读本次batch显式白名单：prepared manifest、started/finished/completed标记、harness results/manifest、contract、gate、report和outcome。无服务端口请求、远端写入、信号、负载或编译；不读DB、生成凭据config、日志、二进制。JSON字符串敏感字段会去敏；SOURCE-HASHES同时记录原source SHA与collected SHA，gate/contract/outcome引用源hash时使用source SHA，不混用。

```sh
python3 -B pull.py --host root@192.168.31.98 --out inputs
python3 -B analyze.py --input inputs --out .
```

后一个命令完全离线；可将整个目录移到其他机器，仅用Python3和标准库复跑。只需保留 `analyze.py`、`contract_checker.py`、`plan.json`、`variants5.json` 和 `inputs/`。`variants5.json` 只是已审的制品/静态目录路径及非凭据参数，没有生成数据库或密钥。前一个命令仅在需要重新读取远端时使用，不是离线复跑所需。

`review.json` 和 `review.md` 可在监测过程中更新；未有outcome时明确 `state=running`、`final_acceptance_passed=null`，不足6pair不能当验收。结束后复核exact12/6pair、ABBA、config/身份/TTL/种子/源SHA与原冻结gate、runner outcome。门槛保持RSS合计配对中位≤+5%、RPS≥−5%、P99≤+10%，且RPS≥+10%与paired95%下界>0，或P99≤−15%与paired95%上界<0。缺数据或失败原样保留，分析器不重跑checker/负载、不改门槛。

报告包含每对RPS/P99和Go/Rust/合计RSS变化、各角色六trial中位数、CPU秒/平均占用核数、FD/线程和client质量。CPU核数用CPU秒÷实测elapsed；RSS是两个进程各自采样峰值之和。client≥1.7核或fixture≥0.85核只提示可能限制，不能单凭此归因。预热超时诊断单列，不新增冻结harness没有的warm duration硬门槛。

本次仅取必要的汇总/旁侧小文件，没有下载raw时间曲线，不能推断内存泄漏或精确RPC/cache命中率。root另行负责完整原始归档。读取时遇写入中/JSON不完整会失败且保留旧本地快照，不据此判定实验失败；以新成功快照和最终outcome为准。

`python3 -B test_analysis.py` 执行纯合成门槛复核测试，无网络或实验。
