#!/usr/bin/env node
// Offline only. Imports the exact frozen statistics and soak implementation.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const options = {};
for (let i = 0; i < args.length; i++) {
  const flag = args[i];
  if (flag === '--partial') { options.partial = true; continue; }
  assert(['--input-dir', '--plan-dir', '--tools-dir', '--source-index', '--out'].includes(flag), `unknown option ${flag}`);
  assert(args[i + 1] && !args[i + 1].startsWith('--'), `missing value for ${flag}`);
  assert(options[flag] === undefined, `duplicate option ${flag}`);
  options[flag] = path.resolve(args[++i]);
}
const partial = options.partial === true;
const load = p => JSON.parse(readFileSync(p, 'utf8'));
const sha = p => createHash('sha256').update(readFileSync(p)).digest('hex');
const inputDir = options['--input-dir'] ?? path.join(root, 'inputs');
const planDir = options['--plan-dir'] ?? path.join(root, 'frozen-plan');
const toolDir = options['--tools-dir'] ?? path.join(root, 'frozen-tools');
const plan = load(path.join(planDir, 'manifest.json'));
for (const [name, hash] of Object.entries(plan.tools.files)) {
  assert.equal(sha(path.join(toolDir, name)), hash, `frozen tool ${name}`);
}
for (const [name, hash] of Object.entries(plan.files)) {
  assert.equal(sha(path.join(planDir, name)), hash, `frozen plan ${name}`);
}
const { compareRuns, comparisonFailures } = await import(pathToFileURL(path.join(toolDir, 'auth-performance-lib.mjs')));
const { summarizeSoak } = await import(pathToFileURL(path.join(toolDir, 'auth-performance-soak.mjs')));
const sourceIndex = options['--source-index'] ?? path.join(root, 'source-files.json');
const sourceIndexData = load(sourceIndex);
const inScopeSource = source => {
  if (!source.startsWith(plan.remote_batch + '/')) return false;
  const relative = source.slice(plan.remote_batch.length + 1);
  return /^(session-ttl1|soak-ttl1|recovery)(\/|\.)/.test(relative)
    || ['outcome.json', 'prepared-manifest.json', 'started-utc.txt', 'finished-utc.txt', 'completed-utc.txt', 'completed-cases.txt'].includes(relative);
};
const index = Array.isArray(sourceIndexData.collected)
  ? Object.fromEntries(sourceIndexData.collected
    .filter(r => inScopeSource(r.source))
    .map(r => [r.source.slice(plan.remote_batch.length + 1), {
      source_path: r.source, local_relative: r.relative,
      source_sha256: r.source_sha256, collected_sha256: r.collected_sha256,
      bytes: r.collected_bytes, source_bytes: r.source_bytes,
      byte_preserved: r.source_sha256 === r.collected_sha256,
      redacted_strings: r.redacted_strings,
    }]))
  : sourceIndexData;
assert(Object.keys(index).length > 0, 'empty source index');
function inputPath(name) {
  if (index[name]?.local_relative) return path.join(inputDir, index[name].local_relative);
  const direct = path.join(inputDir, name);
  if (existsSync(direct)) return direct;
  // Collector moves case sidecars under the case and batch files under support.
  const match = name.match(/^(session-ttl1|soak-ttl1|recovery)\.(.+)$/);
  return match ? path.join(inputDir, match[1], match[2]) : path.join(inputDir, 'support', name);
}
for (const [name, record] of Object.entries(index)) {
  assert.equal(record.source_path, plan.remote_batch + '/' + name, `source path ${name}`);
  if (record.local_relative) {
    assert(!path.isAbsolute(record.local_relative) && !record.local_relative.split('/').includes('..'), `collected path ${name}`);
  }
  assert(/^[0-9a-f]{64}$/.test(record.source_sha256), `source SHA ${name}`);
  assert.equal(sha(inputPath(name)), record.collected_sha256, name);
  if (record.byte_preserved) assert.equal(record.source_sha256, record.collected_sha256, `byte-preserved ${name}`);
  assert.equal(record.bytes, readFileSync(inputPath(name)).length);
}
const out = options['--out'] ?? path.join(root, partial ? 'analysis-partial' : 'analysis');
mkdirSync(out, { recursive: true });
const median = values => {
  assert(values.length && values.every(Number.isFinite));
  const sorted = [...values].sort((a, b) => a - b), half = sorted.length >> 1;
  return sorted.length % 2 ? sorted[half] : (sorted[half - 1] + sorted[half]) / 2;
};
const sum = values => values.reduce((a, b) => a + b, 0);
const near = (a, b) => assert(Math.abs(a - b) <= Math.max(1e-9, Math.abs(a) * 1e-10), `${a} != ${b}`);
const omit = (value, names) => Object.fromEntries(Object.entries(value).filter(([k]) => !names.includes(k)));
const measurement = value => omit(value, ['histogram_ms', 'anomalies']);
const fmt = (n, digits = 3) => Number.isFinite(n) ? n.toFixed(digits) : '不可用';
const mib = n => Number.isFinite(n) ? n / 1048576 : null;
const pct = n => Number.isFinite(n) ? `${n >= 0 ? '+' : ''}${(100 * n).toFixed(3)}%` : '不可用';
const counts = values => values.reduce((r, v) => (r[String(v)] = (r[String(v)] ?? 0) + 1, r), {});

function resources(row) {
  return Object.fromEntries(Object.entries(row.resources).map(([name, r]) => {
    assert.deepEqual([r.before.pid, r.before.start_ticks], [r.after.pid, r.after.start_ticks]);
    const cpuMs = r.cpu_seconds * 1000 / row.measurement.successful_requests;
    near(cpuMs, r.cpu_ms_per_1000_success / 1000);
    near(r.cpu_seconds, r.after.cpu_seconds - r.before.cpu_seconds);
    return [name, { ...r, cpu_ms_per_success: cpuMs,
      average_cores: r.cpu_seconds / (row.measurement.elapsed_ms / 1000),
      sampled_peak_rss_mib: r.peak_rss_bytes / 1048576 }];
  }));
}

const report = {
  schema_version: 1, complete: false,
  purpose: 'Incremental audit repair: optimized Go4d + Rust5fdd expected4d versus Go669 + same Rust5fdd expected669; no pooling with earlier performance trials.',
  plan_sha256: sha(path.join(planDir, 'manifest.json')),
  analyzer_sha256: sha(fileURLToPath(import.meta.url)),
  source_files: index, fixture: plan.fixture, gate_contract: plan.gate_contract,
  sources: plan.product_sources, artifacts: plan.artifacts, cases: {},
};
const completionNotePath = path.join(root, 'completion-note.json');
if (existsSync(completionNotePath)) report.completion_note = load(completionNotePath);
const productProcesses = new Set();
for (const name of ['session-ttl1', 'soak-ttl1', 'recovery']) {
  if (!existsSync(inputPath(name + '.outcome.json'))) {
    assert(partial, `missing completed case ${name}`);
    continue;
  }
  for (const required of [name + '/results.json', name + '/manifest.json', name + '.outcome.json', name + '.contract.json', name + '.gate.json']) {
    assert(index[required], `unindexed evidence ${required}`);
  }
  const rows = load(inputPath(name + '/results.json')).runs;
  const outcome = load(inputPath(name + '.outcome.json'));
  const contract = spawnSync('python3', ['-B', path.join(planDir, 'check-plan.py'), 'contract', name, path.dirname(inputPath(name + '/results.json'))], { encoding: 'utf8' });
  writeFileSync(path.join(out, name + '.contract.json'), contract.stdout);
  writeFileSync(path.join(out, name + '.contract.stderr.txt'), contract.stderr);
  assert.equal(contract.status, 0, contract.stdout + contract.stderr);
  const checked = JSON.parse(contract.stdout);
  assert.deepEqual(omit(checked, ['inputs']), omit(load(inputPath(name + '.contract.json')), ['inputs']));
  assert.equal(outcome.passed, true, `recorded failure ${name}`);
  assert.equal(outcome.exit_code, 0);
  for (const stage of ['harness', 'contract', 'gate', 'report']) {
    assert.deepEqual(outcome.stages[stage], { executed: true, exit_code: 0 });
  }
  for (const [file, info] of Object.entries(outcome.evidence)) {
    if (index[file]) assert.equal(index[file].source_sha256, info.sha256, `outcome evidence ${file}`);
  }
  for (const row of rows) {
    for (const component of ['go', 'rust']) {
      const r = row.resources[component].before;
      const id = JSON.stringify([component, r.pid, r.start_ticks]);
      assert(!productProcesses.has(id), 'product process reused across tail cases');
      productProcesses.add(id);
    }
  }
  report.cases[name] = {
    contract_passed: true, recorded_outcome: outcome, trials: rows.length,
    normal_load: { successes: sum(rows.map(r => r.measurement.successful_requests)), failures: sum(rows.map(r => r.measurement.failures)) },
    warmup: { successes: sum(rows.map(r => r.warmup.measurement.successful_requests)), failures: sum(rows.map(r => r.warmup.measurement.failures)), duration_warnings: rows.filter(r => r.warmup.quality?.duration_ok === false).length },
    identities: load(inputPath(name + '/manifest.json')).identities,
    rows: rows.map(row => ({ role: row.role, pair: row.pair, scenario: row.scenario,
      measurement: measurement(row.measurement), warmup: measurement(row.warmup.measurement),
      resources: resources(row), quality: row.quality, observation_counts: row.observation_counts })),
  };
  const group = report.cases[name];
  if (name === 'session-ttl1') {
    const comparisons = compareRuns(rows);
    assert.equal(comparisons.length, 1);
    assert.equal(comparisons[0].complete_pairs, 6);
    const failures = comparisonFailures(comparisons, { requireSixPairs: true });
    assert.deepEqual(comparisons, load(inputPath(name + '.gate.json')));
    group.comparison = comparisons[0];
    group.gate_failures = failures;
    assert.deepEqual(failures, [], 'frozen nonregression gate');
    group.absolute_medians = Object.fromEntries(['baseline', 'candidate'].map(role => {
      const selected = group.rows.filter(r => r.role === role);
      return [role, { rps: median(selected.map(r => r.measurement.successful_requests_per_second)),
        p99_ms: median(selected.map(r => r.measurement.p99_ms)),
        combined_separate_peak_rss_mib: median(selected.map(r => r.resources.go.sampled_peak_rss_mib + r.resources.rust.sampled_peak_rss_mib)),
        resources: Object.fromEntries(['go', 'rust', 'client', 'fixture'].map(component => [component,
          Object.fromEntries(['cpu_seconds', 'cpu_ms_per_success', 'average_cores', 'sampled_peak_rss_mib'].map(metric => [metric, median(selected.map(r => r.resources[component][metric]))]))])) }];
    }));
    group.ratio_of_role_medians = Object.fromEntries(['rps', 'p99_ms', 'combined_separate_peak_rss_mib'].map(metric => [metric, group.absolute_medians.candidate[metric] / group.absolute_medians.baseline[metric] - 1]));
    group.paired_cpu = Object.fromEntries(['go', 'rust', 'client', 'fixture'].map(component => {
      const pairs = Array.from({ length: 6 }, (_, pair) => {
        const selected = group.rows.filter(r => r.pair === pair);
        const b = selected.find(r => r.role === 'baseline').resources[component];
        const c = selected.find(r => r.role === 'candidate').resources[component];
        return { pair, cpu_ms_per_success_change: b.cpu_ms_per_success > 0 ? c.cpu_ms_per_success / b.cpu_ms_per_success - 1 : null,
          average_cores_change: b.average_cores > 0 ? c.average_cores / b.average_cores - 1 : null };
      });
      const completeMedian = values => values.every(Number.isFinite) ? median(values) : null;
      return [component, { pairs, cpu_ms_per_success_change_median: completeMedian(pairs.map(p => p.cpu_ms_per_success_change)), average_cores_change_median: completeMedian(pairs.map(p => p.average_cores_change)),
        note: 'A zero baseline tick delta makes the relative CPU change unavailable; do not floor it or add a performance gate.' }];
    }));
    group.cpu_tick_deltas = group.rows.map(row => ({ role: row.role, pair: row.pair,
      components: Object.fromEntries(Object.entries(row.resources).map(([component, r]) => {
        const ticks = r.cpu_seconds * plan.fixture.clock_ticks_per_second;
        near(ticks, Math.round(ticks));
        return [component, Math.round(ticks)];
      })) }));
  } else if (name === 'soak-ttl1') {
    const row = rows[0], rawName = path.posix.relative(plan.remote_batch, row.raw_result_file);
    assert.equal(rawName.split('/')[0], name);
    assert(index[rawName], 'unindexed soak raw');
    const raw = load(inputPath(rawName));
    const rawSummary = { ...omit(raw, ['samples', 'runtime_health', 'timeout_phase_events']),
      raw_result_file: row.raw_result_file,
      observation_counts: { process_samples: raw.samples?.length ?? 0, health_samples: raw.runtime_health?.length ?? 0, timeout_phase_events: raw.timeout_phase_events?.length ?? 0 } };
    assert.deepEqual(rawSummary, row, 'soak raw/aggregate equality');
    group.trend = summarizeSoak(raw);
    assert.deepEqual(group.trend, load(inputPath(name + '.soak-summary.json')), 'frozen soak summary independently recomputed');
    assert(group.trend.completed_30_minutes_without_request_or_quality_failure);
    assert.deepEqual(load(inputPath(name + '.gate.json')), { passed: true, completion_only: true, resource_growth_gate: false });
    const health = raw.runtime_health ?? [];
    group.health = {
      samples: health.length,
      http_status_counts: counts(health.map(h => h.status)),
      errors: health.filter(h => h.error).length,
      storage_status_counts: counts(health.map(h => h.storage?.status)),
      auth_bridge_status_counts: counts(health.map(h => h.auth_bridge?.status)),
      auth_bridge_reason_counts: counts(health.map(h => h.auth_bridge?.reason_code)),
      unique_gateway_snapshot_timestamps: new Set(health.map(h => h.gateway_runtime?.last_checked_at)).size,
      first: health[0], last: health.at(-1),
    };
  } else {
    const comparisons = compareRuns(rows);
    assert.deepEqual(comparisons, load(inputPath(name + '.gate.json')));
    assert.deepEqual(comparisonFailures(comparisons), []);
    group.probes = rows.map(row => {
      const probe = row.recovery;
      const burst = probe.burst;
      const gap = probe.recovery_started_at_epoch_ms - burst.requests_finished_at_epoch_ms;
      return { role: row.role, passed: probe.passed, recovered: probe.recovered,
        burst: measurement(burst.measurement), burst_quality: burst.quality,
        burst_503_responses: probe.burst_503_responses,
        saturation_observed: probe.burst_503_responses > 0,
        burst_503_rate: probe.burst_503_responses / burst.measurement.requests,
        recovery_elapsed_ms: probe.recovery_elapsed_ms, observed_until_ms: probe.observed_until_ms,
        burst_last_request_to_recovery_timer_ms: gap,
        burst_last_request_to_success_window_end_ms: gap + probe.recovery_elapsed_ms,
        checks: probe.checks.map(c => ({ ...omit(c, ['result']), measurement: measurement(c.result.measurement), quality: c.result.quality })),
        health: Object.fromEntries(['before_health', 'after_burst_health', 'after_recovery_health'].map(k => [k, {
          ...omit(probe[k], ['snapshot']), overall_status: probe[k].snapshot?.overall_status,
          cached_last_checked_at: probe[k].snapshot?.last_checked_at,
        }])) };
    });
  }
}
report.observed_tail_trials = sum(Object.values(report.cases).map(c => c.trials));
report.independent_product_processes = productProcesses.size;
report.complete = Object.keys(report.cases).length === 3 && report.observed_tail_trials === 15;
if (!partial) {
  assert(report.complete);
  assert(index['outcome.json'] && index['prepared-manifest.json'], 'unindexed batch evidence');
  const batch = load(inputPath('outcome.json'));
  assert(batch.passed && batch.exit_code === 0 && batch.expected_trials === 45 && batch.no_prior_trial_pooling);
  assert.deepEqual(batch.completed_cases, ['smoke', 'session-ttl0', 'session-ttl1', 'soak-ttl1', 'recovery']);
  assert.equal(index['prepared-manifest.json'].source_sha256, report.plan_sha256);
  assert.deepEqual(load(inputPath('prepared-manifest.json')), plan);
  report.batch_outcome = batch;
}
report.limitations = [
  '本批只评价既有优化后的 Go4d 到修复 Go669 的增量；Rust 源码仍5fdd，仅 expected gateway commit 及构建制品变化；不与以前273个trial合并。',
  report.completion_note ? '原计划本报告覆盖后半段15trial；收尾时实际仅验收TTL1六对12trial。soak按用户请求中止，recovery未执行；前半段30trial由root另行复核，不声称整批45trial完成。' : '本报告负责TTL1六对、候选TTL1 soak和recovery，共15trial；batch outcome的45trial声明不能替代另30trial逐项复核。',
  '稳定session负载没有主动注销；竞态正确性由确定性barrier测试证明，不由这些性能数字证明。',
  'RPS/P99配对中位变化和固定种子bootstrap95%区间直接复用冻结工具；绝对列为各角色六trial中位数，两个角色中位数之比另列，三者不得互换。P99并非合并请求分位数。',
  'Go与Rust各自采样RSS峰值之和不一定同时达到；不是VmHWM。CPU ms/成功请求=进程CPU秒*1000/成功数；平均核数=进程CPU秒/实际load秒，含后台与采样收尾，100Hz精度，不是延迟或单请求追踪。CPU配对变化仅描述，不设新增门槛。',
  '预定单候选单场景30分钟协议没有资源增长验收门槛；五分钟中位趋势不证明无泄漏。未测停载/GC后回收。Go goroutine来自缓存health，重复观察不独立；Rust async task不可用，native线程不能替代。',
  'health_ok只说明既有采集成功，不能推断所有缓存组件都healthy；primary队列快照不覆盖auth reader队列，五秒缓存不能定位每个503根因。',
  '冻结恢复协议仅包含一轮capacity32/c64两秒burst，再c1连续两秒成功；recovery_elapsed从burst worker清理及收尾后开始，包含完整成功窗，不是首次恢复延迟。单轮差异不做恢复速度收益声明。',
  'burst的503单独列出，不混入常规warm/load质量计数；存在503仅证明可观察拒绝压力，不能确定Go或Rust哪一层容量首先触发。无503不追加失败门槛，但不能声称已观察饱和。',
  '分析完全离线。原始pull按固定文件只读SSH收集、不访问业务端口、不写远端、不启动负载；本地输入核对收集SHA，source index另存源SHA。统一collector的JSON重编码/脱敏可改变收集SHA，两种SHA不混淆。源码到制品关系另依赖冻结build manifest及构建声明，hash不证明编译过程本身可信。',
];

const lines = ['# audit6 后半段离线分析', '', report.complete ? '三阶段共15个trial已完成并通过冻结合同和原门槛。' : '部分阶段已完成；本文件不是全批验收。', '',
  '比较为 Go4d → Go669 的审计修复增量；Rust源码同为5fdd，但各自绑定对应Go身份重建。固定c16/clients2、accounts/sessions1000、ordinary grants100、TOTP、mobility=false、reader1、z/fat/CGU1、Tokio2；正常桥接容量缺省。', ''];
if (report.completion_note) {
  assert(partial && !report.complete, 'user stop note cannot mark a full batch complete');
  lines.splice(2, 1, 'TTL1六对12条已完成并通过。用户要求尽快收尾，soak按此请求中止，未作30分钟完成验收；recovery未执行。本包不将整批audit6标为passed。');
  lines.push('停止信息来自root转达的用户收尾决定；本包在该指令后停止远端读取，未采集中止后的outcome，清理及中止证据由root另行保留。TTL1六份原输入及其源SHA保持不变。', '');
}
const ttl = report.cases['session-ttl1'];
if (ttl) {
  const c = ttl.comparison, b = ttl.absolute_medians.baseline, v = ttl.absolute_medians.candidate;
  lines.push('## TTL1：六对session_hit', '',
    `12trial，warm20秒/load60秒，前后正/负TTL均读回1；常规load成功${ttl.normal_load.successes}，失败${ttl.normal_load.failures}；warm成功${ttl.warmup.successes}，失败${ttl.warmup.failures}。六对非回退门槛通过：RPS中位变化≥−5%、P99≤+10%、合计RSS≤+5%，没有要求达到新增收益。`, '',
    '| 指标 | baseline六trial中位 | candidate六trial中位 | 配对变化中位 | 配对bootstrap 95% |', '| --- | ---: | ---: | ---: | --- |',
    `| RPS | ${fmt(b.rps)} | ${fmt(v.rps)} | ${pct(c.throughput_change_median)} | ${c.throughput_change_bootstrap_95.map(pct).join(' 至 ')} |`,
    `| P99 ms | ${fmt(b.p99_ms)} | ${fmt(v.p99_ms)} | ${pct(c.p99_change_median)} | ${c.p99_change_bootstrap_95.map(pct).join(' 至 ')} |`,
    `| Go+Rust各自峰值之和 MiB | ${fmt(b.combined_separate_peak_rss_mib)} | ${fmt(v.combined_separate_peak_rss_mib)} | ${pct(c.peak_rss_change_median.combined)} | 未计算 |`, '',
    `仅作区分：角色中位数之比变化为RPS ${pct(ttl.ratio_of_role_medians.rps)}、P99 ${pct(ttl.ratio_of_role_medians.p99_ms)}、合计RSS ${pct(ttl.ratio_of_role_medians.combined_separate_peak_rss_mib)}，不能代替上表配对中位变化。`, '',
    '| 进程 | CPU ms/成功请求：base→candidate中位 | 配对变化中位 | 平均核数：base→candidate中位 | RSS采样峰MiB：base→candidate中位 |', '| --- | ---: | ---: | ---: | ---: |');
  for (const component of ['go', 'rust', 'client', 'fixture']) {
    const x = b.resources[component], y = v.resources[component];
    lines.push(`| ${component} | ${fmt(x.cpu_ms_per_success, 6)}→${fmt(y.cpu_ms_per_success, 6)} | ${pct(ttl.paired_cpu[component].cpu_ms_per_success_change_median)} | ${fmt(x.average_cores, 5)}→${fmt(y.average_cores, 5)} | ${fmt(x.sampled_peak_rss_mib)}→${fmt(y.sampled_peak_rss_mib)} |`);
  }
  const rustTicks = ttl.cpu_tick_deltas.map(r => r.components.rust);
  lines.push('', `各对变化、每trial原始资源基数与进程身份见TAIL-SUMMARY.json；CPU无新增显著性或收益门槛。Rust每个60秒trial累计CPU仅${Math.min(...rustTicks)}–${Math.max(...rustTicks)}个10ms tick，相对小变化对计数粒度及后台CPU敏感，不宣称Rust CPU改善。`,
    c.throughput_change_bootstrap_95[0] <= 0 && c.throughput_change_bootstrap_95[1] >= 0 ? '吞吐配对区间跨零；本次结论是未超过冻结回退预算，不是已证明新增加速。' : '此处沿用非回退门槛，未另设修复收益目标。', '');
}
const soak = report.cases['soak-ttl1'];
if (soak) {
  const row = soak.rows[0], m = row.measurement, t = soak.trend;
  lines.push('## TTL1：候选30分钟session soak', '',
    `实际load ${fmt(m.elapsed_ms / 1000)}秒，成功${m.successful_requests}，失败${m.failures}，RPS ${fmt(m.successful_requests_per_second)}，P50/P95/P99=${m.p50_ms}/${m.p95_ms}/${m.p99_ms}ms。warm成功${soak.warmup.successes}、失败${soak.warmup.failures}。原始raw与aggregate严格一致，使用冻结summarizeSoak重新计算后与远端summary逐字段一致。`, '',
    '| 进程 | RSS首→末5分钟中位MiB（变化） | 峰RSS MiB | FD首→末/峰 | native线程首→末/峰 | CPU ms/请求 | 平均核数 |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: |');
  for (const name of ['go', 'rust']) {
    const p = t.processes[name], r = row.resources[name];
    lines.push(`| ${name} | ${fmt(mib(p.rss_bytes.first_window_median))}→${fmt(mib(p.rss_bytes.last_window_median))} (${pct(p.rss_bytes.median_change)}) | ${fmt(mib(p.rss_bytes.peak))} | ${p.fds.first_window_median}→${p.fds.last_window_median}/${p.fds.peak} | ${p.threads.first_window_median}→${p.threads.last_window_median}/${p.threads.peak} | ${fmt(r.cpu_ms_per_success, 6)} | ${fmt(r.average_cores, 5)} |`);
  }
  const g = t.go_goroutines;
  lines.push('', `Go goroutine首/末中位${g.first_window_median}→${g.last_window_median}、峰${g.peak}。进程采样${row.observation_counts.process_samples}次，health ${soak.health.samples}次，其中gateway快照时间戳仅${soak.health.unique_gateway_snapshot_timestamps}个；Rust async task未测量。health HTTP状态${JSON.stringify(soak.health.http_status_counts)}，storage ${JSON.stringify(soak.health.storage_status_counts)}，bridge ${JSON.stringify(soak.health.auth_bridge_status_counts)}。`, '',
    '| 负载区间分钟 | Go RSS中位MiB | Rust RSS中位MiB | 采样数 |', '| --- | ---: | ---: | ---: |');
  for (const bucket of t.buckets) lines.push(`| ${fmt(bucket.from_ms / 60000, 2)}–${fmt(bucket.to_ms / 60000, 2)} | ${fmt(mib(bucket.processes.go.rss_bytes))} | ${fmt(mib(bucket.processes.rust.rss_bytes))} | ${bucket.samples} |`);
  lines.push('', '尾端不足五分钟的桶单列，不用于代替首/末窗口定义；短尾桶可能无采样。完成判定不包含RSS趋势阈值，不能据此宣称无泄漏。', '');
}
const recovery = report.cases.recovery;
if (recovery) {
  lines.push('## capacity32恢复探测', '',
    '正常warm/load为c16、1/3秒、TTL0；probe是c64发起2秒，再c1要求10秒内完成连续2秒成功窗口。', '',
    '| 角色 | burst实际秒 | burst 200/503 | 503比例 | 成功窗次数/最终成功数 | 报告恢复ms（含2秒窗） | burst末请求→计时开始ms | observed_until ms |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |');
  for (const p of recovery.probes) {
    lines.push(`| ${p.role} | ${fmt(p.burst.elapsed_ms / 1000)} | ${p.burst.statuses['200'] ?? 0}/${p.burst_503_responses} | ${(p.burst_503_rate * 100).toFixed(3)}% | ${p.checks.length}/${p.checks.at(-1).measurement.successful_requests} | ${fmt(p.recovery_elapsed_ms)} | ${fmt(p.burst_last_request_to_recovery_timer_ms)} | ${fmt(p.observed_until_ms)} |`);
  }
  lines.push('', `两角色常规load合计成功${recovery.normal_load.successes}、失败${recovery.normal_load.failures}，warm成功${recovery.warmup.successes}、失败${recovery.warmup.failures}。burst错误独立报告。503压力观察：${recovery.probes.map(p => `${p.role}=${p.saturation_observed}`).join('，')}。恢复计时不等于首次成功延迟，不能由单轮差异宣称更快恢复。`, '',
    ...recovery.probes.map(p => `- ${p.role} 缓存health overall前/后：${p.health.before_health.overall_status} → ${p.health.after_recovery_health.overall_status}；bridge前/后：${p.health.before_health.auth_bridge?.reason_code} → ${p.health.after_recovery_health.auth_bridge?.reason_code}。`), '');
}
lines.push('## 证据与边界', '', ...report.limitations.map(x => '- ' + x), '',
  `冻结plan SHA256：${report.plan_sha256}。本地复跑：\`node analyze.mjs${partial ? ' --partial' : ''}\`，可显式传入归档路径，详见README；不需要远端或产品二进制。source-files.json或collection.json保留源路径、源SHA、收集SHA及大小。`, '');
writeFileSync(path.join(out, 'TAIL-SUMMARY.json'), JSON.stringify(report, null, 2) + '\n');
writeFileSync(path.join(out, 'TAIL-REVIEW.md'), lines.join('\n'));
console.log(JSON.stringify({ complete: report.complete, cases: Object.keys(report.cases), trials: report.observed_tail_trials, output: out }));
