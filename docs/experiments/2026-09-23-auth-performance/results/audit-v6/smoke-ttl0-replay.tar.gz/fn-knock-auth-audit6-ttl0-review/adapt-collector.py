#!/usr/bin/env python3
"""Map audit6 standard collector paths to a NEW local analysis view; no SSH."""
import argparse,hashlib,json,shutil
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--collection',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args();assert not a.out.exists(),'view already exists; never overwrite independent inputs'
    collection=load(a.collection/'collection.json');records=collection['collected']
    by_source={r['source']:r for r in records};assert len(by_source)==len(records),'duplicate source entries'
    plan=load(ROOT/'plan/manifest.json');remote=plan['remote_batch']
    mappings={'prepared-manifest.json':'support/prepared-manifest.json'}
    for case in ['smoke','session-ttl0']:
        for name in ['results.json','manifest.json']:mappings[f'{case}/{name}']=f'{case}/{name}'
        for name in ['outcome.json','contract.json','gate.json','report.md']:mappings[f'{case}.{name}']=f'{case}/{name}'
    staged=[]
    for local,expected_relative in mappings.items():
        source=remote+'/'+local;record=by_source[source];relative=PurePosixPath(record['relative'])
        assert not relative.is_absolute() and '..' not in relative.parts,'unsafe collected path'
        assert str(relative)==expected_relative,'unexpected collector structure: '+source
        file=a.collection/str(relative)
        assert file.is_file() and sha(file)==record['collected_sha256'] and file.stat().st_size==record['collected_bytes'],'collected content changed: '+str(file)
        staged.append((local,file,record))
    a.out.mkdir(parents=True)
    index={}
    for local,file,record in staged:
        target=a.out/local;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
        index[local]={k:record[k] for k in ['source','relative','source_sha256','source_bytes','collected_sha256','collected_bytes']}
    provenance={'schema_version':1,'collection_index_sha256':sha(a.collection/'collection.json'),'collection_source':str(a.collection.resolve()),'scope':['smoke','session-ttl0'],'files':index,'note':'Source hashes bind recorded outcome inputs; collected hashes bind normalized/redacted archived content. Original independent pull inputs are untouched.'}
    (a.out/'source-index.json').write_text(json.dumps(provenance,indent=2)+'\n')
    print(json.dumps({'view':str(a.out),'files':len(index),'remote_access':False,'original_inputs_modified':False},indent=2))
if __name__=='__main__':main()
