# 鉴权性能实验结果

记录 18 个trial；0 个无效。所有变化按candidate相对baseline计算。

| 路由 / 并发 / 候选 / cache TTL / 规模 | 完整对数 | 成功吞吐变化 | P99变化 | 吞吐95%区间 | P99 95%区间 | Go峰值RSS变化 | Rust峰值RSS变化 | 合计峰值RSS变化 |
| --- | ---: | ---: | ---: | --- | --- | ---: | ---: | ---: |
| bootstrap/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -0.1% | -15.9% | 不足6对 | 不足6对 | -2.6% | +4.7% | +0.8% |
| session_api/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -3.7% | +5.6% | 不足6对 | 不足6对 | -0.7% | +4.3% | +1.8% |
| session_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -2.0% | +7.1% | 不足6对 | 不足6对 | +0.4% | +2.6% | +1.5% |
| grant_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -0.5% | -4.0% | 不足6对 | 不足6对 | -0.9% | +5.2% | +2.0% |
| auto_ip_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -2.9% | +1.9% | 不足6对 | 不足6对 | +3.2% | +6.3% | +4.8% |
| auto_ip_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -2.1% | +0.0% | 不足6对 | 不足6对 | +5.8% | +2.5% | +4.2% |
| challenge/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -0.7% | +18.2% | 不足6对 | 不足6对 | -0.0% | +4.2% | +1.9% |
| session_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | -0.1% | +0.0% | 不足6对 | 不足6对 | -3.5% | +2.6% | -0.7% |
| grant_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0 | 1 | +12.8% | -13.3% | 不足6对 | 不足6对 | -1.7% | +1.8% | -0.1% |

存在不足六对或无效trial；这些数字只用于检查工具与发现线索，不能作为已证实的优化收益。

| 路由 / 角色 | req/s | P99 ms | Go CPU ms/千成功请求 | Rust CPU ms/千成功请求 | Go 峰值→结束 RSS MiB | Rust 峰值→结束 RSS MiB | 失败请求 |
| --- | ---: | ---: | ---: | ---: | --- | --- | ---: |
| bootstrap/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 398.3 | 63.0 | 397.7 | 3082.0 | 39.98 → 39.98 | 35.75 → 35.06 | 0 |
| bootstrap/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 398.0 | 53.0 | 416.0 | 3119.8 | 38.95 → 38.95 | 37.43 → 36.95 | 0 |
| session_api/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 310.1 | 72.0 | 445.9 | 5318.5 | 38.76 → 38.76 | 38.45 → 35.40 | 0 |
| session_api/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 298.8 | 76.0 | 431.4 | 5331.9 | 38.47 → 38.47 | 40.09 → 37.07 | 0 |
| session_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 496.5 | 42.0 | 472.7 | 2849.5 | 40.55 → 40.55 | 37.78 → 35.11 | 0 |
| session_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 486.6 | 45.0 | 448.4 | 2853.3 | 40.73 → 40.73 | 38.75 → 35.92 | 0 |
| grant_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 1015.7 | 25.0 | 539.9 | 1014.4 | 40.82 → 40.64 | 35.21 → 35.21 | 0 |
| grant_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 1010.4 | 24.0 | 538.4 | 1027.6 | 40.46 → 40.46 | 37.06 → 37.04 | 0 |
| auto_ip_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 176.2 | 104.0 | 422.8 | 6323.5 | 37.34 → 37.34 | 37.14 → 36.60 | 0 |
| auto_ip_hit/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 171.1 | 106.0 | 492.4 | 6439.4 | 38.53 → 38.53 | 39.49 → 38.61 | 0 |
| auto_ip_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 218.5 | 81.0 | 684.5 | 5208.3 | 37.13 → 37.13 | 37.63 → 37.36 | 0 |
| auto_ip_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 214.0 | 81.0 | 654.5 | 5327.2 | 39.30 → 39.30 | 38.58 → 37.64 | 0 |
| challenge/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 3193.3 | 11.0 | 235.5 | 291.7 | 40.86 → 40.13 | 34.90 → 34.88 | 0 |
| challenge/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 3170.0 | 13.0 | 232.9 | 289.6 | 40.86 → 40.36 | 36.38 → 35.85 | 0 |
| session_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 2497.5 | 15.0 | 266.4 | 519.5 | 41.53 → 41.13 | 35.04 → 35.04 | 0 |
| session_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 2495.6 | 15.0 | 265.3 | 517.2 | 40.09 → 39.59 | 35.94 → 35.79 | 0 |
| grant_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/baseline | 2539.8 | 15.0 | 247.7 | 491.4 | 41.60 → 41.13 | 34.84 → 34.80 | 0 |
| grant_miss/16/candidate6/cache-0/profile-off/recovery-off/credential-totp/sessions-1000/accounts-1000/grants-100/total-grants-100/renewals-0/candidate | 2864.5 | 13.0 | 227.8 | 446.3 | 40.90 → 39.85 | 35.47 → 35.26 | 0 |

SQLite primary采样最大队列深度 0，最大队列等待 0.0ms，最大活动操作 1.0ms。这些health字段只统计primary executor，不代表auth reader单slot或全池；auth pool饱和时仍可能为零。

超时phase事件：未记录。

正常负载结果不等于故障恢复测试；可选recovery-probe仅测试请求burst后的恢复，不覆盖Rust暂停/退出、SQLite写锁或上游断开。失败trial的failure_health保留清理前最后一次管理快照，快照自身错误单独记录。RSS为负载期间峰值和结束值，没有主动触发GC，也不代表空闲30秒后的保留量。

grant_renewal是每token仅执行一次的有限批次；短smoke中的CPU tick量化和少量尾延迟样本不适合衡量收益。phase只反映已记录的超时事件，空结果不表示SQLite等待为零。
