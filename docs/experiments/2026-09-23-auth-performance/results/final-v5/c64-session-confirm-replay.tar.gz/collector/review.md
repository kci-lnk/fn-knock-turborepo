# c64 confirmation 收集规范静态复核

结论：**可按新 spec 收集已结束的独立 12-trial confirmation；未发现阻塞性路径或 schema 错配。** 本次只读本地文件，没有运行 collect/selftest、远端访问、产品执行或编译。

## 已核对

- 新 collector 与旧版逐字节一致，SHA256 `ee21d25f87522d3afa289a4857c60c1debfb72e1e01ed610d8aff8b65d0f84f8`。
- review-spec SHA256 `7dabeda85a8a11081f8c99d18cbb7c272b08d7b345a3c93ec8c3d948c2dca30d`；collection-plan SHA256 `547504da5f44dc880002e9424ee566728d96da2af13ea796c5641a216fbd49f8` 与 spec 的 plan_source_sha256 相符。
- 冻结 confirmation manifest SHA256 `35899a5ade46d210c2da17fa3c018d4b31ff569d2586a1e458c262a88b38b408` 与 collection-plan 固定值相符。新 spec 的 expected_options 与冻结 manifest.options 完全相同，也与先前已下载的真实 manifest 一致：session_hit、6 pairs、c64、warm20/load60、clients2、N1000 accounts/sessions、100 grants、TOTP、TTL0、双角色、无 profile/recovery。
- 只枚举 `c64-session-confirm-final/session_hit` 下的直接 trial 子目录 result.json，加 results/manifest；sidecar 实际展开成同级 `session_hit.contract.json`、`session_hit.gate.json`、`session_hit.report.md`，与 runner 写入位置一致。
- extras 覆盖 batch prepared-manifest、trigger、outcome、started/finished 时间及可选 completed 时间；另保存 plan 的 manifest、variants、trigger。正常完成全成功预期 26 个源文件；若只有 gate 失败而没有 completed 标记，则 25 个源文件，缺少此可选标记本身不导致收集失败。这里不是自包含 runner 重放包，执行源码仅由冻结 manifest 的 files hashes 引用。
- review 预期集合是独立的 `(session_hit, pair0..5, baseline/candidate)`，恰好 12 条、AB/BA 及 raw/aggregate 一一对应；输出本地目录必须不存在。spec 不枚举旧 261-trial 目录；trigger 内旧来源路径只是 JSON 字符串，collector 不递归追随它们。
- 已下载的早期 5-row 快照仅用于核对 schema，不冒充最终 12 条完成证明。其 seed 为 total_grants100、ordinary_grants100、renewal_tokens_per_phase0，与本 spec 及通用校验相符。

## 失败证据与校验边界

- 普通 strict gate 不达标时，冻结 checker 在断言失败前已经输出合法 comparison JSON；runner 仍生成 report/outcome。collector 先导出所有白名单文件再 review，不因该 gate 退出码舍弃 raw。contract/quality 失败会使 review 非零，但已写本地 raw/sidecars 仍保留。
- **complete_and_consistent 不是性能验收结果。** list 形式的 gate 只检查完整有效配对；support/outcome 的 passed/exit_code 不参与该布尔值。性能门槛失败但数据有效时，该布尔值仍可能为 true。必须另读 outcome 的 stages/exit_code，并按冻结 gate 解释收益/RSS结果，不将收集完整性替代验收。
- 每个导出文件记录原 source SHA/字节数及脱敏、标准化后的 collected SHA/字节数；传输后和 verify 重算 collected SHA，远端导出末尾复读 source 确认未变。contract.inputs 的哈希与 source SHA 比对。JSON 格式化或脱敏后 source/collected SHA 不同属正常，raw 和 aggregate 使用同一 sanitize 规则后比较。
- support/outcome.evidence 的哈希、prepared/plan manifest 与 collection-plan 中冻结 pin 的关系需要最终人工或专用分析再次核对；通用 review 未实现这些特定确认实验关联。制品 SHA allowlist 仍带旧 compiler s/2/3 条目，但不造成导出这些目录；制品角色/源码的严格约束来自冻结 contract，而非仅此 allowlist。
- 复用代码的 selftest 写死总数 261（第304行），**不要对新 spec 运行 selftest**。正常 collect/verify 采用 spec.expected_trials=12，不受此常量影响。
- 若 sidecar 非法/空 JSON（如工具崩溃，而非正常性能 gate 不达标），export 会在随后 raw 枚举前失败。该异常不在“正常 gate failure 保留完整归档”的保证内；不要删除远端原文件，需单独保留/诊断。当前审阅未声称最终 sidecars 已存在或可解析。
- INDEX-SHA256.json 在 collect 完成时生成；复用 verify 仅在该文件存在时校验，不会主动拒绝缺失 INDEX。最终归档仍需确认该文件存在及四个 envelope hash 匹配。

本审查不新增统计门槛、不改变原 261 条，也不判断尚未收集的 confirmation 结果。
